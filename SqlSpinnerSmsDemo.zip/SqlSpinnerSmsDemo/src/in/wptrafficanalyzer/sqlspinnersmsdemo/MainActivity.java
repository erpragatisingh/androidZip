package in.wptrafficanalyzer.sqlspinnersmsdemo;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends FragmentActivity implements LoaderCallbacks<Cursor> {
	
	SimpleCursorAdapter mAdapter;
	ListView mLstContacts;

		
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
                
        /** Event handler for click event on Add button */
        OnClickListener addContactListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				/** Creating a bundle object to pass some data to the fragment */
				Bundle args = new Bundle();				
				
				/** Adding current operation to the bundle object */
				args.putInt("contact_action", Contact.CONTACT_ADD);
				
				/** Getting fragment manager to open the contact fragment */
				/** Here Android's backward compatibility support library function getSupportFragmentManager() is used to support Android 1.6 and above */
				FragmentManager fm = getSupportFragmentManager();
				
				/** Creating contact dialog fragment */
				Contact contact = new Contact();
				
				/** Setting the bundle object to this fragment */
				contact.setArguments(args);
				
				/** Starting a fragment transaction to dyanmically add fragment to the application */
				FragmentTransaction ft = fm.beginTransaction();
				
				/** Adding fragment to the fragment transaction */
				ft.add(contact, "CONTACT");
				
				/** The contact dialog fragment is effectively added and opened */
				ft.commit();
				
			}
		};
		
        /** Event handler for click event on Edit button */
		OnClickListener editContactListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				int id = 0;
				
				/** Getting the position of the currently selected item in the listview */
				int position  = mLstContacts.getCheckedItemPosition();
				
				/** Getting the id of the currently selected contact in the listview */
				if(mAdapter.getCursor().moveToPosition(position))
					id = Integer.parseInt(mAdapter.getCursor().getString(0));
				
				/** If no item is selected, then corresponding message is shown */
				if(id==0){
					Toast.makeText(getBaseContext(), "Please Select a contact to edit", Toast.LENGTH_SHORT).show();
					return;
				}
				
				/** Creating a bundle object to pass some data to the fragment */
				Bundle args = new Bundle();
				
				/** Adding contact id to the bundle object */
				args.putInt("contact_id", id);
				
				/** Adding current operation to the bundle object */
				args.putInt("contact_action", Contact.CONTACT_EDIT);

				/** Getting fragment manager to open the contact fragment */
				/** Here Android's backward compatibility support library function getSupportFragmentManager() is used to support Android 1.6 and above */
				FragmentManager fm = getSupportFragmentManager();
				
				/** Creating contact dialog fragment */
				Contact contact = new Contact();
				
				/** Setting the bundle object to this fragment */				
				contact.setArguments(args);
				
				/** Starting a fragment transaction to dyanmically add fragment to the application */				
				FragmentTransaction ft = fm.beginTransaction();
				
				/** Adding fragment to the fragment transaction */				
				ft.add(contact, "CONTACT");
				
				/** The contact dialog fragment is effectively added and opened */				
				ft.commit();
				
			}
		};
		
		
        /** Event handler for click event on Delete button */		
		OnClickListener delContactListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				int id = 0;
				
				/** Getting the position of the currently selected item in the listview */
				int position  = mLstContacts.getCheckedItemPosition();
				
				/** Getting the id of the currently selected contact in the listview */
				if(mAdapter.getCursor().moveToPosition(position))
					id = Integer.parseInt(mAdapter.getCursor().getString(0));
				
				/** If no item is selected, then corresponding message is shown */
				if(id==0){
					Toast.makeText(getBaseContext(), "Please Select a contact to delete", Toast.LENGTH_SHORT).show();
					return;
				}
				
				/** Creating a bundle object to pass some data to the fragment */
				Bundle args = new Bundle();
				
				/** Adding contact id to the bundle object */
				args.putInt("contact_id", id);
				
				/** Adding current operation to the bundle object */
				args.putInt("contact_action", Contact.CONTACT_DEL);

				/** Getting fragment manager to open the contact fragment */
				/** Here Android's backward compatibility support library function getSupportFragmentManager() is used to support Android 1.6 and above */				
				FragmentManager fm = getSupportFragmentManager();
				
				/** Creating contact dialog fragment */
				Contact contact = new Contact();		
				
				/** Setting the bundle object to this fragment */
				contact.setArguments(args);
				
				/** Starting a fragment transaction to dyanmically add fragment to the application */
				FragmentTransaction ft = fm.beginTransaction();
				
				/** Adding fragment to the fragment transaction */
				ft.add(contact, "CONTACT");
				
				/** The contact dialog fragment is effectively added and opened */				
				ft.commit();
				
			}
		};
		
        /** Event handler for click event on Call button */
        OnClickListener callContactListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				String tel="";
				
				/** Creating an intent with the dialer's action name  */
                /** Since the intent is created with activity's action name, the intent is an implicit intent */
                Intent intent = new Intent("android.intent.action.DIAL");
                
                int position  = mLstContacts.getCheckedItemPosition();
				if(mAdapter.getCursor().moveToPosition(position))
					tel = mAdapter.getCursor().getString(2);
                
                /** Setting up a uri object with tel no.  */
                Uri data = Uri.parse("tel:"+ tel);

                /** Setting tel no. to the intent object as data */
                intent.setData(data);

                /** Starting the Dialer activity */
                startActivity(intent);

				
			}
		};
		
		
        /** Event handler for click event on SMS button */
		OnClickListener smsContactListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				String tel="";
				
				/** Creating an intent with the dialer's action name  */
                /** Since the intent is created with activity's action name, the intent is an implicit intent */
                Intent intent = new Intent("android.intent.action.VIEW");
                
                int position  = mLstContacts.getCheckedItemPosition();
				if(mAdapter.getCursor().moveToPosition(position))
					tel = mAdapter.getCursor().getString(2);
                
                /** Setting up a uri object with tel no.  */
                Uri data = Uri.parse("sms:"+ tel);

                /** Setting Tel no. to the intent object as data */
                intent.setData(data);

                /** Starting the Dialer activity */
                startActivity(intent);

				
			}
		};

		
		
        
        /** Getting a reference to Add Contact Button */
        Button addContact = (Button) findViewById(R.id.btn_add);
        addContact.setOnClickListener(addContactListener);
        
        /** Getting a reference to Edit Contact Button */
        Button editContact = (Button) findViewById(R.id.btn_edit);
        editContact.setOnClickListener(editContactListener);
        
        
        /** Getting a reference to Delete Contact Button */
        Button delContact = (Button) findViewById(R.id.btn_del);
        delContact.setOnClickListener(delContactListener);
        
        /** Getting a reference to Call  Button */
        Button callContact = (Button) findViewById(R.id.btn_call);
        callContact.setOnClickListener(callContactListener);
        
        /** Getting a reference to SMS  Button */
        Button smsContact = (Button) findViewById(R.id.btn_sms);
        smsContact.setOnClickListener(smsContactListener);
        
        
        mLstContacts = (ListView) findViewById(R.id.lst_contacts);
		
		mAdapter = new SimpleCursorAdapter(getBaseContext(),
                android.R.layout.simple_list_item_single_choice, 
                null,
                new String[] { ContactsDB.KEY_NAME, ContactsDB.KEY_PHONE},
                new int[] { android.R.id.text1 , android.R.id.text2 }, 0);

		
		mLstContacts.setAdapter(mAdapter);
		mLstContacts.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		
		/** Creating a loader for populating listview from sqlite database */
		getSupportLoaderManager().initLoader(0, null, this);
		
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

	/** A callback method invoked by the loader when initLoader() is called */
	@Override
	public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
		Uri uri = ContactsProvider.CONTENT_URI;
		return new CursorLoader(this, uri, null, null, null, null);
	}

	/** A callback method, invoked after the requested content provider returned all the data */
	@Override
	public void onLoadFinished(Loader<Cursor> arg0, Cursor arg1) {
		mAdapter.swapCursor(arg1);
	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
		mAdapter.swapCursor(null);
	}
}