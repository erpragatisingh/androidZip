package in.wptrafficanalyzer.sqlspinnersmsdemo;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.View;
import android.widget.EditText;

public class Contact extends DialogFragment implements LoaderCallbacks<Cursor>{
	
	/** A constant identifier for add operation */
	public static final int CONTACT_ADD =  1;
	
	/** A constant identifier for edit operation */
	public static final int CONTACT_EDIT = 2;
	
	/** A constant identifier for delete operation */
	public static final int CONTACT_DEL =  3;
	
	/** An adapter which holds contacts for the listview */
	SimpleCursorAdapter mAdapter;
	
	/** A reference for Contact name */
	EditText mTxtName;
	
	/** A reference for phone number */
	EditText mTxtPhone;
	
	/** A variable to inflate the layout file contact.xml*/
	View mContactView;
	
	/** A variable to hold contact id, which is required for updation and deletion of a contact */
	int mContactId = 0;
	
	/** Current operation done by this class, default is CONTACT_ADD */
	int mContactAction=CONTACT_ADD;
	
		
	/** A callback method */
	@Override
	public void onActivityCreated(Bundle arg0) {
		super.onActivityCreated(arg0);
		
		/** Getting a reference to Name */
		mTxtName = (EditText) mContactView.findViewById(R.id.txt_name);
		
		/** Getting a reference to Phone */
		mTxtPhone = (EditText) mContactView.findViewById(R.id.txt_phone);
		
		/** Creating the loader, if it does not exists */
		getLoaderManager().initLoader(0, null, this);
	};
	
		
	/** A callbak method */
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		
		/** Initializes mContactAction and mContactID using the arguments passed to this fragment by the function setArguments() */
		Bundle b = getArguments();
		if(b!=null){
			if(b.containsKey("contact_action"))
				mContactAction = b.getInt("contact_action");
			if(b.containsKey("contact_id"))
				mContactId = b.getInt("contact_id");
		}
		
		
		/** Creates a dialog window */
		AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());	
		
		/** Inflating the layout file for this dialog window */
		mContactView = getActivity().getLayoutInflater().inflate(R.layout.contact,null);
		
		/** Click listener for the OK button of the dialog window */
		OnClickListener clickListener = new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				
				/** Setting up values to insert or delete a contact */
				ContentValues contentValues = new ContentValues();
				contentValues.put(ContactsDB.KEY_NAME, mTxtName.getText().toString());
				contentValues.put(ContactsDB.KEY_PHONE, mTxtPhone.getText().toString());
				
				
				switch(mContactAction){
					case CONTACT_ADD:
						/** Invokes content provider's insert operation */
						getActivity().getContentResolver().insert(ContactsProvider.CONTENT_URI, contentValues);
						break;
						
					case CONTACT_EDIT:
						/** Invokes content provider's update operation */
						Uri uri = ContactsProvider.CONTENT_URI;
						String pathSegment = Integer.toString(mContactId);
						uri = Uri.withAppendedPath(uri, pathSegment);						
						getActivity().getContentResolver().update(uri, contentValues, null, null);	
						break;
						
					case CONTACT_DEL:
						/** Invokes content provider's delete operation */
						uri = ContactsProvider.CONTENT_URI;
						pathSegment = Integer.toString(mContactId);
						uri = Uri.withAppendedPath(uri, pathSegment);						
						getActivity().getContentResolver().delete(uri, null, null);
				}				
				
				/** Restarting the MainActivity's loader to refresh the listview */
				getActivity().getSupportLoaderManager().restartLoader(0, null, (LoaderCallbacks<Cursor>)getActivity());				
			}
		};
		
		
		/** Changing the appearance of the dialog window based on the operation */
		switch(mContactAction){
			case CONTACT_ADD:
				dialogBuilder.setView(mContactView);
				dialogBuilder.setTitle("Add Contact");
				break;
			case CONTACT_EDIT:
				dialogBuilder.setView(mContactView);
				dialogBuilder.setTitle("Edit Contact");
				break;
			case CONTACT_DEL:
				dialogBuilder.setTitle("Delete Contact");
				dialogBuilder.setMessage("Are you sure to delete?");
				break;
				
		}
				
		dialogBuilder.setNegativeButton("Cancel", null);
		
		/** Setting click event handler for the OK button */
		dialogBuilder.setPositiveButton("OK", clickListener);
				
		return dialogBuilder.create();
	}


	/** A callback method invoked by the loader when initLoader() is called */
	@Override
	public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
		Bundle b = getArguments();
		
		/** Requesting for the contact name and phone to be edited */
		if(mContactAction==CONTACT_EDIT){
				Uri uri = ContactsProvider.CONTENT_URI;
				String pathSegment = Integer.toString(mContactId);
				uri = Uri.withAppendedPath(uri, pathSegment);
				return new CursorLoader(getActivity(), uri, null, null, null, null);
		}
		else
			return null;
	}
	
	/** A callback method, invoked after the requested content provider returned all the data */
	@Override
	public void onLoadFinished(Loader<Cursor> arg0, Cursor data) {
		/** populates Contact Name and Phone on edit operation */
		if(data.moveToFirst()){			
			mTxtName.setText(data.getString(1));
			mTxtPhone.setText(data.getString(2));
		}
		
	}

	@Override
	public void onLoaderReset(Loader<Cursor> arg0) {
	}

}
