package com.menor.easyfacebookconnect;

public enum PendingAction {
    NONE,
    POST_PHOTO_WALL,
    POST_PHOTO_PAGE,
    POST_STATUS_WALL,
    POST_STATUS_PAGE
}
