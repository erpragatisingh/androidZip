package com.example.webbrowser;

import android.os.Message;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebView.FindListener;

public class WebChrome extends WebChromeClient
{
	
		WebView wb;
	public WebChrome(WebView wb1)
	{
		wb=wb1;
	}
	
	WebView w1=(WebView)wb.findViewById(R.id.webView1);
	
	public boolean onCreateWindow(WebView wb1, boolean isdialog,boolean isUserGesture, Message resultMsg)
	{
		// TODO Auto-generated method stub
		return true;
	}

}