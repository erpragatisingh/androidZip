package com.example.webbrowser;

import android.os.Bundle;
import android.os.Handler;
import android.provider.Browser;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipData.Item;

public class MainActivity extends Activity implements OnClickListener
{
	public static ImageView go;
	public static EditText edt1;
	public static WebView wb;
	public static ProgressBar prgrs;
	
 
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		prgrs=(ProgressBar)findViewById(R.id.progressBar1);
		go=(ImageView)findViewById(R.id.imgvw);
		wb=(WebView)findViewById(R.id.webView1);
		edt1=(EditText)findViewById(R.id.edttext);
		
		go.setOnClickListener(this);
		 wb.getSettings().setJavaScriptEnabled(true);
		 	
		 new Handler().postDelayed(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
 				/*Code to display Progress*/
		 wb.setWebChromeClient(new WebChromeClient() {
		   public void onProgressChanged(WebView view, int progress) {
		     // Activities and WebViews measure progress with different scales.
		     // The progress meter will automatically disappear when we reach 100%
			   
			   if(progress<100)
			   {
				   prgrs.setVisibility(ProgressBar.VISIBLE);
			   }
			   else
			   {
				   prgrs.setVisibility(ProgressBar.INVISIBLE);
			   }
		     prgrs.setProgress(progress);	//max value of progress is 100
		   }
		 });
		 wb.setWebViewClient(new WebViewClient() {
		   public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
		     Toast.makeText(getApplicationContext(), "Oh no! " + description, Toast.LENGTH_SHORT).show();
		   }
		 });
		 				/*Progress coding finish*/
		 
		 /*Code to enable javascript*/
		 
		WebSettings ws=wb.getSettings();
		ws.setJavaScriptEnabled(true);
		
	/**********************************************/	
		
		wb.pageDown(true);
		wb.pageDown(true);
		
	/************Code to enable zoom controls*************/	
        ws.setBuiltInZoomControls(true);
        ws.setUseWideViewPort(true);
	/*****************************************/	
		
        wb.setWebViewClient(new HelloWebViewClient());
			}
		}, 1);
	}
	
	private class HelloWebViewClient extends WebViewClient {
	    @Override
	    public boolean shouldOverrideUrlLoading(WebView view, String url)
	    {
	        view.loadUrl(url);
	        return true;
	    }
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		switch(v.getId())
		{
			case R.id.imgvw:
				if(edt1.getText().toString().contains("http://"))
				{
					wb.loadUrl(edt1.getText().toString());
				}
				else
				{
					wb.loadUrl("http://"+edt1.getText().toString());
				}
				break;
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) 
	{
		// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				switch(item.getItemId())
				{
					case R.id.forward:
						wb.canGoForward();
						wb.goForward();
						edt1.setText(wb.getUrl());
						break;
						
					case R.id.refresh:
						wb.reload();
						break;
						
					case R.id.exit:
						finish();
						break;
					case R.id.newwindow:
							Toast.makeText(getApplicationContext(), "Helo", Toast.LENGTH_SHORT).show();
						break;
						
					case R.id.addbookmark:
						Browser.saveBookmark(this, wb.getTitle(), wb.getUrl());
						break;
				}
		return super.onMenuItemSelected(featureId, item);
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if(wb.getUrl()==null)
		{
			super.onBackPressed();
		}
		else
		{
		wb.canGoBack();
		wb.goBack();
		edt1.setText(wb.getUrl());
		}
	}
	
}
