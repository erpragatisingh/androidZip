package njlj.kh;

import java.security.spec.MGF1ParameterSpec;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class games extends Activity{
	
	Button b1, b2;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.games);
		
		b1=(Button)findViewById(R.id.sud);
		b2=(Button)findViewById(R.id.magg);
		
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
			}
		});
		
		b2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent i15 = new Intent(getApplicationContext(),magic_strtng.class);
				startActivity(i15);
				
			}
		});
	}

}
