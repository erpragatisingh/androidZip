package njlj.kh;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class video_list extends Activity{
	
ListView ls;
private NotificationManager mNotificationManager;
private int SIMPLE_NOTFICATION_ID;
Context con;

ArrayList<video_info> list=new ArrayList<video_info>();

	public void onCreate(Bundle b){
		super.onCreate(b);
		setContentView(R.layout.video_list);
		
		ls=(ListView)findViewById(R.id.listView1);
		 
        initializeList();
	}
	
	private class videoSelectionListener implements OnItemClickListener
	{

		@Override
		public void onItemClick(AdapterView<?> parent, View clickedView, int index, long id) {
			video_info info=list.get(index);
			String uri=MediaStore.Video.Media.EXTERNAL_CONTENT_URI+"/"+info.getId();
			Toast.makeText(getApplicationContext(),uri,100).show();
			Log.i("mvp", "starting activity to play video...");
			Intent intent=new Intent(getApplicationContext(),PlayingVideo2.class);
			intent.putExtra("uri", uri);
			intent.putExtra("title", info.getTitle());
			intent.putExtra("duration",info.getDuration());
			startActivityForResult(intent,1);
		}
		
	}

	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode==1)
		{
			Process.killProcess(Process.myPid());
			
			
		}
	}


	private void initializeList()
	{
		 ContentResolver resolver=getContentResolver();
		 String projection[]={MediaStore.Video.Media._ID,MediaStore.Video.Media.DISPLAY_NAME,MediaStore.Video.Media.DURATION};
		 Cursor cursor= resolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, null);
		 while(cursor.moveToNext())
		 {
			int id=cursor.getInt(0);
			String title=cursor.getString(1);
			int dur=cursor.getInt(2);
			list.add(new video_info(id,title,dur));
			
		 }
		 cursor.close();
		 ArrayAdapter<video_info> adapter=new MyArrayAdapter(getApplicationContext(),R.layout.dummy_for_list,list);
		 ls.setAdapter(adapter);
		 ls.setOnItemClickListener(new videoSelectionListener());
		 
	}
	  
    @Override
    public void onDestroy(){
    	super.onDestroy();
    	mNotificationManager.cancel(SIMPLE_NOTFICATION_ID);
    }

	private class MyArrayAdapter extends ArrayAdapter<video_info>
	{
		int layout;
		
		public MyArrayAdapter(Context context, int layoutId,
				List<video_info> objects) {
			super(context, layoutId, objects);
			layout=layoutId;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			RelativeLayout newView;
			video_info detail= list.get(position);
			if (convertView==null)
			{
				newView=new RelativeLayout(getContext());
				LayoutInflater  li=(LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE) ;
				li.inflate(layout, newView, true);
			}
			else
			{
				newView=(RelativeLayout)convertView;
				
			}
			TextView title=(TextView)newView.findViewById(R.id.t11);
			title.setText(detail.getTitle());
			TextView duration=(TextView)newView.findViewById(R.id.t22);
			duration.setText(detail.getDisplayDuration());
			
			
			return newView;
		}
		
	}
	
	
}
