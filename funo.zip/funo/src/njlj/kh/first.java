package njlj.kh;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.BounceInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class first extends Activity{
	
	Button b1,b2,b3,b4;
	TextView t1, t2, t3, t4;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.first);
		
		LinearLayout l3 = (LinearLayout)findViewById(R.id.linearLayout3);
		LinearLayout l4 = (LinearLayout)findViewById(R.id.linearLayout4);
		LinearLayout l5 = (LinearLayout)findViewById(R.id.linearLayout5);
		LinearLayout l6 = (LinearLayout)findViewById(R.id.linearLayout6);
		
		b1=(Button)findViewById(R.id.media);
		b2=(Button)findViewById(R.id.blue);
		b3=(Button)findViewById(R.id.video);
		b4=(Button)findViewById(R.id.game);
		
		t1=(TextView)findViewById(R.id.med);
		t2=(TextView)findViewById(R.id.bl);
		t3=(TextView)findViewById(R.id.vid);
		t4=(TextView)findViewById(R.id.gam);
		
		TranslateAnimation a1 = new TranslateAnimation(-200, 0, -200, 0);
        a1.setInterpolator(new LinearInterpolator());
        a1.setDuration(1000);
        l3.clearAnimation();
        l3.startAnimation(a1);
        
        TranslateAnimation a2 = new TranslateAnimation(200, 0, -200, 0);
        a2.setInterpolator(new LinearInterpolator());
        a2.setDuration(1000);
        l4.clearAnimation();
        l4.startAnimation(a2);
        
        TranslateAnimation a3 = new TranslateAnimation(-200, 0, -200, 0);
        a3.setInterpolator(new LinearInterpolator());
        a3.setDuration(1000);
        l5.clearAnimation();
        l5.startAnimation(a3);
        
        TranslateAnimation a4 = new TranslateAnimation(200, 0, -200, 0);
        a4.setInterpolator(new LinearInterpolator());
        a4.setDuration(1000);
        l6.clearAnimation();
        l6.startAnimation(a4);
		
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent i = new Intent(getApplicationContext(),media.class);
				startActivity(i);
			}
		});
		
		b2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent i1 = new Intent(getApplicationContext(),bluetooth.class);
				startActivity(i1);
			}
		});
		
		b3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent i2 = new Intent(getApplicationContext(),video.class);
				startActivity(i2);

				
			}
		});
		
		b4.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent i3 = new Intent(getApplicationContext(),games.class);
				startActivity(i3);

				
			}
		});
	}

}
