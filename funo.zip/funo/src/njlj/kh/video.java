package njlj.kh;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class video extends Activity{
	
	ImageView i1;
	LinearLayout l1;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.video);
		
		l1=(LinearLayout)findViewById(R.id.l11);
		i1=(ImageView)findViewById(R.id.imageView1);
		
		ScaleAnimation a1 = new ScaleAnimation(4, 1,3,1);
		a1.setInterpolator(new LinearInterpolator());
		a1.setDuration(3000);
		i1.clearAnimation();
		i1.startAnimation(a1);
		
		 TimerTask tt = new TimerTask() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					
					Intent i = new Intent(video.this,video_list.class);
					startActivity(i);
					finish();
					
				}
			};
			
			Timer tone = new Timer();
			tone.schedule(tt,6000);
			
			
	    }
		
		
	}


