package njlj.kh;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.TextView;

public class magic_strtng extends Activity{
	
	Handler h=new Handler();
	TextView t1,t2;
	ImageView im;
	int i=1;
	
	public void onCreate(Bundle b){
	
		super.onCreate(b);
		setContentView(R.layout.mgic_strtng);
		
	    t1=(TextView)findViewById(R.id.textView1);
	    t2=(TextView)findViewById(R.id.textView2);
	    t2.setVisibility(TextView.INVISIBLE);
		im=(ImageView)findViewById(R.id.imageView1);
		
	    hell();	
	}
	
	public void hell(){
		
	Runnable chr=new Runnable() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
		
			if(i==1){
		    
				im.setVisibility(ImageView.INVISIBLE);
		 	    t1.setVisibility(TextView.INVISIBLE);
			    t2.setVisibility(TextView.VISIBLE);
			    
			    t2.setText("Select a number between 1 to 99 \n\n " +
			    		"" +"7 cards will be shown to you\n"+
			    		"" +"see the cards and click on yes or no \n"+
			    		""+"according to their exitence in card\n"+
			    		""+"and wait for the Magic...."
			    );
		     }
		
			i++;
		     
			if(i==4)
			{
				Intent i=new Intent(getApplicationContext(), magicc.class);
				startActivity(i);
			    finish();
		    
			}	
			
		     hell();
		}
		
	};
		h.postDelayed(chr,3000);
		}
}
