package njlj.kh;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.animation.BounceInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;

public class FunoActivity extends Activity {
	
	ImageView i1;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        i1=(ImageView)findViewById(R.id.imageButton1);
         
        
        
        fade();
        
        TimerTask tt = new TimerTask() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
				Intent i = new Intent(FunoActivity.this,first.class);
				startActivity(i);
				finish();
				
			}
		};
		
		Timer tone = new Timer();
		tone.schedule(tt,6000);
		
		
    }
    
    public void fade()
    {
    	TranslateAnimation a1 = new TranslateAnimation(0,0,-400,0);
    	a1.setInterpolator(new BounceInterpolator());
    	a1.setDuration(4000);
    	i1.startAnimation(a1);
    }
}