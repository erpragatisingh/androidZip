package njlj.kh;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.media.MediaPlayer.OnCompletionListener;
public class PlayingVideo2 extends Activity {
	Button playlist,main_menu; 
	ImageButton v_play,v_next,v_prev;
	ProgressBar videoProgress;
	VideoView vView; 
	int play_pause=0;
	TextView t1,t2,t3;
	Handler h=new Handler();
	private int seekForwardTime = 5000; 
	private int seekBackwardTime = 5000;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			 setContentView(R.layout.video_main);
			 
			 vView=(VideoView)findViewById(R.id.videoView1);
			 	t1=(TextView)findViewById(R.id.textView2);
			 	t2=(TextView)findViewById(R.id.textView3);
			 	t3=(TextView)findViewById(R.id.textView1);
			 	
			videoProgress=(ProgressBar)findViewById(R.id.progressBar1);
			videoProgress.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
				ProgressBar vvv=(ProgressBar)v;
					vView.seekTo(vvv.getProgress());
				}
			});
			v_play=(ImageButton)findViewById(R.id.v_play);
			v_prev=(ImageButton)findViewById(R.id.v_prev);
			v_next=(ImageButton)findViewById(R.id.v_next);
			v_play.setBackgroundResource(R.drawable.btn_pause);
			v_play.setOnClickListener(new PauseAndResumeListener());
			playlist=(Button)findViewById(R.id.playlist);
			main_menu=(Button)findViewById(R.id.menuu);
			playlist.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					Log.i("mvp", "returning to playlist...");
					setResult(0);
					finish();
				}
				
				
			});

			main_menu.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					Log.i("mvp", "returning to playlist...");
					setResult(0);
					Intent i=new Intent(getApplicationContext(),first.class);
					startActivity(i);
				    finish();
				}
				
				
			});

			
			v_next.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int currentPosition = vView.getCurrentPosition();
					// check if seekForward time is lesser than song duration
					if(currentPosition + seekForwardTime <= vView.getDuration()){
						// forward song
						vView.seekTo(currentPosition + seekForwardTime);
					}else{
						// forward to end position
						vView.seekTo(vView.getDuration());
					}	
				}
			});
			v_prev.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int currentPosition = vView.getCurrentPosition();
					// check if seekBackward time is greater than 0 sec
					if(currentPosition - seekBackwardTime >= 0){
						// forward song
						vView.seekTo(currentPosition - seekBackwardTime);
					}else{
						// backward to starting position
						vView.seekTo(0);
					}
					
				}
			});
			
			
			Intent intent=getIntent();
			String uri=intent.getStringExtra("uri");
			t2.setText(dur(intent.getIntExtra("duration", 1000)));
			String title=intent.getStringExtra("title");
			t3.setText(title);
			Log.i("mvp", "Player Activity Started, obtaining media player...");
			videoProgress.setMax(intent.getIntExtra("duration", 1000));
			playVideo(uri);
			
			
			
	}

	

	


	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		vView.stopPlayback();
		play_pause=1;
	}






	private class PauseAndResumeListener implements OnClickListener
	{

		@Override
		public void onClick(View v) {
			switch(play_pause){
			case 0:
			Toast.makeText(getApplicationContext(), "play",100).show();	
				vView.start();
				update();
				v_play.setBackgroundResource(R.drawable.btn_pause);
				play_pause=1;
			    break;
			case 1:	Toast.makeText(getApplicationContext(), "pause",100).show();
				vView.pause();
				v_play.setBackgroundResource(R.drawable.btn_play);
				play_pause=0;
				break;
			
		}
}
	}
	
	

	// converting text to duration format
	
		  public String dur(int dur){
		    	int min=0,sec=0;
		    	int time=dur/1000;
		    	min=time/60;
		    	sec=time%60;
		    	String min_s=min+"";
		    	String sec_s=sec+"";
		    	
		    	if(min<10){
		    		min_s="0"+min;
		    	}
		    	if(sec<10){
		    		sec_s="0"+sec;
		    	}
		    	
		    	return (min_s+":"+sec_s);
		    }
	
	
	
    public void update()
    {
    	
    	videoProgress.setProgress(vView.getCurrentPosition());
    	t1.setText(dur(vView.getCurrentPosition()));
    	if(vView.isPlaying())
    	{
    		Runnable notification=new Runnable(){
    			public void run(){
    				update();
    			}
    		};
    	h.postDelayed(notification, 1000);
    		}
    	else{
    		play_pause=0;
    		v_play.setBackgroundResource(R.drawable.btn_play);
    		
    	}
    	
    	}

	
	
	
	private void playVideo(String songUri) {
		Uri uri=Uri.parse(songUri);
		
		if (vView.isPlaying() )
			{
			vView.stopPlayback();
			}
		
		vView.setVideoURI(uri);
		vView.start();
		play_pause=0;
		update();
		vView.setOnCompletionListener(new OnCompletionListener() {
			
			@Override
			public void onCompletion(MediaPlayer mp) {
				play_pause=1;
				Toast.makeText(getApplicationContext(),"Video Completed.", Toast.LENGTH_LONG).show();
			}
		});
		
		Log.i("mvp", "player started...");
		}

	
	
}
