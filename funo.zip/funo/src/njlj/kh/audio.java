package njlj.kh;

import java.io.File;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class audio extends Activity{
	
	Button b11,b12,b13,b14;
	String str;
	MediaPlayer m1;
	MediaRecorder m2;
	
	

	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.audio);
        
        b11=(Button)findViewById(R.id.button11);
        b12=(Button)findViewById(R.id.button12);
        b13=(Button)findViewById(R.id.button13);
        b14=(Button)findViewById(R.id.button14);
        
        str=Environment.getExternalStorageDirectory()+"/recordaudio.3gpp";
        
        b11.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				try
				{
				beginrecording();
				
				}
				
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		});
        
        b12.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				stoprecording();
				
			}
		});
        
        b13.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				try 
				{
					playrecording();
				} 
				
				catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
        
        b14.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				stopplayingrecording();
			}
		});
    }
    
    public void beginrecording() throws Exception
    {
    	
    		killmediarecorder();
    		
    		File outfile= new File(str);
    		
    		if(outfile.exists())
    		{
    			outfile.delete();
    		}
    		
    		m2=new MediaRecorder();
    		m2.setAudioSource(MediaRecorder.AudioSource.MIC);
    		m2.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
    		m2.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
    		m2.setOutputFile(str);
    		m2.prepare();
    		m2.start();
    		
    	
    	
    }
    
    public void stoprecording()
    {
    	if(m2!= null)
    	{
    		m2.stop();
    	}
    }
    
    public void killmediaplayer()
    {
    	if(m1!=null)
    	{
    		try
    		{
    			m1.release();
    		}
    		catch(Exception e)
    		{
    			e.printStackTrace();
    		}
    	}
    	
    }
   
    public void killmediarecorder()
    {
    	if(m2!= null)
    	{
    		m2.release();
    	}
    }
    
    public void playrecording() throws Exception
    {
    	killmediaplayer();
    	m1 = new MediaPlayer();
    	
    	m1.setDataSource(str);
    	m1.prepare();
    	m1.start();
    	
    }
    
    public void stopplayingrecording()
    {
    	if(m1!= null)
    		m1.stop();
    	
    }
    
    
    protected void onDestroy()
    {
    	super.onDestroy();
    	killmediaplayer();
    	killmediarecorder();
    }
    
}
