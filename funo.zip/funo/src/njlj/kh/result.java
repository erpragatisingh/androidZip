package njlj.kh;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class result extends Activity{

	Button b1,b2;
	TextView t1;
	
	
	public void onCreate(Bundle b){
		super.onCreate(b);
		setContentView(R.layout.result);
		
		
		t1=(TextView)findViewById(R.id.textView1);
		b1=(Button)findViewById(R.id.button1);
		b2=(Button)findViewById(R.id.button2);
		
		Intent i=getIntent();
		String str=i.getStringExtra("result");
		t1.setText(str);
		
		b1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent i=new Intent(getApplicationContext(), magicc.class);
				startActivity(i);
			    finish();
			    
	}
		});
		
		b2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=new Intent(getApplicationContext(),first.class);
				startActivity(i);
			    finish();
	
			}
		});
	}
}
