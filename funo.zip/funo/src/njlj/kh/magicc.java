package njlj.kh;

import java.util.Random;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
//import android.widget.RelativeLayout;
import android.widget.TextView;
//import android.widget.Toast;

public class magicc extends Activity {
	Random r=new Random();
	 Integer[] a1={1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45,47,49,51,53,55,57,59,61,63,65,67,69,71,73,75,77,79,81,83,85,87,89,91,93,95,97,99};
	 Integer[] a2={2,3,6,7,10,11,14,15,18,19,22,23,26,27,30,31,34,35,38,39,42,43,46,47,50,51,54,55,58,59,62,63,66,67,70,71,74,75,78,79,82,83,86,87,90,91,94,95,98,99};
	 Integer[] a4={4,5,6,7,12,13,14,15,20,21,22,23,28,29,30,31,36,37,38,39,44,45,46,47,52,53,54,55,60,61,62,63,68,69,70,71,76,77,78,79,84,85,86,87,92,93,94,95};
	 Integer[] a8={8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31,40,41,42,43,44,45,46,47,56,57,58,59,60,61,62,63,72,73,74,75,76,77,78,79,80,81,89,90,91,92,93,94,95};
	 Integer[] a32={32,33,34,35,36,37,38,39,40,41,42,43,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,96,97,98,99};
	 Integer[] a16={16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95};
	 Integer[] a64={64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99};
	 
	 int num=0;
	 int cards=1;
	 ImageButton b1,b2;
	 GridView gv;
	 LinearLayout ln;
	 TextView t1;
	 private NotificationManager mNotificationManager;
	 private int SIMPLE_NOTFICATION_ID;
	 Context con;

	 ArrayAdapter<Integer> ap1,ap2,ap4,ap8,ap16,ap32,ap64;
	 
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
     
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.mg_main);
    	
        b1=(ImageButton)findViewById(R.id.button1);
        b2=(ImageButton)findViewById(R.id.button2);
        gv=(GridView)findViewById(R.id.gridView1);
        t1=(TextView)findViewById(R.id.textView1);
        ln=(LinearLayout)findViewById(R.id.linearLayout2);
        
        t1.setText("Card 1");
        
       
        ln.setBackgroundResource(R.drawable.blue);
        
        ap1=new  ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,a1);
        ap2=new  ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,a2);
        ap4=new  ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,a4);
        ap8=new  ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,a8);
        ap16=new  ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,a16);
        ap32=new  ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,a32);
        ap64=new  ArrayAdapter<Integer>(this,android.R.layout.simple_list_item_1,a64);
       
        gv.setAdapter(ap1);
        
        b1.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			
			switch(cards)
			{
			case 1:
					num=num+1;cards=2;
					t1.setText("Card 2");
					ln.setBackgroundResource(R.drawable.green);
					gv.setAdapter(ap2);
					
				     break;
			
			case 2:
					num=num+2;
					gv.setAdapter(ap4);
					cards=3;
					t1.setText("Card 3");
					ln.setBackgroundResource(R.drawable.grey);
					
					break;
			
			case 3:
					num=num+4;
					gv.setAdapter(ap8);
					cards=4;
					t1.setText("Card 4");
					ln.setBackgroundResource(R.drawable.orange);
					
					break;
					
			case 4:
					num=num+8;
					gv.setAdapter(ap16);
					cards=5;
					t1.setText("Card 5");
					ln.setBackgroundResource(R.drawable.purple);
				
					break;
					
			case 5:
					num=num+16;
					gv.setAdapter(ap32);
					cards=6;
					t1.setText("Card 6");
					ln.setBackgroundResource(R.drawable.red);
				
					break;
			
			case 6:
					num=num+32;
					gv.setAdapter(ap64);
					cards=7;
					t1.setText("Card 7");
					ln.setBackgroundResource(R.drawable.blue);
				
					break;
			
			case 7:
					num=num+64;
					result();
			
					break;
			}
		}
	});
        
       b2.setOnClickListener(new OnClickListener() {
   		
   		@Override
   		public void onClick(View v) {
   			// TODO Auto-generated method stub
   		
   			switch(cards)
   			{
   			
   			case 1:
   					gv.setAdapter(ap2);
   					cards=2;
   					t1.setText("Card 2");
   					ln.setBackgroundResource(R.drawable.green);
   				     
   					break;
   			
   			case 2:
   					gv.setAdapter(ap4);
   					cards=3;
   					t1.setText("Card 3");
   					ln.setBackgroundResource(R.drawable.grey);
   			
   					break;
   			
   			case 3:
   					gv.setAdapter(ap8);
   					cards=4;
   					t1.setText("Card 4");
   					ln.setBackgroundResource(R.drawable.orange);
   				 
   					break;
   			
   			case 4:
   					gv.setAdapter(ap16);
   					cards=5;
   					t1.setText("Card 5");
   					ln.setBackgroundResource(R.drawable.purple);
   				
   					break;
   					
   			case 5:
   					gv.setAdapter(ap32);
   					cards=6;
   					t1.setText("Card 6");
   					ln.setBackgroundResource(R.drawable.red);
   				
   					break;
   					
   			case 6:
   					gv.setAdapter(ap64);
   					cards=7;
   					t1.setText("Card 7");
   					ln.setBackgroundResource(R.drawable.blue);
   				
   					break;
   					
   			case 7:
   					result();
				
   					break;
   			}
   		}
   	});

    }
    public void result(){
    	Intent i=new Intent(getApplicationContext(), result.class);
    	i.putExtra("result",num+"");
    	startActivity(i);
    	finish();
    	
    	
    }
    
    @Override
    public void onDestroy(){
    	super.onDestroy();
    	mNotificationManager.cancel(SIMPLE_NOTFICATION_ID);
    }
    
}