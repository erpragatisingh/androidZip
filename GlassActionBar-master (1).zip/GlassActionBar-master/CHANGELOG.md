Change Log
=======================================

Version 0.3.0 *(2013-10-06)*
----------------------------

 * Revamped project structure, now all AB types (stock, sherlock, compat) are under the same repo. Stock AB support in in the main library, whereas other types are in the "extras" folder.

Version 0.2.1 *(2013-07-15)*
----------------------------

 * Added support for changing content (through the "invalidate" method).
 * Handle non-scrollable content in a more efficient manner.
 * Fixed bug which prevented transparent content from being blurred properly.
 * Many performance optimizations.
 * Added possibility of changing the gaussian blur params ("radius" and "downsampling").
 * Added support for maven and gradle builds.

Version 0.1.1 *(2013-06-23)*
----------------------------
* Important performance optimizations. 

Version 0.1.0 *(2013-06-23)*
----------------------------
Initial release.
