package com.android.example.contact.data;

public class ContactItem {
	public long mId;
	public long mContactId;
	public String mDisplayName;
	public String mPhone;
}