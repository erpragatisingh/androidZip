//
//  main.m
//  FourInARow
//
//  Created by John Rees on 08/12/2010.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"FourInARowAppDelegate");
	[pool release];
	return retVal;
}
