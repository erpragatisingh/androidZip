//
//  RootViewController.h
//  FourInARow
//
//  Created by John Rees on 08/12/2010.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
