#import "cocos2d.h"

@interface GameLayer : CCLayer
{
}

+(id) scene;

@end
