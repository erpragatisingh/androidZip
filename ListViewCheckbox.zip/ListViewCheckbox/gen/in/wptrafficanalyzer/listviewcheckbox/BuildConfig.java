/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.listviewcheckbox;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}