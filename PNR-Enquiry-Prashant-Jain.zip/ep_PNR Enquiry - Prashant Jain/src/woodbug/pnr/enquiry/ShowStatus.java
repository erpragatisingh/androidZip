package woodbug.pnr.enquiry;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class ShowStatus extends Activity {

	TextView result;
	StringBuffer status, temp,final_status;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.status);
		status = new StringBuffer();
		temp = new StringBuffer();
		result = (TextView) findViewById(R.id.result);
		Intent intent = getIntent();

		try {
			temp.append(intent.getStringExtra("json"));

			for (int i = 0; i < temp.length(); i++) {
				if (temp.charAt(i) == '\\' && temp.charAt(i + 1) == 'u'
						&& temp.charAt(i + 2) == '0'
						&& temp.charAt(i + 3) == '0'
						&& temp.charAt(i + 4) == '0'
						&& temp.charAt(i + 5) == 'a')
					temp.delete(i, i + 6);
			}

			for (int i = 0; i < temp.length(); i++) {
				if (temp.charAt(i) == '<') {
					if (status.charAt(status.length() - 1) != '\n')
						status.append('\n');
					while (i < temp.length() && temp.charAt(i) != '>') {
						i++;
					}
				}
				else if (temp.charAt(i) == '(') {
					while (i < temp.length() && temp.charAt(i) != ')') {
						i++;
					}
				} 
					else {
				
					status.append(temp.charAt(i));
				}
			}
			
			ArrayList<StringBuffer> al = new ArrayList<StringBuffer>();
			int i = 0;
			while (status.charAt(i) != '\n')
				i++;
			i++;
			for (int count = 0; count < 8; count++) {

				temp = new StringBuffer();
				for (; status.charAt(i) != '\n'; i++) {
                 temp.append(status.charAt(i));
				}i++;
				al.add(temp);
			}
			for (int count = 0; count < 8; count++) {

				temp = new StringBuffer();
				for (; status.charAt(i) != '\n'; i++) {
                 temp.append(status.charAt(i));
				}i++;
				al.get(count).append(" - ").append(temp);
			}
			final_status=new StringBuffer();
			for(int k=0;k<al.size();k++)
				final_status.append('\n').append(al.get(k));
			
			
				al = new ArrayList<StringBuffer>();
				for (int count = 0; count < 4; count++) {

					temp = new StringBuffer();
					for (; status.charAt(i) != '\n'; i++) {
						temp.append(status.charAt(i));
					}
					i++;
					al.add(temp);
				}
				al.remove(2);

				while (status.charAt(i)=='P') {
					final_status.append('\n');
				for (int count = 0; count < 3; count++) {

					temp = new StringBuffer();
					for (; status.charAt(i) != '\n'; i++) {
						temp.append(status.charAt(i));
					}
					i++;
					final_status.append('\n').append(al.get(count)+" - "+temp);
				}
			}
				
			final_status.append("\n\n").append(status.substring(i, status.length()));
			

			if (final_status.equals(""))
				throw new Exception();
			else
				result.setText(final_status);
		} catch (Exception ignore) {
			Toast.makeText(getApplicationContext(),
					"Invalid Result. check PNR number..", Toast.LENGTH_LONG)
					.show();
		}
	}

}