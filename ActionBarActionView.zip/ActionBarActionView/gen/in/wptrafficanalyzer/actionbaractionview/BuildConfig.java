/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.actionbaractionview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}