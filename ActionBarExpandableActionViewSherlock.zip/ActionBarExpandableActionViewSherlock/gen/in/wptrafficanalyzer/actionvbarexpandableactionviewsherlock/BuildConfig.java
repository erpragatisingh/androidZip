/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.actionvbarexpandableactionviewsherlock;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}