/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.customedittextdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}