/*
 * Climbers
 * https://github.com/haqu/climbers
 *
 * Copyright (c) 2011 Sergey Tikhonov
 *
 */

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
