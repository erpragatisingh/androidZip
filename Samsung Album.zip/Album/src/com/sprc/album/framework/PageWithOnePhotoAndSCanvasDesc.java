/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import com.sprc.album.R;
import com.sprc.album.framework.TitleView.TitleViewMode;

/**
 * Class which represents first page of album.
 */
public class PageWithOnePhotoAndSCanvasDesc extends LinearLayout {

	/**
	 * Control which represents title description.
	 */
	private TitleView mTitleAlbum;
	/** Title photo frame. */
	private PhotoFrameView mTitlePhoto;

	/**
	 * Listener which listen than photo was clicked.
	 */
	private OnTitlePhotoPageClickListner mOnTitlePhotoPageClickListner;

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * 
	 * @param pEditMode
	 *            mode of title view
	 */
	public PageWithOnePhotoAndSCanvasDesc(final Context pContext, TitleViewMode pEditMode) {
		super(pContext);
		initCustomView(pContext, pEditMode);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            pContext of application
	 * @param pArtts
	 *            attributes
	 */
	public PageWithOnePhotoAndSCanvasDesc(final Context pContext, final AttributeSet pArtts) {
		super(pContext, pArtts);
		initCustomView(pContext, TitleViewMode.ANIM_INSCRIPTION);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            pContext of application
	 * @param pArtts
	 *            attributes
	 * @param pDefStyle
	 *            definition of style
	 */
	public PageWithOnePhotoAndSCanvasDesc(final Context pContext, final AttributeSet pArtts, final int pDefStyle) {
		super(pContext, pArtts, pDefStyle);
		initCustomView(pContext, TitleViewMode.ANIM_INSCRIPTION);
	}

	/**
	 * Initialize view.
	 * 
	 * @param pContext
	 *            pContext for this view
	 * @param pEditMode
	 *            mode of title view
	 */
	private void initCustomView(final Context pContext, TitleViewMode pEditMode) {
		View.inflate(pContext, R.layout.album_page_title_page, this);
		mTitlePhoto = (PhotoFrameView) findViewById(R.id.title_photo);
		mTitlePhoto.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (mOnTitlePhotoPageClickListner != null) {
					mOnTitlePhotoPageClickListner.onTitlePhotoClick();
				}
			}
		});
		mTitleAlbum = (TitleView) findViewById(R.id.title_view);
		mTitleAlbum.setModeType(pEditMode);

	}

	/**
	 * Sets path to file for TitleAlbum.
	 * 
	 * @param filePath
	 *            path to file
	 */
	public void setFilePath(String filePath) {
		mTitleAlbum.setFilePath(filePath);
	}

	/**
	 * Sets photo in frame.
	 * 
	 * @param pPhoto
	 *            photo which will be set in frame
	 */
	public void setTitlePhoto(final Bitmap pPhoto) {
		mTitlePhoto.setPhoto(pPhoto);
	}

	/**
	 * Sets photo in frame.
	 * 
	 * @param pResPhoto
	 *            resources to photo which will be set in frame
	 */
	public void setTitlePhoto(final int pResPhoto) {
		mTitlePhoto.setPhoto(pResPhoto);
	}

	/**
	 * Save file form title view.
	 * 
	 * @return path to save file.
	 */
	public String saveAsFile() {
		return mTitleAlbum.saveAsFile();
	}

	/**
	 * Sets listener for title photo.
	 * 
	 * @param pOnTitlePhotoPageClickListner
	 *            photo title click listener
	 */
	public void setOnTitlePhotoPageListner(OnTitlePhotoPageClickListner pOnTitlePhotoPageClickListner) {
		mOnTitlePhotoPageClickListner = pOnTitlePhotoPageClickListner;
	}

	/**
	 * Interface which is used to catch event when title photo is clicked.
	 */
	public interface OnTitlePhotoPageClickListner {
		/**
		 * Called when title photo is clicked.
		 */
		void onTitlePhotoClick();
	}
}
