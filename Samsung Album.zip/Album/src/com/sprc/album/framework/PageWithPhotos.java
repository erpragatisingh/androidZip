/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import java.util.List;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import com.sprc.album.R;
import com.sprc.album.db.data.Photo;

/**
 * Class which should be parent for all pages with photo which are inside album.
 */
public class PageWithPhotos extends LinearLayout {

	/** Number of photo equals 1. */
	public static final int COUNT_PHOTO_ONE = 1;
	/** Number of photo equals 2. */
	public static final int COUNT_PHOTO_TWO = 2;
	/** Number of photo equals 3. */
	public static final int COUNT_PHOTO_THREE = 3;

	/** Photo frame. */
	private final PhotoFrameView[] mPhotoFramesView;

	/**
	 * Number of photo.
	 */
	private final int mPhotoCount;

	/**
	 * Listener which calls method when photo is clicked.
	 */
	private OnPhotosClickListener mOnPhotosClickListener;

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pPhotoCount
	 *            number of photo
	 */
	public PageWithPhotos(final Context pContext, int pPhotoCount) {
		super(pContext);
		mPhotoCount = pPhotoCount;
		mPhotoFramesView = new PhotoFrameView[mPhotoCount];
		initCustomView(pContext);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pArtts
	 *            attributes
	 */
	public PageWithPhotos(final Context pContext, final AttributeSet pArtts) {
		super(pContext, pArtts);

		final TypedArray typedArray = pContext.obtainStyledAttributes(pArtts, R.styleable.AlbumsAttributes, 0, 0);
		mPhotoCount = typedArray.getInt(R.styleable.AlbumsAttributes_photo_count, 1);
		mPhotoFramesView = new PhotoFrameView[mPhotoCount];
		initCustomView(pContext);
		typedArray.recycle();
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pArtts
	 *            attributes
	 * @param pDefStyle
	 *            definition of style
	 */
	public PageWithPhotos(final Context pContext, final AttributeSet pArtts, final int pDefStyle) {
		super(pContext, pArtts, pDefStyle);

		final TypedArray typedArray = pContext.obtainStyledAttributes(pArtts, R.styleable.AlbumsAttributes, pDefStyle,
				0);
		mPhotoCount = typedArray.getInt(R.styleable.AlbumsAttributes_photo_count, 1);
		mPhotoFramesView = new PhotoFrameView[mPhotoCount];
		initCustomView(pContext);

	}

	/**
	 * Sets photo at index.
	 * 
	 * @param pPhoto
	 *            photo which will be set as photo
	 * @param pIndex
	 *            index index of photo <b> if will be greater than number of photo this method throws exception</b>
	 */
	public void setPhotoAt(final Bitmap pPhoto, int pIndex) {
		if (pPhoto == null) {
			throw new IllegalArgumentException("Bitmap can not be null!");
		}
		if (pIndex >= mPhotoCount) {
			throw new IndexOutOfBoundsException("There shoul be " + mPhotoCount + "  images!!!");
		}
		mPhotoFramesView[pIndex].setPhoto(pPhoto);
	}

	/**
	 * Sets photo at index.
	 * 
	 * @param pResPhoto
	 *            Resources to photo which will be set as photo
	 * @param pIndex
	 *            index index of photo <b> if will be greater than number of photo this method throws exception</b>
	 */
	public void setPhotoAt(final int pResPhoto, int pIndex) {
		if (pIndex >= mPhotoCount) {
			throw new IndexOutOfBoundsException("There should be " + mPhotoCount + "  images!!!");
		}
		mPhotoFramesView[pIndex].setPhoto(pResPhoto);
	}

	/**
	 * Sets photo from list.
	 * 
	 * @param pListPhoto
	 *            list of photo
	 */
	public void setPhotos(final List<Photo> pListPhoto) {
		if (pListPhoto == null) {
			throw new IllegalArgumentException("List can not be null!");
		}
		if (pListPhoto.size() != mPhotoCount) {
			throw new IndexOutOfBoundsException("There shoul be " + mPhotoCount + "  images!!!");
		}
		for (int index = 0; index < mPhotoCount; index++) {
			setPhotoAt(pListPhoto.get(index).getPhoto(), index);
		}

	}

	/**
	 * Initializes view.
	 * 
	 * @param pContext
	 *            context of application
	 */
	private void initCustomView(Context pContext) {
		final int[] resTab = new int[] { R.id.first_photo, R.id.second_photo, R.id.third_photo };
		final int res;
		switch (mPhotoCount) {
		case COUNT_PHOTO_ONE:
			res = R.layout.album_page_one_photo;
			break;
		case COUNT_PHOTO_TWO:
			res = R.layout.album_page_two_photo;
			break;
		case COUNT_PHOTO_THREE:
			res = R.layout.album_page_three_photo;
			break;
		default:
			throw new IllegalArgumentException(Integer.toString(mPhotoCount));
		}
		View.inflate(pContext, res, this);
		for (int index = 0; index < mPhotoCount; index++) {
			mPhotoFramesView[index] = (PhotoFrameView) findViewById(resTab[index]);
			final int finalIndex = index;
			mPhotoFramesView[index].setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View pView) {
					if (mOnPhotosClickListener != null) {
						mOnPhotosClickListener.onPhotoClick(pView, finalIndex);
					}
				}

			});
		}
	}

	/**
	 * Sets onClickListener for all photos.
	 * 
	 * @param pOnPhotosClickListener
	 *            listener which is used to catch photo click event
	 */
	public void setOnPhotosClickListener(OnPhotosClickListener pOnPhotosClickListener) {
		mOnPhotosClickListener = pOnPhotosClickListener;
	}

	/**
	 * Interface which is used to catch event when photo is clicked.
	 */
	public interface OnPhotosClickListener {
		/**
		 * Called when photo was clicked.
		 * 
		 * @param pView
		 *            view which was clicked
		 * @param pIndex
		 *            index of photo
		 */
		void onPhotoClick(View pView, int pIndex);
	}
}
