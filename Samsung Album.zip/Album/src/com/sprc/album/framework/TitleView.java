/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;

import com.samsung.samm.common.SObjectStroke;
import com.samsung.samm.common.SOptionPlay;
import com.samsung.samm.common.SOptionSAMM;
import com.samsung.samm.common.SOptionSCanvas;
import com.samsung.spensdk.SCanvasView;
import com.samsung.spensdk.applistener.AnimationProcessListener;
import com.samsung.spensdk.applistener.FileProcessListener;
import com.samsung.spensdk.applistener.SCanvasInitializeListener;
import com.sprc.album.R;
import com.sprc.album.utils.Preconditions;

/**
 * A view class to perform {@link SCanvasView} animation.
 */
public class TitleView extends SCanvasView {

	/**
	 * Application context.
	 */
	private final Context mContext;
	/**
	 * The animation initialized listener.
	 */
	private OnAnimationInitalizedListener mOnAnimationInitalizedListener = NullAnimationInitializedListener.NULL_INSTANCE;
	/**
	 * The animation finished listener.
	 */
	private OnAnimationFinishedListener mOnAnimationFinishedListener = NullAnimationFinishedListener.NULL_INSTANCE;
	/**
	 * Path to file in the file system.
	 */
	private String mFilePath;
	/**
	 * Path to asset located in the apk.
	 */
	private String mAssetPath;
	/**
	 * Mode of the title view.
	 */
	private TitleViewMode mTitleViewMode;
	/**
	 * Width of the stroke.
	 */
	private static final int STROKE_WIDTH = 5;

	/**
	 * Creates the {@link TitleView}.
	 * 
	 * @param pContext
	 *            application context
	 * @param pAssetPath
	 *            path to asset located in the apk, which contains animation to play (it must be the SAMMFile)
	 * @return {@link TitleView} instance
	 */
	public static final TitleView createTitleView(final Context pContext, final String pAssetPath) {
		final TitleView titleView = new TitleView(pContext, null);
		titleView.setAssetPath(pAssetPath);
		return titleView;
	}

	/**
	 * Creates the {@link TitleView}.
	 * 
	 * @param pContext
	 *            application context
	 * @param pAttributes
	 *            view attributes
	 */
	public TitleView(final Context pContext, final AttributeSet pAttributes) {
		super(pContext, pAttributes);
		mContext = pContext;

		setVisibility(View.INVISIBLE);
		mTitleViewMode = TitleViewMode.ANIM_INSCRIPTION;

		super.setFileProcessListener(new FileProcessListener() {

			@Override
			public void onLoadComplete(final boolean flag) {
				if (mTitleViewMode.equals(TitleViewMode.ANIM_INSCRIPTION)) {
					playAnimation();
				} else {
					setVisibility(View.VISIBLE);
				}
				mOnAnimationInitalizedListener.animationInitialized();
			}

			@Override
			public void onChangeProgress(final int i) {
				// does nothing intentionally
			}
		});

		super.setAnimationProcessListener(new AnimationProcessListener() {

			@Override
			public void onPlayComplete() {
				doAnimationClose();
				setAnimationMode(false);
				setCanvasDrawable(false);
				setCanvasPanEnable(false);
				setCanvasZoomEnable(false);
				mOnAnimationFinishedListener.animationFinished();
			}

			@Override
			public void onChangeProgress(final int arg0) {
				// does nothing intentionally
			}
		});

		super.setSCanvasInitializeListener(new SCanvasInitializeListener() {

			@Override
			public void onInitialized() {
				switch (mTitleViewMode) {
				case SHOW_INSCRIPTION:
				case ANIM_INSCRIPTION:
					final SOptionSCanvas canvasOption = getOption();
					canvasOption.mSAMMOption
							.setConvertCanvasSizeOption(SOptionSAMM.SAMM_LOAD_OPTION_CONVERT_SIZE_FITTOSIZE);
					setOption(canvasOption);

					try {
						if (mFilePath == null) {
							mFilePath = AssetToFile.assetPathToFilePath(mContext, mAssetPath);
						}
					} catch (final IOException e) {
						throw new RuntimeException(e);
					}

					loadSAMMFile(mFilePath, true, true, false);
					setCanvasDrawable(false);
					setCanvasPanEnable(false);
					setCanvasZoomEnable(false);

					break;
				case EDIT_MODE:
					setCanvasDrawable(true);
					setVisibility(View.VISIBLE);
					setSettingStrokeInfo(SObjectStroke.SAMM_STROKE_STYLE_PENCIL,
							SObjectStroke.SAMM_DEFAULT_MIN_STROKESIZE * STROKE_WIDTH,
							getResources().getColor(R.color.stroke_color));
					setBackgroundColor(Color.WHITE);
					break;
				default:
					throw new IllegalArgumentException(mTitleViewMode.name());
				}
			}
		});
	}

	/**
	 * Closes the TitleView. It should be done inside onDestroy().
	 */
	public void closeTitleView() {
		if (isAnimationMode()) {
			doAnimationClose();
		}
		closeSCanvasView();
	}

	/**
	 * Plays animation loaded from the provided asset.
	 */
	public void playAnimation() {
		final SOptionSCanvas canvasOption = getOption();
		canvasOption.mPlayOption.setAnimationSpeed(SOptionPlay.ANIMATION_SPEED_NORMAL);
		canvasOption.mPlayOption.setInvisibleBGImageAnimationOption(false);
		setOption(canvasOption);
		setAnimationMode(true);
		setCanvasDrawable(false);
		setCanvasPanEnable(false);
		setCanvasZoomEnable(false);
		setVisibility(View.VISIBLE);
		doAnimationStart();
	}

	/**
	 * Sets the animation initialized listener.
	 * 
	 * @param pOnAnimationInitalizedListener
	 *            the listener
	 */
	public void setOnAnimationInitializedListener(final OnAnimationInitalizedListener pOnAnimationInitalizedListener) {
		mOnAnimationInitalizedListener = pOnAnimationInitalizedListener == null ? NullAnimationInitializedListener.NULL_INSTANCE
				: pOnAnimationInitalizedListener;
	}

	/**
	 * Sets the animation finished listener.
	 * 
	 * @param pOnAnimationFinishedListener
	 *            the listener
	 */
	public void setOnAnimationFinshedListener(final OnAnimationFinishedListener pOnAnimationFinishedListener) {
		mOnAnimationFinishedListener = pOnAnimationFinishedListener == null ? NullAnimationFinishedListener.NULL_INSTANCE
				: pOnAnimationFinishedListener;
	}

	/**
	 * Enables or disables drawing on the view.
	 * 
	 * @param pFlag
	 *            whether or not drawing is enabled
	 */
	public void setModeType(TitleViewMode pFlag) {
		mTitleViewMode = pFlag;
	}

	/**
	 * Saves TitleView as file in the file system.
	 * 
	 * @return path to the saved file or null if a save operation has failed
	 */
	public String saveAsFile() {
		// @formatter:off
		final String path = new StringBuilder()
				.append(mContext.getApplicationContext().getFilesDir().getAbsolutePath()).append('/')
				.append(System.currentTimeMillis()).append(".png").toString();
		// @formatter:on

		setBackgroundColor(Color.TRANSPARENT);
		final SOptionSCanvas canvasOption = getOption();
		canvasOption.mSAMMOption.setSaveImageSize(SOptionSAMM.SAMM_SAVE_OPTION_ORIGINAL_SIZE);
		canvasOption.mSAMMOption.setContentsQuality(SOptionSAMM.SAMM_CONTETNS_QUALITY_MAX);
		canvasOption.mSAMMOption.setSaveOnlyForegroundImage(true);
		canvasOption.mSAMMOption.setCreateNewImageFile(true);
		setOption(canvasOption);
		final boolean result = saveSAMMFile(path);
		return result ? path : null;
	}

	/**
	 * Sets path to the asset located inside the apk.
	 * 
	 * @param assetPath
	 *            path to the asset (i.e. "album.png")
	 */
	public void setAssetPath(String assetPath) {
		mAssetPath = Preconditions.checkNotNull(assetPath);
	}

	/**
	 * Sets path to the file located in the file system.
	 * 
	 * @param filePath
	 *            absolute path to a file
	 */
	public void setFilePath(String filePath) {
		mFilePath = Preconditions.checkNotNull(filePath);
	}

	/**
	 * Do not use this method. It always throws {@link UnsupportedOperationException}.
	 * 
	 * @param arg0
	 *            a SCanvas initialize listener
	 */
	@Override
	public final void setSCanvasInitializeListener(final SCanvasInitializeListener arg0) {
		throw new UnsupportedOperationException();
	}

	/**
	 * Do not use this method. It always throws {@link UnsupportedOperationException}.
	 * 
	 * @param arg0
	 *            a animation process listener
	 */
	@Override
	public final void setAnimationProcessListener(final AnimationProcessListener arg0) {
		throw new UnsupportedOperationException();
	}

	/**
	 * Do not use this method. It always throws {@link UnsupportedOperationException}.
	 * 
	 * @param arg0
	 *            a file process listener
	 */
	@Override
	public final void setFileProcessListener(final FileProcessListener arg0) {
		throw new UnsupportedOperationException();
	}

	/**
	 * Mode of the title view.
	 */
	public enum TitleViewMode {
		/**
		 * Shows inscription.
		 */
		SHOW_INSCRIPTION,
		/**
		 * Animate inscription.
		 */
		ANIM_INSCRIPTION,
		/**
		 * Edit mode.
		 */
		EDIT_MODE
	}

	/**
	 * The callback function interface to call when the animation has finished.
	 */
	public interface OnAnimationFinishedListener {

		/**
		 * Called when animation has finished.
		 */
		void animationFinished();
	}

	/**
	 * Null instance of the {@link OnAnimationFinishedListener}.
	 */
	private enum NullAnimationFinishedListener implements OnAnimationFinishedListener {
		/**
		 * Null instance.
		 */
		NULL_INSTANCE;

		@Override
		public void animationFinished() {
			// Does nothing intentionally.
		}

	}

	/**
	 * The callback function interface to call when the animation has been initialized.
	 */
	public interface OnAnimationInitalizedListener {

		/**
		 * Called when animation has been initialized.
		 */
		void animationInitialized();
	}

	/**
	 * Null instance of the {@link OnAnimationInitalizedListener}.
	 */
	private enum NullAnimationInitializedListener implements OnAnimationInitalizedListener {
		/**
		 * Null instance.
		 */
		NULL_INSTANCE;

		@Override
		public void animationInitialized() {
			// Does nothing intentionally.
		}

	}

	/**
	 * Utility class that converts an asset to a file located in the file system.
	 */
	private static class AssetToFile {

		/**
		 * /** Converts an asset to a file located in the file system.
		 * 
		 * @param pContext
		 *            application context
		 * @param pAssetPath
		 *            path to the asset (i.e. "album.png")
		 * @return path to the file located in the file system
		 * @throws IOException
		 *             if asset to file conversion has failed
		 */
		public static String assetPathToFilePath(final Context pContext, final String pAssetPath) throws IOException {
			final AssetManager assets = pContext.getAssets();
			final InputStream inputStream = assets.open(pAssetPath);
			final File file = createFileFromInputStream(pContext, inputStream);
			return file.getAbsolutePath();
		}

		private static final int BUFFER_SIZE = 1024;

		/**
		 * Creates a file from an input stream.
		 * 
		 * @param pContext
		 *            application context
		 * @param pInputStream
		 *            input stream with data
		 * @return {@link File} representing the created file
		 * @throws IOException
		 *             if the file creation operation has failed
		 */
		private static File createFileFromInputStream(final Context pContext, final InputStream pInputStream)
				throws IOException {
			final String filePath = pContext.getFilesDir() + "/asset";
			final File file = new File(filePath);
			final OutputStream outputStream = new FileOutputStream(file);
			final byte buffer[] = new byte[BUFFER_SIZE];
			int length;

			try {
				while ((length = pInputStream.read(buffer)) > 0) {
					outputStream.write(buffer, 0, length);
				}
			} finally {
				outputStream.close();
				pInputStream.close();
			}

			return file;
		}
	}
}
