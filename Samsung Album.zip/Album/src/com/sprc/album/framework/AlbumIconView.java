/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.sprc.album.R;

/**
 * Class which represents item on albums list view.
 */
public class AlbumIconView extends LinearLayout {

	/** ImageView which is used to display bitmap. */
	private ImageView mPhotoView;
	private TextView mAlbumName;

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 */
	public AlbumIconView(final Context pContext) {
		super(pContext);
		initCustomView(pContext);
	}

	private void initCustomView(final Context pContext) {
		View.inflate(pContext, R.layout.photo_album_icon_layout, this);
		mPhotoView = (ImageView) findViewById(R.id.main_photo);
		mAlbumName = (TextView) findViewById(R.id.main_text);
	}

	/**
	 * Sets photo in main page.
	 * 
	 * @param pPhoto
	 *            - Bitmap which will be set as photo in main page.
	 */
	public void setMainPhoto(final Bitmap pPhoto) {
		mPhotoView.setImageBitmap(pPhoto);
	}

	/**
	 * Sets text in main page.
	 * 
	 * @param pText
	 *            - Text which will be set in main page.
	 */
	public void setAlbumName(final String pText) {
		mAlbumName.setText(pText);
	}

}
