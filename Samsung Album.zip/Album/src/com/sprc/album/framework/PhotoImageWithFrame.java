/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * Class which was created for rotation image.
 * 
 */
public class PhotoImageWithFrame extends ImageView {

	private static final int FRAME_IN_PAGE_COLOR = 40;
	private static final int FRAME_IN_WITH_COLOR = 20;
	private static final int MARGIN_PHOTO = 5;

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 */
	public PhotoImageWithFrame(Context pContext) {
		this(pContext, null);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pArtts
	 *            attributes
	 */
	public PhotoImageWithFrame(Context pContext, AttributeSet pArtts) {
		this(pContext, pArtts, 0);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pArtts
	 *            attributes
	 * @param pDefStyle
	 *            definition of style
	 */
	public PhotoImageWithFrame(Context pContext, AttributeSet pArtts, int pDefStyle) {
		super(pContext, pArtts, pDefStyle);
	}

	@Override
	public void setImageBitmap(Bitmap bitmap) {
		final Bitmap background = Bitmap.createBitmap(bitmap.getWidth() + FRAME_IN_PAGE_COLOR, bitmap.getHeight()
				+ FRAME_IN_PAGE_COLOR, bitmap.getConfig());

		final Canvas c = new Canvas(background);
		final Paint myPaint = new Paint();
		myPaint.setStrokeWidth(0);
		myPaint.setColor(Color.parseColor("#181818"));
		myPaint.setAntiAlias(true);
		c.drawRect(new Rect(0, 0, c.getWidth(), c.getHeight()), myPaint);
		myPaint.setColor(Color.WHITE);
		c.drawRect(new Rect(MARGIN_PHOTO, MARGIN_PHOTO, c.getWidth() - MARGIN_PHOTO, c.getHeight() - MARGIN_PHOTO),
				myPaint);
		c.drawBitmap(bitmap, FRAME_IN_WITH_COLOR, FRAME_IN_WITH_COLOR, myPaint);

		super.setImageBitmap(background);
	}

	@Override
	public void setImageResource(int resId) {
		final BitmapDrawable d = (BitmapDrawable) getContext().getResources().getDrawable(resId);

		setImageBitmap(d.getBitmap());
	}
}
