/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import com.sprc.album.R;
import com.sprc.album.framework.TitleView.TitleViewMode;

/**
 * Class which represents end page of album .
 */
public class PageWithSCanvasDesc extends LinearLayout {

	/**
	 * View which represents end description view.
	 */
	private TitleView mEndDesc;

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pTitleViewMode
	 *            mode of description
	 */
	public PageWithSCanvasDesc(final Context pContext, TitleViewMode pTitleViewMode) {
		super(pContext);
		initCustomView(pContext, pTitleViewMode);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            pContext of application
	 * @param pArtts
	 *            attributes
	 */
	public PageWithSCanvasDesc(final Context pContext, final AttributeSet pArtts) {
		super(pContext, pArtts);
		initCustomView(pContext, TitleViewMode.ANIM_INSCRIPTION);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            pContext of application
	 * @param pArtts
	 *            attributes
	 * @param pDefStyle
	 *            definition of style
	 */
	public PageWithSCanvasDesc(final Context pContext, final AttributeSet pArtts, final int pDefStyle) {
		super(pContext, pArtts, pDefStyle);
		initCustomView(pContext, TitleViewMode.ANIM_INSCRIPTION);
	}

	/**
	 * Initialize view.
	 * 
	 * @param pContext
	 *            context for this view
	 * @param pTitleViewMode
	 *            mode of description
	 */
	private void initCustomView(final Context pContext, TitleViewMode pTitleViewMode) {
		View.inflate(pContext, R.layout.album_page_end_page, this);

		mEndDesc = (TitleView) findViewById(R.id.end_dec_view);
		mEndDesc.setModeType(pTitleViewMode);
	}

	/**
	 * Save file.
	 * 
	 * @return information about path where was saved file.
	 */
	public String saveAsFile() {
		return mEndDesc.saveAsFile();
	}

	/**
	 * Sets path to file for description control.
	 * 
	 * @param pathToDesc
	 *            path to png file with description
	 */
	public void setFilePath(String pathToDesc) {
		mEndDesc.setFilePath(pathToDesc);
	}
}
