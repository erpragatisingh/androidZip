/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.sprc.album.R;

/**
 * Class which represents palette view. This class has implemented support for the to choose color. You can set
 * OnColorSelectListener and you can catch view which is selected and color which suits him.
 * 
 */
public class PaletteView extends RelativeLayout {

	/** Number of buttons, colors and buttons resources. */
	private static final int BUTTONS_COUNT = 8;
	/** Array of buttons which represents colors. */
	private ImageView[] mColorButtons;
	/** Array of resources id buttons view. */
	private final int[] mButtonsRes = new int[] { R.id.palette_color_red, R.id.palette_color_orange,
			R.id.palette_color_yellow, R.id.palette_color_green, R.id.palette_color_blue, R.id.palette_color_dark_blue,
			R.id.palette_color_purple, R.id.palette_color_more_colors };
	/** Array of colors which suit buttons. */
	private final int[] mColors = new int[] { Color.parseColor("#f40812"), Color.parseColor("#f17f03"),
			Color.parseColor("#fccf04"), Color.parseColor("#92d605"), Color.parseColor("#06c7f2"),
			Color.parseColor("#0d7fc8"), Color.parseColor("#8b17da"), Color.TRANSPARENT };
	/** Listener. */
	private OnColorSelectListener mOnColorSelectListener;

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 */
	public PaletteView(Context pContext) {
		super(pContext);
		initControl();
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pArtts
	 *            attributes
	 */
	public PaletteView(Context pContext, AttributeSet pArtts) {
		super(pContext, pArtts);
		initControl();
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pArtts
	 *            attributes
	 * @param pDefStyle
	 *            definition of style
	 */
	public PaletteView(Context pContext, AttributeSet pArtts, int pDefStyle) {
		super(pContext, pArtts, pDefStyle);
		initControl();
	}

	private void initControl() {
		View.inflate(getContext(), R.layout.palette_layout, this);
		mColorButtons = new ImageView[BUTTONS_COUNT];

		final OnClickListener onClickListener = new OnClickListener() {

			@Override
			public void onClick(View pView) {
				final int id = pView.getId();
				int slectedIndex = -1;
				for (int index = 0; index < BUTTONS_COUNT; index++) {
					final boolean findIndex = id == mButtonsRes[index];
					mColorButtons[index].setSelected(findIndex);
					if (findIndex) {
						slectedIndex = index;
					}
				}
				if (mOnColorSelectListener != null) {
					mOnColorSelectListener.onColorSelect(pView, mColors[slectedIndex]);
				}
			}
		};
		for (int index = 0; index < BUTTONS_COUNT; index++) {
			mColorButtons[index] = (ImageView) findViewById(mButtonsRes[index]);
			mColorButtons[index].setOnClickListener(onClickListener);
		}
		mColorButtons[0].setSelected(true);
		mColorButtons[0].invalidate();
	}

	/**
	 * Sets the selected color.
	 * 
	 * @param pColor
	 *            the selected color
	 */
	public void setSelectedColor(int pColor) {
		final ImageView mColorSelected = (ImageView) findViewById(R.id.palette_color_more_colors_select);
		mColorSelected.setBackgroundColor(pColor);
	}

	@Override
	public void setEnabled(boolean enabled) {
		super.setEnabled(enabled);
		for (int index = 0; index < BUTTONS_COUNT; index++) {
			mColorButtons[index] = (ImageView) findViewById(mButtonsRes[index]);
			if (mButtonsRes[index] != R.id.palette_color_more_colors) {
				mColorButtons[index].setEnabled(enabled);
			}
		}

	}

	/**
	 * Sets OnColorSelectListener.
	 * 
	 * @param pOnColorSelectListener
	 *            listener which informs that color was changed
	 */
	public void setOnColorSelectListener(OnColorSelectListener pOnColorSelectListener) {
		mOnColorSelectListener = pOnColorSelectListener;
	}

	/** Interface which is used to get information that color was changed. */
	public interface OnColorSelectListener {
		/**
		 * Called when some color is selected.
		 * 
		 * @param pView
		 *            view which was selected
		 * @param pColor
		 *            color which is assigned to view
		 */
		void onColorSelect(View pView, int pColor);
	}
}
