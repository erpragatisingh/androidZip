/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;

import com.sprc.album.R;

/**
 * View which allows to display photo in frame.
 * 
 */
public class PhotoFrameView extends RelativeLayout {

	/** ImageView which is used to display bitmap. */
	private PhotoImageWithFrame mPhotoView;

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 */
	public PhotoFrameView(final Context pContext) {
		super(pContext);
		initCustomView(pContext);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pArtts
	 *            attributes
	 */
	public PhotoFrameView(final Context pContext, final AttributeSet pArtts) {
		super(pContext, pArtts);
		initCustomView(pContext);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pArtts
	 *            attributes
	 * @param pDefStyle
	 *            definition of style
	 */
	public PhotoFrameView(final Context pContext, final AttributeSet pArtts, final int pDefStyle) {
		super(pContext, pArtts, pDefStyle);
		initCustomView(pContext);
	}

	private void initCustomView(final Context pContext) {
		View.inflate(pContext, R.layout.photo_album_frame_layout, this);
		mPhotoView = (PhotoImageWithFrame) findViewById(R.id.picture);
	}

	/**
	 * Sets photo in frame.
	 * 
	 * @param pPhoto
	 *            - Bitmap which will be set as photo in frame.
	 */
	public void setPhoto(final Bitmap pPhoto) {
		if (pPhoto == null) {
			throw new IllegalArgumentException("List can not be null!");
		}
		mPhotoView.setImageBitmap(pPhoto);
	}

	/**
	 * Sets photo in frame.
	 * 
	 * @param pResPhoto
	 *            - Resources to bitmap which will be set as photo in frame.
	 */
	public void setPhoto(final int pResPhoto) {
		mPhotoView.setImageResource(pResPhoto);
	}
}
