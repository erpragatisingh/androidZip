/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;

import com.sprc.album.R;
import com.sprc.album.utils.Preconditions;

/**
 * Class which represents custom flipper view.
 */
public class CustomPageFlipperView extends RelativeLayout {

	/** Current view. */
	private View mCurentView;
	/** Next view. */
	private View mNextView;

	private OnPageChangeListener mListener = NullOnPageChangeListener.NULL_INSTANCE;

	/** How to change type. */
	public enum ChangeType {
		/** When we want to show new page. */
		NEXT_PAGE,
		/** When we want to show previous page. */
		PREV_PAGE
	}

	/**
	 * Enum which represents null instance of OnPageChangeListener.
	 */
	private enum NullOnPageChangeListener implements OnPageChangeListener {
		/** Instance which represents null instance. */
		NULL_INSTANCE;

		@Override
		public void changed() {
			// Do nothing.
		}
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 */
	public CustomPageFlipperView(final Context pContext) {
		super(pContext);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pAttrs
	 *            attributes
	 */
	public CustomPageFlipperView(final Context pContext, final AttributeSet pAttrs) {
		super(pContext, pAttrs);
	}

	/**
	 * Constructor.
	 * 
	 * @param pContext
	 *            context of application
	 * @param pAttrs
	 *            attributes
	 * @param pDefStyle
	 *            definition of style
	 */
	public CustomPageFlipperView(final Context pContext, final AttributeSet pAttrs, final int pDefStyle) {
		super(pContext, pAttrs, pDefStyle);
	}

	/**
	 * Sets current page. <B> This function must be called before setDisplayPage</B>.
	 * 
	 * @param pCurentView
	 *            view which be displayed on start
	 */
	public void setCurrentPage(final View pCurentView) {
		mCurentView = Preconditions.checkNotNull(pCurentView);
		addView(mCurentView, new LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT,
				android.view.ViewGroup.LayoutParams.MATCH_PARENT));
	}

	/**
	 * Sets page with animation.Before use this method we have to set current view via setCurrentPage method.
	 * 
	 * @param pView
	 *            view which will be set as next or previous. After set view, it will be current page.
	 * @param pHowToChange
	 *            type to page change. Open page or close page. (Sets next or previous)
	 */
	public void setDisplayPage(final View pView, final ChangeType pHowToChange) {
		if (mCurentView == null) {
			throw new IllegalStateException("First set current page.");
		}
		mNextView = pView;

		addView(mNextView, new LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT,
				android.view.ViewGroup.LayoutParams.MATCH_PARENT));

		if (pHowToChange.equals(ChangeType.NEXT_PAGE)) {
			// if we wont to display next page we must put new view behind
			// current view.
			// so we must detach current view and attach again.
			detachViewFromParent(mCurentView);
			addView(mCurentView, new LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT,
					android.view.ViewGroup.LayoutParams.MATCH_PARENT));
		}

		final int resAnim = pHowToChange == ChangeType.NEXT_PAGE ? R.anim.page_out_animation : R.anim.page_in_animation;
		final View viewToAnim = pHowToChange == ChangeType.NEXT_PAGE ? mCurentView : mNextView;

		// Animation to change page
		final Animation anim = AnimationUtils.loadAnimation(getContext(), resAnim);
		viewToAnim.startAnimation(anim);
		anim.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(final Animation animation) {

			}

			@Override
			public void onAnimationRepeat(final Animation animation) {

			}

			@Override
			public void onAnimationEnd(final Animation animation) {
				detachViewFromParent(mCurentView);
				mCurentView = mNextView;
				// unlock page
				setEnabled(true);
				mListener.changed();
			}
		});

		// lock page
		setEnabled(false);
	}

	/**
	 * Sets listener which informs about change page.
	 * 
	 * @param pListener
	 *            listener which informs about change page
	 */
	public void setOnPageChangeListener(OnPageChangeListener pListener) {
		if (pListener == null) {
			mListener = NullOnPageChangeListener.NULL_INSTANCE;
		}
		mListener = pListener;
	}

	/**
	 * Listener which inform that page was changed.
	 */
	public interface OnPageChangeListener {
		/**
		 * Calls when page was changed.
		 */
		void changed();
	}
}
