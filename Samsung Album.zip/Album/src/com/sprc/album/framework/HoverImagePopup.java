/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.framework;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.PopupWindow;

/**
 * Pop-up window with image.
 */
public class HoverImagePopup extends PopupWindow {

	/**
	 * Constructs a pop-up.
	 */
	public HoverImagePopup() {
		super();
	}

	/**
	 * Constructs a pop-up.
	 * 
	 * @param context
	 *            application context
	 * @param attrs
	 *            collection of attributes
	 * @param defStyle
	 *            style of the pop-up
	 */
	public HoverImagePopup(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	/**
	 * Constructs a pop-up.
	 * 
	 * @param context
	 *            application context
	 * @param attrs
	 *            collection of attributes
	 */
	public HoverImagePopup(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	/**
	 * Constructs a pop-up.
	 * 
	 * @param context
	 *            application context
	 */
	public HoverImagePopup(Context context) {
		super(context);
	}

	/**
	 * Constructs a pop-up.
	 * 
	 * @param width
	 *            width of the pop-up
	 * @param height
	 *            height of the pop-up
	 */
	public HoverImagePopup(int width, int height) {
		super(width, height);
	}

	/**
	 * Sets the photo.
	 * 
	 * @param photo
	 *            ImageView with photo
	 */
	public void setPhoto(ImageView photo) {
		setContentView(photo);
	}
}
