/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.albumcreator;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.samsung.spen.lib.input.SPenEventLibrary;
import com.samsung.spensdk.applistener.SPenHoverListener;
import com.sprc.album.R;
import com.sprc.album.db.DbUtils;
import com.sprc.album.db.data.Photo;
import com.sprc.album.framework.HoverImagePopup;

/**
 * Shows all photos from the database and allows to choose one of them. Returns id of the chosen photo as extra field in
 * the intent.
 */
public class PhotoChooser extends Activity {

	/**
	 * Value used as key for photo's id.
	 */
	static final String PHOTO_ID = "PHOTO_ID";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.photo_chooser_layout);
		final GridView gridView = (GridView) findViewById(R.id.photo_chooser_grid_view);
		gridView.setAdapter(new PhotoAdapter(this, DbUtils.getPhotos(this)));
		gridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(final AdapterView<?> parent, final View v, final int position, final long id) {
				final int photoID = ((PhotoAdapter) parent.getAdapter()).getItem(position).getId();
				final Intent result = new Intent();
				result.putExtra(PHOTO_ID, photoID);
				setResult(Activity.RESULT_OK, result);
				finish();
			}
		});
	}

	@Override
	public void onBackPressed() {
		setResult(Activity.RESULT_CANCELED);
		finish();
	}

	/**
	 * Adapter for GridView.
	 */
	private static class PhotoAdapter extends BaseAdapter {

		/**
		 * Delay in milliseconds.
		 */
		private static final int POPUP_DELAY = 300;
		private static final int POPUP_SIZE = 500;
		private final HoverImagePopup mPopup;
		private Runnable mRun;
		private boolean mWillBeShown;

		private final SPenEventLibrary mSPenEventLibrary = new SPenEventLibrary();
		private final SPenHoverListener mOnHoverListener = new SPenHoverListener() {

			@Override
			public boolean onHover(final View v, MotionEvent event) {
				if (!mPopup.isShowing() && !mWillBeShown) {
					mWillBeShown = true;
					mRun = new Runnable() {

						@Override
						public void run() {
							v.buildDrawingCache();
							final ImageView image = new ImageView(mContext);
							image.setImageBitmap(v.getDrawingCache());
							mPopup.setPhoto(image);
							mPopup.showAsDropDown(v, -v.getWidth() / 2, -v.getHeight());
						}
					};
					v.postDelayed(mRun, POPUP_DELAY);
				}

				if (MotionEvent.ACTION_HOVER_EXIT == event.getAction()) {
					if (!mPopup.isShowing() && mWillBeShown) {
						v.removeCallbacks(mRun);
					}
					mPopup.dismiss();
					mWillBeShown = false;
				}

				return true;
			}

			@Override
			public void onHoverButtonDown(View arg0, MotionEvent arg1) {
				// Does nothing intentionally.
			}

			@Override
			public void onHoverButtonUp(View arg0, MotionEvent arg1) {
				// Does nothing intentionally.
			}
		};

		/**
		 * Context of application.
		 */
		private final Context mContext;
		/**
		 * List of albums.
		 */
		private final List<Photo> mPhotos;

		/**
		 * Constructs an adapter for photos.
		 * 
		 * @param context
		 *            application context
		 * @param photos
		 *            list with photos
		 */
		public PhotoAdapter(Context context, List<Photo> photos) {
			mContext = context;
			mPhotos = new ArrayList<Photo>(photos);
			mPopup = new HoverImagePopup(POPUP_SIZE, POPUP_SIZE);
			mPopup.setTouchable(false);
		}

		@Override
		public int getCount() {
			return mPhotos.size();
		}

		@Override
		public Photo getItem(int index) {
			return mPhotos.get(index);
		}

		@Override
		public long getItemId(int id) {
			return id;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final ImageView photoView = new ImageView(mContext);
			final Photo info = mPhotos.get(position);
			photoView.setImageBitmap(info.getPhoto());
			mSPenEventLibrary.setSPenHoverListener(photoView, mOnHoverListener);
			return photoView;
		}
	}

}
