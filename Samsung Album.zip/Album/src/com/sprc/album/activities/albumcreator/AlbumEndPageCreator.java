/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.albumcreator;

import android.content.Intent;
import android.os.Bundle;

import com.sprc.album.R;
import com.sprc.album.framework.PageWithSCanvasDesc;
import com.sprc.album.framework.TitleView.TitleViewMode;

/**
 * Activity which represents creator for end page.
 */
public class AlbumEndPageCreator extends AbstractAlbumPageCreator {

	/**
	 * Key for value of path to description.
	 */
	static final String PATH_TO_END_DESC = "PATH_TO_END_DESC";

	/**
	 * End page.
	 */
	private PageWithSCanvasDesc mViewToAdd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		unlockAddButton();
	}

	@Override
	void initPageView(int pPageType) {

		if (pPageType != R.id.create_end_page) {
			throw new IllegalArgumentException();
		}
		mViewToAdd = new PageWithSCanvasDesc(this, TitleViewMode.EDIT_MODE);
		addViewToMainFrame(mViewToAdd);
	}

	@Override
	void putDataIntoIntent(Intent result) {
		final String pathToFile = mViewToAdd.saveAsFile();
		result.putExtra(PATH_TO_END_DESC, pathToFile);
	}

}
