/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.albumcreator;

import android.content.Intent;
import android.os.Bundle;

import com.sprc.album.R;
import com.sprc.album.db.DbUtils;
import com.sprc.album.db.data.Photo;
import com.sprc.album.framework.PageWithOnePhotoAndSCanvasDesc;
import com.sprc.album.framework.PageWithOnePhotoAndSCanvasDesc.OnTitlePhotoPageClickListner;
import com.sprc.album.framework.TitleView.TitleViewMode;
import com.sprc.album.utils.Preconditions;

/**
 * Class which represents activity to create title page.
 */
public class AlbumTitlePageCreator extends AbstractAlbumPageCreator {

	/**
	 * Title page.
	 */
	private PageWithOnePhotoAndSCanvasDesc mViewToAdd;

	/**
	 * Key to get path to title.
	 */
	static final String PATH_TO_TITLE = "PATH_TO_TITLE";
	/**
	 * Key to get photo id.
	 */
	static final String PHOTO_ID = "PHOTO_ID";

	/**
	 * Id of photo.
	 */
	private int mPhotoId;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	void initPageView(int pPageType) {
		if (pPageType != R.id.create_title_page) {
			throw new IllegalArgumentException();
		}

		mViewToAdd = new PageWithOnePhotoAndSCanvasDesc(this, TitleViewMode.EDIT_MODE);
		mViewToAdd.setTitlePhoto(R.drawable.create_album_cover_photo_button);
		mViewToAdd.setOnTitlePhotoPageListner(new OnTitlePhotoPageClickListner() {

			@Override
			public void onTitlePhotoClick() {
				startActivityForResult(new Intent(AlbumTitlePageCreator.this, PhotoChooser.class), PHOTO_CHOOSER_REQ);
			}
		});

		addViewToMainFrame(mViewToAdd);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK && requestCode == PHOTO_CHOOSER_REQ) {
			Preconditions.checkNotNull(data);
			final Bundle b = data.getExtras();
			Preconditions.checkNotNull(b);
			final int photoId = b.getInt(PhotoChooser.PHOTO_ID);
			final Photo photo = DbUtils.getPhoto(this, photoId);
			Preconditions.checkNotNull(photo);
			mViewToAdd.setTitlePhoto(photo.getPhoto());
			mPhotoId = photoId;
			unlockAddButton();
		}
	}

	@Override
	void putDataIntoIntent(final Intent result) {
		final String mPhotoPath = mViewToAdd.saveAsFile();
		result.putExtra(PATH_TO_TITLE, mPhotoPath);
		result.putExtra(PHOTO_ID, mPhotoId);
	}

}
