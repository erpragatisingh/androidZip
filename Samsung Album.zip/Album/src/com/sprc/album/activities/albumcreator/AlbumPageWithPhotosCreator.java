/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.albumcreator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.sprc.album.R;
import com.sprc.album.db.DbUtils;
import com.sprc.album.db.data.Photo;
import com.sprc.album.framework.PageWithPhotos;
import com.sprc.album.framework.PageWithPhotos.OnPhotosClickListener;
import com.sprc.album.utils.Preconditions;

/**
 * Class which represents activity to create page with photos.
 * 
 */
public class AlbumPageWithPhotosCreator extends AbstractAlbumPageCreator {

	static final String PHOTOS_IDS_LIST = "PHOTOS_IDS_LIST";

	private int[] mPhotosIds;
	private boolean[] mIsPhotoSet;
	private int mSelectedIndex = -1;

	private PageWithPhotos mViewToAdd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

	}

	@Override
	void initPageView(int pPageType) {
		switch (pPageType) {

		case R.id.create_page_with_one_photo:
			mPhotosIds = new int[PageWithPhotos.COUNT_PHOTO_ONE];
			mIsPhotoSet = new boolean[PageWithPhotos.COUNT_PHOTO_ONE];
			preparePageWithPhotos(PageWithPhotos.COUNT_PHOTO_ONE);
			break;
		case R.id.create_page_with_two_photo:
			mPhotosIds = new int[PageWithPhotos.COUNT_PHOTO_TWO];
			mIsPhotoSet = new boolean[PageWithPhotos.COUNT_PHOTO_TWO];
			preparePageWithPhotos(PageWithPhotos.COUNT_PHOTO_TWO);
			break;
		case R.id.create_page_with_three_photo:
			mPhotosIds = new int[PageWithPhotos.COUNT_PHOTO_THREE];
			mIsPhotoSet = new boolean[PageWithPhotos.COUNT_PHOTO_THREE];
			preparePageWithPhotos(PageWithPhotos.COUNT_PHOTO_THREE);
			break;
		default:
			throw new IllegalArgumentException();
		}
		addViewToMainFrame(mViewToAdd);
	}

	private void preparePageWithPhotos(int pPhotoCount) {
		mViewToAdd = new PageWithPhotos(this, pPhotoCount);
		for (int index = 0; index < pPhotoCount; index++) {
			mViewToAdd.setPhotoAt(R.drawable.create_album_cover_photo_button, index);
		}
		mViewToAdd.setOnPhotosClickListener(new OnPhotosClickListener() {

			@Override
			public void onPhotoClick(View pView, int pIndex) {
				startActivityForResult(new Intent(AlbumPageWithPhotosCreator.this, PhotoChooser.class),
						PHOTO_CHOOSER_REQ);
				mSelectedIndex = pIndex;
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK && requestCode == PHOTO_CHOOSER_REQ) {
			final Bundle b = data.getExtras();
			Preconditions.checkNotNull(b);
			final int photoId = b.getInt(PhotoChooser.PHOTO_ID);
			mPhotosIds[mSelectedIndex] = photoId;
			mIsPhotoSet[mSelectedIndex] = true;
			final Photo photo = DbUtils.getPhoto(this, photoId);
			Preconditions.checkNotNull(photo);
			mViewToAdd.setPhotoAt(photo.getPhoto(), mSelectedIndex);
			if (isAllPhotoSet()) {
				unlockAddButton();
			}
		}
	}

	private boolean isAllPhotoSet() {
		boolean reslt = true;
		for (final boolean isPhotoSet : mIsPhotoSet) {
			reslt = reslt && isPhotoSet;
		}
		return reslt;
	}

	@Override
	void putDataIntoIntent(Intent result) {
		result.putExtra(PHOTOS_IDS_LIST, mPhotosIds);
	}
}
