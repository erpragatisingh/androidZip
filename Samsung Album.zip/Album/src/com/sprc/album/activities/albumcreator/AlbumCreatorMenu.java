/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.albumcreator;

import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.sprc.album.R;
import com.sprc.album.db.DbUtils;
import com.sprc.album.db.data.AlbumPage;
import com.sprc.album.db.data.EndPage;
import com.sprc.album.db.data.Photo;
import com.sprc.album.db.data.TitlePage;
import com.sprc.album.framework.PageWithPhotos;
import com.sprc.album.logic.album.Album;
import com.sprc.album.utils.Preconditions;

/**
 * Class which represents menu to create album. (We can create title page, page with one two and three photos and end
 * page).
 */
public class AlbumCreatorMenu extends Activity {

	/**
	 * Key for value which defines page type.
	 */
	static final String PAGE_TYPE_KEY = "PAGE_TYPE_KEY";

	/**
	 * Adapter for pages list.
	 */
	private PageListAdapter mPageListAdapter;

	/**
	 * Title page of album.
	 */
	private TitlePage mTitlePage;
	/**
	 * Pages list.
	 */
	private List<AlbumPage> mAlbumPagesList;
	/**
	 * End page.
	 */
	private EndPage mEndPage;
	/**
	 * EditText field where a user inserts name of album.
	 */
	private EditText mAlbumName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_album_creator_menu);
		mAlbumPagesList = new LinkedList<AlbumPage>();
		prepareAlbumNameEditText();
		preparePagesList();
	}

	private void prepareAlbumNameEditText() {
		mAlbumName = (EditText) findViewById(R.id.album_name_text);
		mAlbumName.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				setButtonEnabled(count != 0 && mEndPage != null, R.id.save_button);
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// Do nothing
			}

			@Override
			public void afterTextChanged(Editable s) {
				// Do nothing
			}
		});
	}

	private void preparePagesList() {
		final ListView pagesList = (ListView) findViewById(R.id.pages_list);
		mPageListAdapter = new PageListAdapter(this);
		pagesList.setAdapter(mPageListAdapter);
		mPageListAdapter.setOnItemRemoveListener(new OnItemRemoveListener() {

			@Override
			public void onItemRemove(int pItemType, int pPosition) {
				if (mPageListAdapter.getCount() == 1) {
					setButtonEnabled(true, R.id.create_title_page);
					setButtonEnabled(false, R.id.create_page_with_one_photo, R.id.create_page_with_two_photo,
							R.id.create_page_with_three_photo, R.id.create_end_page);
				}
				if (isPageWithPhotos(pItemType)) {
					mAlbumPagesList.remove(pPosition - 1);
					if (mPageListAdapter.getCount() == 2) {
						setButtonEnabled(false, R.id.create_end_page);
					}
				}
				if (pItemType == R.id.create_end_page) {
					setButtonEnabled(true, R.id.create_end_page, R.id.create_page_with_one_photo,
							R.id.create_page_with_two_photo, R.id.create_page_with_three_photo, R.id.create_end_page);

					setButtonEnabled(false, R.id.save_button);
					mEndPage = null;
				}

			}
		});
	}

	private boolean isPageWithPhotos(int pType) {
		return pType == R.id.create_page_with_one_photo || pType == R.id.create_page_with_two_photo
				|| pType == R.id.create_page_with_three_photo;
	}

	private void setButtonEnabled(boolean pEnabled, int... pButtonIds) {
		for (final int res : pButtonIds) {
			final Button button = (Button) findViewById(res);
			if (button == null) {
				throw new IllegalArgumentException("Button " + res + " not found.");
			}
			button.setEnabled(pEnabled);
		}
	}

	/**
	 * Called when some button which create page was clicked.
	 * 
	 * @param pView
	 *            view which was clicked.
	 */
	public void onCreatePageButtonClick(View pView) {

		final Intent intent;

		switch (pView.getId()) {
		case R.id.create_title_page:
			intent = new Intent(AlbumCreatorMenu.this, AlbumTitlePageCreator.class);
			break;
		case R.id.create_page_with_one_photo:
		case R.id.create_page_with_two_photo:
		case R.id.create_page_with_three_photo:
			intent = new Intent(AlbumCreatorMenu.this, AlbumPageWithPhotosCreator.class);
			break;
		case R.id.create_end_page:
			intent = new Intent(AlbumCreatorMenu.this, AlbumEndPageCreator.class);
			break;
		default:
			throw new IllegalArgumentException("View " + pView.getId() + " is not supported via this method.");
		}
		intent.putExtra(PAGE_TYPE_KEY, pView.getId());
		startActivityForResult(intent, pView.getId());
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			Preconditions.checkNotNull(data);
			switch (requestCode) {
			case R.id.create_title_page:
				onAlbumTitlePageCreatorResult(data);
				break;
			case R.id.create_page_with_one_photo:
				onAlbumPageWithPhotoCreatorResult(data, PageWithPhotos.COUNT_PHOTO_ONE);
				break;
			case R.id.create_page_with_two_photo:
				onAlbumPageWithPhotoCreatorResult(data, PageWithPhotos.COUNT_PHOTO_TWO);
				break;
			case R.id.create_page_with_three_photo:
				onAlbumPageWithPhotoCreatorResult(data, PageWithPhotos.COUNT_PHOTO_THREE);
				break;
			case R.id.create_end_page:
				onAlbumEndPageCreatorResult(data);
				break;
			default:
				throw new IllegalArgumentException("View " + resultCode + " is not supported via this method.");
			}
			mPageListAdapter.addItem(requestCode);
		}
	}

	private void onAlbumTitlePageCreatorResult(Intent data) {
		final int photoId = data.getIntExtra(AlbumTitlePageCreator.PHOTO_ID, -1);
		if (photoId == -1) {
			throw new IllegalArgumentException();
		}

		final String titleText = data.getStringExtra(AlbumTitlePageCreator.PATH_TO_TITLE);
		Preconditions.checkNotNull(titleText);

		setButtonEnabled(false, R.id.create_title_page);
		setButtonEnabled(true, R.id.create_page_with_one_photo, R.id.create_page_with_two_photo,
				R.id.create_page_with_three_photo);
		mTitlePage = new TitlePage.Builder().setId(0).setTitleAnimation(titleText)
				.setTitleImage(new Photo.Builder().setId(photoId).build()).build();
	}

	private void onAlbumPageWithPhotoCreatorResult(Intent data, int photoCount) {
		final int[] photosIds = data.getIntArrayExtra(AlbumPageWithPhotosCreator.PHOTOS_IDS_LIST);
		if (photosIds == null || photosIds.length != photoCount) {
			throw new IllegalArgumentException();
		}
		setButtonEnabled(true, R.id.create_end_page);
		final AlbumPage.Builder pageBuilder = new AlbumPage.Builder();
		for (int index = 0; index < photoCount; index++) {
			pageBuilder.addPhoto(new Photo.Builder().setId(photosIds[index]).build(), index);

		}
		mAlbumPagesList.add(pageBuilder.build());
	}

	private void onAlbumEndPageCreatorResult(Intent data) {
		final String endDesc = data.getStringExtra(AlbumEndPageCreator.PATH_TO_END_DESC);
		Preconditions.checkNotNull(endDesc);
		setButtonEnabled(false, R.id.create_title_page, R.id.create_page_with_one_photo,
				R.id.create_page_with_two_photo, R.id.create_page_with_three_photo, R.id.create_end_page);
		setButtonEnabled(mAlbumName.getText().length() != 0, R.id.save_button);
		mEndPage = new EndPage.Builder().setId(0).setPathToDesc(endDesc).build();
	}

	/**
	 * Called when save button was clicked.
	 * 
	 * @param pView
	 *            save button.
	 */
	public void onSaveButtonClick(View pView) {
		if (pView.getId() != R.id.save_button) {
			throw new IllegalArgumentException("This method should be used only for save button. Not support "
					+ pView.getId());
		}
		final Album album = new Album(mTitlePage, mEndPage, mAlbumPagesList, mAlbumName.getText().toString());
		DbUtils.insertAlbum(this, album);
		finish();
	}

	/**
	 * Adapter for pages list which album contains.
	 */
	static class PageListAdapter extends BaseAdapter {

		/**
		 * Context of application.
		 */
		private final Context mContext;

		/**
		 * List all pages (a first page and a last is there too).
		 */
		private final List<Integer> mPageList;

		/**
		 * Listener which informs about removed item.
		 */
		private OnItemRemoveListener mOnItemRemoveListener;

		/**
		 * Constructor.
		 * 
		 * @param pContext
		 *            context of application
		 */
		PageListAdapter(Context pContext) {
			mContext = pContext;
			mPageList = new LinkedList<Integer>();
		}

		/**
		 * Adds item to the list.
		 * 
		 * @param pItem
		 *            item which will be added
		 */
		public void addItem(int pItem) {
			mPageList.add(pItem);
			notifyDataSetInvalidated();
		}

		/**
		 * Sets OnItemRemoveListener listener.
		 * 
		 * @param pOnItemRemoveListener
		 *            on item remove listener
		 */
		public void setOnItemRemoveListener(OnItemRemoveListener pOnItemRemoveListener) {
			mOnItemRemoveListener = pOnItemRemoveListener;
		}

		/**
		 * Returns number of elements.
		 * 
		 * @return pages list count
		 */
		@Override
		public int getCount() {
			return mPageList.size();
		}

		/**
		 * Returns element from the pages list.
		 * 
		 * @param pPosition
		 *            position of item
		 * 
		 * @return page type
		 */
		@Override
		public Object getItem(int pPosition) {
			return mPageList.get(pPosition);
		}

		/**
		 * Returns item id.
		 * 
		 * @param pPosition
		 *            position of item
		 * 
		 * @return items position
		 */
		@Override
		public long getItemId(int pPosition) {
			return pPosition;
		}

		/**
		 * Returns view which represents item.
		 * 
		 * @param pPosition
		 *            position on the list
		 * @param pConvertView
		 *            converter view
		 * @param pParent
		 *            parent.
		 * 
		 * @return view which will be shown as item on ListView
		 */
		@Override
		public View getView(final int pPosition, View pConvertView, final ViewGroup pParent) {
			final RelativeLayout view = (RelativeLayout) View.inflate(mContext,
					R.layout.album_creator_menu_pages_list_icon, null);
			final ImageView image = (ImageView) view.findViewById(R.id.page_icon);
			final Button button = (Button) view.findViewById(R.id.delete_button);
			button.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					final int type = mPageList.get(pPosition);
					if (mOnItemRemoveListener != null) {
						mOnItemRemoveListener.onItemRemove(type, pPosition);
					}
					mPageList.remove(pPosition);
					PageListAdapter.this.notifyDataSetInvalidated();
				}
			});

			final int type = mPageList.get(pPosition);
			switch (type) {
			case R.id.create_title_page:
				if (getCount() == 1) {
					button.setVisibility(View.VISIBLE);
				} else {
					button.setVisibility(View.GONE);
				}
				image.setBackgroundResource(R.drawable.create_album_page01_title_normal_small);
				break;
			case R.id.create_page_with_one_photo:
				if (mPageList.contains(R.id.create_end_page)) {
					button.setVisibility(View.GONE);
				} else {
					button.setVisibility(View.VISIBLE);
				}
				image.setBackgroundResource(R.drawable.create_album_page02_1photo_normal_small);
				break;
			case R.id.create_page_with_two_photo:
				if (mPageList.contains(R.id.create_end_page)) {
					button.setVisibility(View.GONE);
				} else {
					button.setVisibility(View.VISIBLE);
				}
				image.setBackgroundResource(R.drawable.create_album_page03_2photos_normal_small);
				break;

			case R.id.create_page_with_three_photo:
				if (mPageList.contains(R.id.create_end_page)) {
					button.setVisibility(View.GONE);
				} else {
					button.setVisibility(View.VISIBLE);
				}
				image.setBackgroundResource(R.drawable.create_album_page04_3photos_normal_small);
				break;
			case R.id.create_end_page:
				image.setBackgroundResource(R.drawable.create_album_page05_signature_normal_small);
				break;
			default:
				throw new IllegalArgumentException("View " + type + " is not supported via this method.");
			}

			return view;

		}
	}

	/**
	 * Interface definition for a callback to be invoked when an item in this AdapterView has been removed.
	 */
	interface OnItemRemoveListener {
		/**
		 * Callback method to be invoked when an item in this AdapterView has been removed.
		 * 
		 * @param pItemType
		 *            type of item
		 * 
		 * @param position
		 *            position item on the list
		 */
		void onItemRemove(int pItemType, int position);
	}
}
