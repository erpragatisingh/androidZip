/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.albumcreator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.sprc.album.R;

/**
 * Abstract class which is the basic for all Activities which creates Albums page.
 * 
 */
abstract class AbstractAlbumPageCreator extends Activity {

	/**
	 * Code of photo chooser request.
	 */
	static final int PHOTO_CHOOSER_REQ = 1000;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_page_creator);
		final Bundle extras = getIntent().getExtras();
		if (extras == null) {
			throw new IllegalArgumentException();
		}

		final int pageType = extras.getInt(AlbumCreatorMenu.PAGE_TYPE_KEY, -1);
		initPageView(pageType);

	}

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		final View addButton = findViewById(R.id.add_button);
		final RelativeLayout layout = (RelativeLayout) findViewById(R.id.main_frame);
		layout.removeView(addButton);
		layout.addView(addButton);
	}

	/**
	 * Abstract method which initializes control to create albums page.
	 * 
	 * @param pPageType
	 *            type of page
	 */
	abstract void initPageView(int pPageType);

	/**
	 * On this method should puts data to intent.
	 * 
	 * @param intent
	 *            intent which will be send to activity which starts this activity for results
	 */
	abstract void putDataIntoIntent(final Intent intent);

	/**
	 * Adds view to main frame.
	 * 
	 * @param pView
	 *            view to create page
	 */
	void addViewToMainFrame(View pView) {
		final RelativeLayout pageWithPhotosFrame = (RelativeLayout) findViewById(R.id.page_with_photos_frame);
		pageWithPhotosFrame.addView(pView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
	}

	/**
	 * Called when add button will be clicked.
	 * 
	 * @param pView
	 *            add button.
	 */
	public void onAddButtonClick(View pView) {
		final Intent result = new Intent();

		putDataIntoIntent(result);

		setResult(Activity.RESULT_OK, result);
		finish();
	}

	/**
	 * Sets add button enabled.
	 */
	void unlockAddButton() {
		final Button addButton = (Button) findViewById(R.id.add_button);
		addButton.setEnabled(true);
	}

}
