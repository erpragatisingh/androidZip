/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Toast;

import com.sprc.album.R;
import com.sprc.album.activities.albumcreator.AlbumCreatorMenu;
import com.sprc.album.activities.photocreator.PhotoCreatorGetter;
import com.sprc.album.db.DbUtils;
import com.sprc.album.framework.TitleView;
import com.sprc.album.framework.TitleView.OnAnimationFinishedListener;
import com.sprc.album.framework.TitleView.TitleViewMode;

/**
 * Class which represents menu activity.
 */
public class MenuActivity extends Activity {

	private static final String ASSET_PATH = "menu.png";
	/**
	 * Offset for animations. There is used one animation for all buttons. There is changed only start offset.
	 */
	private static final int START_ANIMATION_OFFSET = 100;

	/**
	 * Button which open photo creator.
	 */
	private Button mCreatePhoto;

	/**
	 * Button which open albums creator.
	 */
	private Button mCreateAlbum;

	/**
	 * Button which open list of created albums.
	 */
	private Button mAlbums;

	private TitleView mMenuTitleView;

	@Override
	public void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);

		mCreatePhoto = (Button) findViewById(R.id.create_photo_btn);
		mCreateAlbum = (Button) findViewById(R.id.create_album_btn);
		mAlbums = (Button) findViewById(R.id.albums_btn);

		mCreatePhoto.setEnabled(false);
		mCreateAlbum.setEnabled(false);
		mAlbums.setEnabled(false);

		mMenuTitleView = (TitleView) findViewById(R.id.menu_title_view);
		prepareTitleView();
	}

	@Override
	protected void onStart() {
		super.onStart();
		startAnimationButtons(R.anim.start_menu_button_animation);
	}

	private void prepareTitleView() {
		mMenuTitleView.setAssetPath(ASSET_PATH);
		mMenuTitleView.setModeType(TitleViewMode.ANIM_INSCRIPTION);
		final TitleView.OnAnimationFinishedListener onAnimationFinishedListener = new OnAnimationFinishedListener() {

			@Override
			public void animationFinished() {
				mCreatePhoto.setEnabled(true);
				mCreateAlbum.setEnabled(true);
				mAlbums.setEnabled(true);
			}
		};
		mMenuTitleView.setOnAnimationFinshedListener(onAnimationFinishedListener);
	}

	/**
	 * Initialize method. Sets animations for all buttons.
	 */
	private void startAnimationButtons(final int pResAniamtion) {
		AnimationSet anim = (AnimationSet) AnimationUtils.loadAnimation(this, pResAniamtion);
		mCreatePhoto.startAnimation(anim);
		anim = (AnimationSet) AnimationUtils.loadAnimation(this, pResAniamtion);
		anim.setStartOffset(START_ANIMATION_OFFSET);
		mCreateAlbum.startAnimation(anim);
		anim = (AnimationSet) AnimationUtils.loadAnimation(this, pResAniamtion);
		anim.setStartOffset(START_ANIMATION_OFFSET * 2);
		mAlbums.startAnimation(anim);
	}

	/**
	 * Called when some button is press.
	 * 
	 * @param pView
	 *            - view which will be clicked
	 */
	public void onMenuButtonClick(final View pView) {
		switch (pView.getId()) {
		case R.id.create_photo_btn:
			startActivity(new Intent(MenuActivity.this, PhotoCreatorGetter.class));
			break;
		case R.id.create_album_btn:
			if (checkIfAnyPhotoExists()) {
				startActivity(new Intent(MenuActivity.this, AlbumCreatorMenu.class));
			} else {
				Toast.makeText(this, "Please create at least one photo", Toast.LENGTH_SHORT).show();
			}
			break;
		case R.id.albums_btn:
			startActivity(new Intent(MenuActivity.this, AlbumsActivity.class));
			break;
		default:
			throw new IllegalArgumentException("This listener can be use for this view " + pView.getId());
		}
	}

	private boolean checkIfAnyPhotoExists() {
		return DbUtils.getPhotoCount(this) > 0;
	}

	/**
	 * Closes the {@link TitleView}.
	 */
	@Override
	protected void onDestroy() {
		super.onDestroy();
		mMenuTitleView.closeTitleView();
	}
}
