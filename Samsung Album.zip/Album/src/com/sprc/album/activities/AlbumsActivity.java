/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;

import com.sprc.album.R;
import com.sprc.album.db.DbUtils;
import com.sprc.album.db.data.AlbumInfo;
import com.sprc.album.framework.AlbumIconView;
import com.sprc.album.framework.TitleView;
import com.sprc.album.framework.TitleView.OnAnimationFinishedListener;
import com.sprc.album.framework.TitleView.TitleViewMode;

/**
 * Class represents list of albums.
 */
public class AlbumsActivity extends Activity {

	/**
	 * Album id.
	 */
	public static final String ALBUM_ID = "ALBUM_ID";

	/**
	 * Album assets.
	 */
	private static final String ASSET_PATH = "albums.png";

	/**
	 * Title view.
	 */
	private TitleView mAlbumsTitleView;
	/**
	 * List of albums.
	 */
	private GridView mAlbumsGridView;

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.albums_list_layout);

		mAlbumsTitleView = (TitleView) findViewById(R.id.albums_title_view);
		mAlbumsGridView = (GridView) findViewById(R.id.albums_grid_view);

		perpareAlbumsGridView();
		prepareTitleView();
	}

	/**
	 * Prepares grid view.
	 */
	private void perpareAlbumsGridView() {
		mAlbumsGridView.setAdapter(new AlbumsAdapter(this, DbUtils.getAlbumsInfo(this)));

		mAlbumsGridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(final AdapterView<?> parent, final View v, final int position, final long id) {
				final int albumID = ((AlbumsAdapter) parent.getAdapter()).getItem(position).getId();

				final Intent intent = new Intent(AlbumsActivity.this, AlbumActivity.class);
				intent.putExtra(ALBUM_ID, albumID);
				startActivity(intent);
			}
		});
		mAlbumsGridView.setEmptyView(findViewById(R.id.empty_text));
		mAlbumsGridView.setEnabled(false);
	}

	/**
	 * Prepares title view.
	 */
	private void prepareTitleView() {
		mAlbumsTitleView.setAssetPath(ASSET_PATH);
		mAlbumsTitleView.setModeType(TitleViewMode.ANIM_INSCRIPTION);
		final TitleView.OnAnimationFinishedListener onAnimationFinishedListener = new OnAnimationFinishedListener() {

			@Override
			public void animationFinished() {
				mAlbumsGridView.setEnabled(true);
			}
		};
		mAlbumsTitleView.setOnAnimationFinshedListener(onAnimationFinishedListener);
	}

	/**
	 * Adapter for GridView.
	 */
	private static class AlbumsAdapter extends BaseAdapter {

		/**
		 * Context of application.
		 */
		private final Context mContext;
		/**
		 * List of albums.
		 */
		private final List<AlbumInfo> mAlbumsList;

		/**
		 * Constructor.
		 * 
		 * @param pContext
		 *            context of application
		 * @param pAlbumList
		 *            list of albums
		 */
		public AlbumsAdapter(final Context pContext, final List<AlbumInfo> pAlbumList) {
			mContext = pContext;
			mAlbumsList = new ArrayList<AlbumInfo>(pAlbumList);
		}

		/**
		 * Returns number of albums.
		 * 
		 * @return albums count
		 */
		@Override
		public int getCount() {
			return mAlbumsList.size();
		}

		/**
		 * Logical object which contains information about album.
		 * 
		 * @param pIndex
		 *            index of item which will be returned
		 * 
		 * @return information about album
		 */
		@Override
		public AlbumInfo getItem(final int pIndex) {
			return mAlbumsList.get(pIndex);
		}

		/**
		 * Returns number to identity view.
		 * 
		 * @param id
		 *            id of item
		 * 
		 * @return id
		 */
		@Override
		public long getItemId(final int id) {
			return id;
		}

		/**
		 * Returns view which represents album.
		 * 
		 * @param position
		 *            position of item
		 * @param pConvertView
		 *            contender view
		 * @param pParent
		 *            parent view
		 * 
		 * @return albums icons
		 */
		@Override
		public View getView(final int position, final View pConvertView, final ViewGroup pParent) {
			AlbumIconView albumIconView;
			if (pConvertView != null) {
				if (pConvertView instanceof AlbumIconView) {
					albumIconView = (AlbumIconView) pConvertView;
				} else {
					throw new IllegalArgumentException("View should be AlbumIconView type.");
				}
			} else {
				albumIconView = new AlbumIconView(mContext);
			}

			final AlbumInfo info = mAlbumsList.get(position);
			albumIconView.setMainPhoto(info.getPhoto());
			albumIconView.setAlbumName(info.getAlbumName());
			return albumIconView;
		}

	}
}
