/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.photocreator;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.SlidingDrawer;

import com.samsung.samm.common.SObjectStroke;
import com.samsung.spen.settings.SettingStrokeInfo;
import com.samsung.spensdk.SCanvasConstants;
import com.samsung.spensdk.SCanvasView;
import com.samsung.spensdk.applistener.SCanvasInitializeListener;
import com.samsung.spensdk.applistener.SettingStrokeChangeListener;
import com.sprc.album.R;
import com.sprc.album.framework.PaletteView;
import com.sprc.album.framework.PaletteView.OnColorSelectListener;
import com.sprc.album.utils.FileUtils;

/**
 * Class which represents step where user can draw something.
 */
public class PhotoCreatorPainter extends AbstractPhotoCreatorWithSCanvas {

	/** Paint palette. */
	private PaletteView mPaletteView;
	/** Color which is selected. */
	private int mSelectedColor = Color.TRANSPARENT;
	/** Type which is selected. */
	private int mSlecetedType = SCanvasConstants.SCANVAS_MODE_INPUT_PEN;

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_creator_photo_painter);
		mPaletteView = (PaletteView) findViewById(R.id.paint_palette);
		setOnColorSelectListenerForPalletView();
		createSettingView();
		final SlidingDrawer typeFilter = (SlidingDrawer) findViewById(R.id.pallete_tools);
		typeFilter.open();

	}

	private void createSettingView() {
		final RelativeLayout container = (RelativeLayout) findViewById(R.id.main_frame);
		final SCanvasView photoView = getPhotoView();
		photoView.createSettingView(container, null, null);
		photoView.setSettingStrokeChangeListener(new SettingStrokeChangeListener() {

			@Override
			public void onStrokeWidthChanged(int pStrokeWidth) {
				// Do nothing
			}

			@Override
			public void onStrokeStyleChanged(int pStrokeSty) {
				final int res;
				switch (pStrokeSty) {
				case SObjectStroke.SAMM_STROKE_STYLE_PENCIL:
					res = R.id.pen_tool_btn;
					break;
				case SObjectStroke.SAMM_STROKE_STYLE_BRUSH:
					res = R.id.brush1_tool_btn;
					break;
				case SObjectStroke.SAMM_STROKE_STYLE_CHINESE_BRUSH:
					res = R.id.brush2_tool_btn;
					break;
				case SObjectStroke.SAMM_STROKE_STYLE_CRAYON:
					res = R.id.pencil_tool_btn;
					break;
				case SObjectStroke.SAMM_STROKE_STYLE_MARKER:
					res = R.id.marker_tool_btn;
					break;
				case SObjectStroke.SAMM_STROKE_STYLE_ERASER:
					res = R.id.eraserr_tool_btn;
					break;
				default:
					throw new IllegalArgumentException();
				}

				final RadioButton rb = (RadioButton) findViewById(res);
				rb.setChecked(true);

			}

			@Override
			public void onStrokeColorChanged(int pStrokeColor) {
				mSelectedColor = pStrokeColor;
				mPaletteView.setSelectedColor(pStrokeColor);
			}

			@Override
			public void onStrokeAlphaChanged(int pStrokeAlpha) {
				// Do nothing
			}

			@Override
			public void onEraserWidthChanged(int pStrokeEraserWidth) {
				// Do nothing
			}

			@Override
			public void onClearAll(boolean pClearAll) {
				// Do nothing
			}
		});
	}

	private void setOnColorSelectListenerForPalletView() {
		final OnColorSelectListener onColorSelectListener = new OnColorSelectListener() {

			@Override
			public void onColorSelect(View pView, int pColor) {
				final SCanvasView photoView = getPhotoView();
				final SettingStrokeInfo settinStrokeInfo = photoView.getSettingViewStrokeInfo();
				if (pColor != Color.TRANSPARENT) {
					mSelectedColor = pColor;
					mPaletteView.setSelectedColor(Color.TRANSPARENT);
					settinStrokeInfo.setStrokeColor(pColor);
					if (mSlecetedType != SObjectStroke.SAMM_STROKE_STYLE_ERASER) {
						settinStrokeInfo.setStrokeStyle(mSlecetedType);
					}
					photoView.setSettingViewStrokeInfo(settinStrokeInfo);
					mPaletteView.setSelectedColor(pColor);
				} else {
					if (mSlecetedType != SObjectStroke.SAMM_STROKE_STYLE_ERASER) {
						photoView.showSettingView(SCanvasConstants.SCANVAS_SETTINGVIEW_SIZE_MINI, true);
						mPaletteView.setSelectedColor(mSelectedColor);

					} else {
						photoView.showSettingView(SCanvasConstants.SCANVAS_SETTINGVIEW_ERASER, true);
						mPaletteView.setSelectedColor(pColor);
					}
				}

			}
		};
		mPaletteView.setOnColorSelectListener(onColorSelectListener);
	}

	@Override
	public void setSCanvasViewSetting(final SCanvasView pSCanvasView) {
		pSCanvasView.setSCanvasInitializeListener(new SCanvasInitializeListener() {

			@Override
			public void onInitialized() {
				setPhotoFromFile();
			}
		});
	}

	/**
	 * Called when some tool from paint tool was selected.
	 * 
	 * @param pView
	 *            view which represents selected tool.
	 */
	public void onPaintToolSelected(View pView) {
		final SCanvasView photoView = getPhotoView();

		switch (pView.getId()) {
		case R.id.pen_tool_btn:
			onDrawToolSelected(photoView, SObjectStroke.SAMM_STROKE_STYLE_PENCIL);
			break;
		case R.id.brush1_tool_btn:
			onDrawToolSelected(photoView, SObjectStroke.SAMM_STROKE_STYLE_BRUSH);
			break;
		case R.id.brush2_tool_btn:
			onDrawToolSelected(photoView, SObjectStroke.SAMM_STROKE_STYLE_CHINESE_BRUSH);
			break;
		case R.id.pencil_tool_btn:
			onDrawToolSelected(photoView, SObjectStroke.SAMM_STROKE_STYLE_CRAYON);
			break;
		case R.id.marker_tool_btn:
			onDrawToolSelected(photoView, SObjectStroke.SAMM_STROKE_STYLE_MARKER);
			break;
		case R.id.eraserr_tool_btn:
			if (photoView.isSettingViewVisible(SCanvasConstants.SCANVAS_SETTINGVIEW_SIZE_MINI)) {
				photoView.toggleShowSettingView(SCanvasConstants.SCANVAS_SETTINGVIEW_SIZE_MINI);
				photoView.showSettingView(SCanvasConstants.SCANVAS_SETTINGVIEW_ERASER, true);

			}
			photoView.setCanvasMode(SCanvasConstants.SCANVAS_MODE_INPUT_ERASER);
			mSlecetedType = SObjectStroke.SAMM_STROKE_STYLE_ERASER;
			mPaletteView.setSelectedColor(Color.TRANSPARENT);
			mPaletteView.setEnabled(false);
			return;
		default:
			throw new IllegalArgumentException(Integer.toString(pView.getId()));
		}
		final SettingStrokeInfo settinStrokeInfo = photoView.getSettingViewStrokeInfo();

		if (mSlecetedType != SObjectStroke.SAMM_STROKE_STYLE_ERASER) {
			settinStrokeInfo.setStrokeStyle(mSlecetedType);
		}
		photoView.setSettingViewStrokeInfo(settinStrokeInfo);
	}

	private void onDrawToolSelected(SCanvasView scanvasView, int selectedType) {
		if (scanvasView.isSettingViewVisible(SCanvasConstants.SCANVAS_SETTINGVIEW_ERASER)) {
			scanvasView.toggleShowSettingView(SCanvasConstants.SCANVAS_SETTINGVIEW_ERASER);
			scanvasView.showSettingView(SCanvasConstants.SCANVAS_SETTINGVIEW_SIZE_MINI, true);
		}
		scanvasView.setCanvasMode(SCanvasConstants.SCANVAS_MODE_INPUT_PEN);
		mSlecetedType = selectedType;
		mPaletteView.setEnabled(true);
		mPaletteView.setSelectedColor(mSelectedColor);
	}

	@Override
	protected void onNextButtonClick() {
		super.onNextButtonClick();
		final Intent creatorPhoto = new Intent(this, PhotoCreatorComics.class);
		FileUtils.saveBitmap(mPhoto);
		startActivity(creatorPhoto);
	}

	@Override
	protected void onPreviousButtonClick() {
		finish();
	}

}
