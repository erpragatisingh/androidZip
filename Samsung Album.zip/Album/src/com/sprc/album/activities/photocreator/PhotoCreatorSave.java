/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.photocreator;

import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.Toast;

import com.sprc.album.activities.MenuActivity;
import com.sprc.album.activities.fragments.SavePhotoFragment;
import com.sprc.album.activities.fragments.SavePhotoFragment.OnSavePhotoListener;
import com.sprc.album.db.DbUtils;
import com.sprc.album.db.data.Photo;
import com.sprc.album.db.data.Photo.Builder;

/**
 * Photo creator which allows to save the photo to the database.
 */
public class PhotoCreatorSave extends AbstractPhotoCreatorWithImageView implements OnSavePhotoListener {

	private static final int SIZE = 300;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setPhotoFromFile();
	}

	@Override
	protected void onNextButtonClick() {
		showPopup();
	}

	/**
	 * Shows pop-up dialog fragment with option to save the photo or to cancel the action.
	 */
	private void showPopup() {
		final FragmentManager fragmentManager = getFragmentManager();
		final SavePhotoFragment savePhotoDialog = new SavePhotoFragment();
		savePhotoDialog.show(fragmentManager, "save");
	}

	@Override
	public void savePhoto(boolean save) {
		if (save) {
			savePhotoToDatabase();
			backToMenu();
		}
	}

	/**
	 * Creates a photo and inserts it to the database.
	 */
	private void savePhotoToDatabase() {
		// @formatter:off
		final Bitmap copyToSave = Bitmap.createScaledBitmap(mPhoto, SIZE, SIZE, false);
		final Photo photo = new Builder().setPhoto(copyToSave).build();
		// @formatter:on

		DbUtils.insertPhoto(this, photo);
		Toast.makeText(this, "Photo has been saved", Toast.LENGTH_SHORT).show();
	}

	@Override
	protected void onPreviousButtonClick() {
		finish();
	}

	private void backToMenu() {
		final Intent intent = new Intent(this, MenuActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
	}

}
