/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.photocreator;

import java.util.List;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.sprc.album.R;
import com.sprc.album.db.DbUtils;
import com.sprc.album.db.data.AlbumInfo;
import com.sprc.album.db.data.Photo;
import com.sprc.album.utils.FileUtils;

/**
 * Class which represents activity to select way to get photo.
 */
public class PhotoCreatorGetter extends AbstractPhotoCreatorWithImageView {

	/** Camera request. */
	private static final int CAMERA_REQUEST = 1001;
	/** Gallery request. */
	private static final int GALLERY_REQUEST = 1002;
	/** Picture cropping request. */
	private static final int PICTURE_CROPPING = 1003;

	/** Picture size. */
	public static final int PICTURE_SIZE = 600;

	/** Next button - used to go to next step. */
	private Button mButtonNext;

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_creator_photo_getter);

		mButtonNext = (Button) findViewById(R.id.next_button);
		mButtonNext.setEnabled(false);
		final List<AlbumInfo> albums = DbUtils.getAlbumsInfo(this);
		Log.e("TAG", "albums: " + Integer.toString(albums.size()));
		final List<Photo> photos = DbUtils.getPhotos(this);
		Log.e("TAG", "photos: " + Integer.toString(photos.size()));

		final ImageView imageView = (ImageView) findViewById(R.id.photo_image_view);
		imageView.setBackgroundResource(R.drawable.template_img);
	}

	/**
	 * Called when some button from tools is pressed.
	 * 
	 * @param pView
	 *            view which used this method.
	 */
	public void onToolsButtonClick(final View pView) {
		switch (pView.getId()) {
		case R.id.photo_getter_camera_btn:
			final Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(cameraIntent, CAMERA_REQUEST);
			break;
		case R.id.photo_getter_gallery_btn:
			final Intent galleryIntent = new Intent(Intent.ACTION_PICK,
					android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
			startActivityForResult(galleryIntent, GALLERY_REQUEST);
			break;
		default:
			throw new IllegalArgumentException("This listener can be use for this view " + pView.getId());
		}
	}

	@Override
	protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {

		if ((requestCode == CAMERA_REQUEST || requestCode == GALLERY_REQUEST) && resultCode == RESULT_OK) {
			if (data == null) {
				Toast.makeText(this, "Something was wrong - no find photo try again in other resources",
						Toast.LENGTH_LONG).show();
				return;
			}

			final Uri selectedImage = data.getData();

			final Intent intent = new Intent("com.android.camera.action.CROP");

			intent.setDataAndType(selectedImage, "image/*");

			intent.putExtra("crop", "true");
			intent.putExtra("scale", true);

			intent.putExtra("aspectX", 1);
			intent.putExtra("aspectY", 1);

			intent.putExtra("outputX", PICTURE_SIZE);
			intent.putExtra("outputY", PICTURE_SIZE);
			intent.putExtra(MediaStore.EXTRA_OUTPUT, FileUtils.getTempUri());
			intent.putExtra("outputFormat", Bitmap.CompressFormat.PNG.toString());

			startActivityForResult(intent, PICTURE_CROPPING);

		} else if (requestCode == PICTURE_CROPPING && resultCode == RESULT_OK && data != null) {

			mPhoto = FileUtils.loadBitmap();
			if (mPhoto != null) {
				setImageBitmap(mPhoto);
				getPhotoView().setBackgroundColor(Color.WHITE);
				mButtonNext.setEnabled(true);
			}
		}
	}

	@Override
	protected void onNextButtonClick() {
		if (mPhoto != null) {
			final Intent creatorPhoto = new Intent(this, PhotoCreatorFilter.class);
			FileUtils.saveBitmap(mPhoto);
			startActivity(creatorPhoto);
		}
	}

	@Override
	protected void onPreviousButtonClick() {
		finish();
	}
}
