/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.photocreator;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SlidingDrawer;
import android.widget.Toast;

import com.samsung.samm.common.SObject;
import com.samsung.samm.common.SObjectImage;
import com.samsung.samm.common.SObjectStroke;
import com.samsung.samm.common.SOptionSAMM;
import com.samsung.samm.common.SOptionSCanvas;
import com.samsung.spensdk.SCanvasConstants;
import com.samsung.spensdk.SCanvasView;
import com.samsung.spensdk.applistener.SCanvasInitializeListener;
import com.samsung.spensdk.applistener.SObjectUpdateListener;
import com.sprc.album.R;
import com.sprc.album.utils.FileUtils;
import com.sprc.album.utils.Preconditions;

/**
 * Class which represents step where user can set clouds and text.
 */
public class PhotoCreatorComics extends AbstractPhotoCreatorWithSCanvas {

	private SCanvasView mSCanvasView;

	private final SObjectUpdateListener mUpdateListener = new SObjectUpdateListener() {

		@Override
		public boolean onSObjectStrokeInserting(SObjectStroke arg0) {
			return true;
		}

		@Override
		public void onSObjectSelected(SObject sObject, boolean bSelected) {
			getPhotoView().setDrawable(bSelected);
		}

		@Override
		public void onSObjectInserted(SObject arg0, boolean arg1, boolean arg2) {
			// Does nothing intentionally.
		}

		@Override
		public void onSObjectDeleted(SObject arg0, boolean arg1, boolean arg2, boolean arg3) {
			if (arg0 instanceof SObjectImage) {
				--mCloudCount;
			}
		}

		@Override
		public void onSObjectClearAll(boolean arg0) {
			// Does nothing intentionally.
		}

		@Override
		public void onSObjectChanged(SObject arg0, boolean arg1, boolean arg2) {
		}
	};

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_creator_photo_comics);
		mSCanvasView = getPhotoView();
		mSCanvasView.createSettingView((ViewGroup) findViewById(R.id.main_frame), null);
		mSCanvasView.setDrawable(false);
		mSCanvasView.setZoomEnable(false);
		mSCanvasView.setSObjectUpdateListener(mUpdateListener);

		((SlidingDrawer) findViewById(R.id.cartoon_list)).open();
	}

	/**
	 * Called when any view (cloud) has been clicked.
	 * 
	 * @param view
	 *            cloud's view
	 */
	public void onCloudClick(View view) {
		final Bitmap bitmap;

		switch (view.getId()) {
		case R.id.cartoon_cloud_rounded:
			bitmap = getBitmap(R.drawable.cartoon_cloud_rounded_img);
			break;
		case R.id.cartoon_cloud_square:
			bitmap = getBitmap(R.drawable.cartoon_cloud_square_img);
			break;
		case R.id.cartoon_cloud_thought:
			bitmap = getBitmap(R.drawable.cartoon_cloud_thought_img);
			break;
		default:
			throw new IllegalArgumentException();
		}

		if (mSCanvasView.isSettingViewVisible(SCanvasConstants.SCANVAS_SETTINGVIEW_TEXT)) {
			mSCanvasView.toggleShowSettingView(SCanvasConstants.SCANVAS_SETTINGVIEW_TEXT);
		}
		insertBitmap(bitmap);
	}

	/**
	 * Called when the text button has been clicked.
	 * 
	 * @param view
	 *            clicked view
	 */
	public void onInsertTextClick(View view) {
		mSCanvasView.setCanvasMode(SCanvasConstants.SCANVAS_MODE_INPUT_TEXT);
		mSCanvasView.setDrawable(true);
		mSCanvasView.toggleShowSettingView(SCanvasConstants.SCANVAS_SETTINGVIEW_TEXT);
	}

	private Bitmap getBitmap(int drawableId) {
		return loadBitmap(drawableId);
	}

	private Bitmap loadBitmap(int drawableId) {
		return Preconditions.checkNotNull(BitmapFactory.decodeResource(getResources(), drawableId));
	}

	private static final int CLOUD_MAX_COUNT = 10;
	private int mCloudCount = 0;

	private void insertBitmap(Bitmap bitmap) {
		mSCanvasView.setCanvasMode(SCanvasConstants.SCANVAS_MODE_INPUT_IMAGE);

		if (mCloudCount < CLOUD_MAX_COUNT) {
			final RectF rectF = getDefaultImageRect(bitmap, mSCanvasView);
			final SObjectImage sImageObject = new SObjectImage();
			sImageObject.setRect(rectF);
			sImageObject.setImageBitmap(bitmap);

			// SCanvasView option settings
			final SOptionSCanvas canvasOption = Preconditions.checkNotNull(mSCanvasView.getOption());
			canvasOption.mSAMMOption.setContentsQuality(SOptionSAMM.SAMM_CONTETNS_QUALITY_ORIGINAL);
			mSCanvasView.setOption(canvasOption);

			final boolean result = mSCanvasView.insertSAMMImage(sImageObject, true);

			if (!result) {
				Toast.makeText(this, "Can't insert the image", Toast.LENGTH_SHORT).show();
			} else {
				++mCloudCount;
			}
		} else {
			Toast.makeText(this, "You have reached 10 clouds limit.", Toast.LENGTH_SHORT).show();
		}
	}

	private RectF getDefaultImageRect(Bitmap strImagePath, SCanvasView pSCanvasView) {
		// generic solution that works well with both rectangular and square SCanvasViews
		final int nImageWidth = strImagePath.getWidth();
		final int nImageHeight = strImagePath.getHeight();
		final int nScreenWidth = pSCanvasView.getWidth();
		final int nScreenHeight = pSCanvasView.getHeight();
		final int nBoxRadius = nScreenWidth > nScreenHeight ? nScreenHeight / 4 : nScreenWidth / 4;
		final int nCenterX = nScreenWidth / 2;
		final int nCenterY = nScreenHeight / 2;
		if (nImageWidth > nImageHeight) {
			return new RectF(nCenterX - nBoxRadius, nCenterY - nBoxRadius * nImageHeight / nImageWidth, nCenterX
					+ nBoxRadius, nCenterY + nBoxRadius * nImageHeight / nImageWidth);
		} else {
			return new RectF(nCenterX - nBoxRadius * nImageWidth / nImageHeight, nCenterY - nBoxRadius, nCenterX
					+ nBoxRadius * nImageWidth / nImageHeight, nCenterY + nBoxRadius);
		}
	}

	@Override
	public void setSCanvasViewSetting(final SCanvasView pSCanvasView) {
		pSCanvasView.setSCanvasInitializeListener(new SCanvasInitializeListener() {

			@Override
			public void onInitialized() {
				setPhotoFromFile();
			}
		});
	}

	@Override
	protected void onNextButtonClick() {
		super.onNextButtonClick();
		final Intent creatorPhoto = new Intent(this, PhotoCreatorSave.class);
		FileUtils.saveBitmap(mPhoto);
		startActivity(creatorPhoto);
	}

	@Override
	protected void onPreviousButtonClick() {
		finish();
	}

}
