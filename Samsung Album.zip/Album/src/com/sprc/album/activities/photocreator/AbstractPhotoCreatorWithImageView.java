/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.photocreator;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.sprc.album.R;

/**
 * Basic class for all Activities form creator which do not use SCanvasView.
 */
abstract class AbstractPhotoCreatorWithImageView extends AbstractPhotoCreator<ImageView> {

	/**
	 * Reference to frame where will be added functionality view.
	 */
	private RelativeLayout mMainFrame;

	/**
	 * Reference to view which displayed photo.
	 */
	private ImageView mImageView;

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mMainFrame = (RelativeLayout) findViewById(R.id.main_frame);
		final View inflateView = getLayoutInflater().inflate(R.layout.activity_creator_photo_image_view, null);
		mMainFrame.addView(inflateView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		mImageView = (ImageView) findViewById(R.id.photo_image_view);
	}

	@Override
	public void setImageBitmap(final Bitmap pPhoto) {
		mImageView.setImageBitmap(pPhoto);
	}

	@Override
	public void setContentView(final int pLayoutResID) {
		final View inflateView = getLayoutInflater().inflate(pLayoutResID, null);
		mMainFrame.addView(inflateView);
	}

	@Override
	public ImageView getPhotoView() {
		return mImageView;
	}

}
