/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.photocreator;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.sprc.album.R;
import com.sprc.album.utils.FileUtils;

/**
 * Basic class for all Activities which are used in photo creator.
 * 
 * @param <T>
 *            this class should be parameterized via SCanvasView or ImageView
 */
abstract class AbstractPhotoCreator<T extends View> extends Activity {

	/**
	 * Bitmap which will be modified in a step.
	 */
	Bitmap mPhoto;

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		super.setContentView(R.layout.activity_creator_photo);
	}

	/**
	 * Called when button was clicked. This action is defined in xml file.
	 * 
	 * @param pView
	 *            view which called this method. It should be button with id one of them next_button or previous_button,
	 *            otherwise this method throw exception
	 * 
	 */
	public void onButtonClick(final View pView) {
		switch (pView.getId()) {
		case R.id.next_button:
			onNextButtonClick();
			break;
		case R.id.previous_button:
			onPreviousButtonClick();
			break;
		default:
			throw new IllegalArgumentException("Unsupported view used method!");
		}
	}

	/**
	 * Sets photo from intent.<br />
	 * <B> If activity doesn't have bitmap in Bundle object this method throws exception.</B>
	 */
	public void setPhotoFromFile() {
		mPhoto = FileUtils.loadBitmap();
		if (mPhoto != null) {
			setImageBitmap(mPhoto);
		} else {
			Toast.makeText(this, "Fail to set Background Image Path.", Toast.LENGTH_LONG).show();
		}

	}

	/**
	 * Called when next button is clicked.
	 */
	protected abstract void onNextButtonClick();

	/**
	 * Called when previous button is clicked.
	 */
	protected abstract void onPreviousButtonClick();

	/**
	 * Sets photo from intent.
	 * 
	 * @param pPhoto
	 *            photo which will be set in view
	 */
	public abstract void setImageBitmap(Bitmap pPhoto);

	/**
	 * Returns View (SCanvasView or ImageView).
	 * 
	 * @return view where bitmap is set.
	 */
	public abstract T getPhotoView();
}
