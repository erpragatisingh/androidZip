/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.photocreator;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.RelativeLayout;

import com.samsung.spensdk.SCanvasView;
import com.sprc.album.R;
import com.sprc.album.utils.Preconditions;

/**
 * Basic class for all Activities form creator which use SCanvasView.
 */
abstract class AbstractPhotoCreatorWithSCanvas extends AbstractPhotoCreator<SCanvasView> {

	/**
	 * Reference to frame where will be added functionality view.
	 */
	private RelativeLayout mMainFrame;

	/**
	 * Reference to SCanvasView.
	 */
	private SCanvasView mSCanvasView;

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mMainFrame = (RelativeLayout) findViewById(R.id.main_frame);
		final View inflateView = getLayoutInflater().inflate(R.layout.activity_creator_photo_scanvas, null);
		mMainFrame.addView(inflateView, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		mSCanvasView = (SCanvasView) findViewById(R.id.photo_spen_view);
		setSCanvasViewSetting(mSCanvasView);
	}

	@Override
	public void setContentView(final int pLayoutResID) {
		final View inflateView = getLayoutInflater().inflate(pLayoutResID, null);
		mMainFrame.addView(inflateView);
	}

	@Override
	public void setImageBitmap(final Bitmap photo) {
		mSCanvasView.setBackgroundImage(photo);
	}

	@Override
	public SCanvasView getPhotoView() {
		return mSCanvasView;

	}

	@Override
	protected void onNextButtonClick() {
		if (mSCanvasView.isSObjectSelected()) {
			// Unselect the object.
			mSCanvasView.undo();
			mSCanvasView.redo();
		}

		mPhoto = Preconditions.checkNotNull(mSCanvasView.getCanvasBitmap(false));
		mPhoto = Bitmap.createScaledBitmap(mPhoto, PhotoCreatorGetter.PICTURE_SIZE, PhotoCreatorGetter.PICTURE_SIZE,
				false);
	}

	/**
	 * Sets SCanvasView setting.
	 * 
	 * @param pSCanvasView
	 *            - SCanvasView which is on activities
	 */
	public abstract void setSCanvasViewSetting(final SCanvasView pSCanvasView);
}
