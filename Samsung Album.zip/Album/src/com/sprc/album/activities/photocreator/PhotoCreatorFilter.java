/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.photocreator;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.SlidingDrawer;
import android.widget.TextView;
import android.widget.Toast;

import com.samsung.spen.lib.image.SPenImageFilter;
import com.samsung.spen.lib.image.SPenImageFilterConstants;
import com.sprc.album.R;
import com.sprc.album.utils.FileUtils;

/**
 * Class which represents step where user can set filter.
 */
public class PhotoCreatorFilter extends AbstractPhotoCreatorWithImageView {

	/**
	 * List of filters.
	 */
	private ListView mFiltersListView;

	/**
	 * Reference to bitmap which is filtered.
	 */
	private Bitmap mFilterPhoto;

	/**
	 * Type of filter.
	 */
	private int mTypeFilter = SPenImageFilterConstants.FILTER_LEVEL_VERYLARGE;

	/**
	 * Image operation.
	 */
	private int mImageOperation = SPenImageFilterConstants.FILTER_ORIGINAL;

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_creator_photo_filters);

		mFiltersListView = (ListView) findViewById(R.id.filters_list);

		prepareFiltersListView();
		prepareFiltersTypeRadioGrop();
		setPhotoFromFile();
		if (mPhoto != null) {
			mFilterPhoto = Bitmap.createBitmap(mPhoto);
		}

		final SlidingDrawer filterList = (SlidingDrawer) findViewById(R.id.drawer_filter_list);
		filterList.open();
	}

	/**
	 * Called when type of filter was changed.
	 * 
	 * @param pView
	 *            view which was selected
	 */
	public void onFilterTypeSelected(final View pView) {
		switch (pView.getId()) {
		case R.id.very_large_btn:
			mTypeFilter = SPenImageFilterConstants.FILTER_LEVEL_VERYLARGE;
			break;
		case R.id.large_btn:
			mTypeFilter = SPenImageFilterConstants.FILTER_LEVEL_LARGE;
			break;
		case R.id.medium_btn:
			mTypeFilter = SPenImageFilterConstants.FILTER_LEVEL_MEDIUM;
			break;
		case R.id.small_btn:
			mTypeFilter = SPenImageFilterConstants.FILTER_LEVEL_SMALL;
			break;
		case R.id.very_small_btn:
			mTypeFilter = SPenImageFilterConstants.FILTER_LEVEL_VERYSMALL;
			break;

		default:
			throw new IllegalArgumentException("This method shouldn't called for " + pView.getId());

		}
		pView.setSelected(true);
		onFilterChanged();
	}

	/**
	 * Prepares list of filters.
	 */
	private void prepareFiltersListView() {
		mFiltersListView.setAdapter(new FilterListAdapter(this));
		mFiltersListView.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);

		final OnItemClickListener onItemClickListener = new OnItemClickListener() {

			@Override
			public void onItemClick(final AdapterView<?> pParent, final View pView, final int pPosition, final long pId) {
				mImageOperation = (Integer) pParent.getItemAtPosition(pPosition);
				onFilterChanged();
			}
		};
		mFiltersListView.setOnItemClickListener(onItemClickListener);
		mFiltersListView.setItemChecked(0, true);

	}

	private void onFilterChanged() {
		if (mPhoto == null) {
			Toast.makeText(PhotoCreatorFilter.this, "Input image does not selected!, select Image firtsly",
					Toast.LENGTH_SHORT).show();
			return;
		}

		if (mImageOperation == SPenImageFilterConstants.FILTER_ORIGINAL) {
			mFilterPhoto = Bitmap.createBitmap(mPhoto);
			setImageBitmap(mPhoto);
		} else {
			mFilterPhoto = SPenImageFilter.filterImageCopy(mPhoto, mImageOperation, mTypeFilter);
			if (mFilterPhoto != null) {
				setImageBitmap(mFilterPhoto);
			} else {
				Toast.makeText(PhotoCreatorFilter.this, "Fail to apply image filter", Toast.LENGTH_LONG).show();
			}
		}
	}

	private void prepareFiltersTypeRadioGrop() {
		final RadioButton r = (RadioButton) findViewById(R.id.very_large_btn);
		r.setChecked(true);
	}

	@Override
	protected void onNextButtonClick() {
		if (mFilterPhoto != null) {
			final Intent creatorPhoto = new Intent(this, PhotoCreatorPainter.class);
			FileUtils.saveBitmap(mFilterPhoto);
			startActivity(creatorPhoto);
		}
	}

	@Override
	protected void onPreviousButtonClick() {
		finish();
	}

	/**
	 * Class which represents adapter for filter list.
	 */
	private static class FilterListAdapter extends BaseAdapter {

		/**
		 * Image operations.
		 */
		private final int[] mImageOperationByIndex = { SPenImageFilterConstants.FILTER_ORIGINAL,
				SPenImageFilterConstants.FILTER_GRAY, SPenImageFilterConstants.FILTER_SEPIA,
				SPenImageFilterConstants.FILTER_NEGATIVE, SPenImageFilterConstants.FILTER_BRIGHT,
				SPenImageFilterConstants.FILTER_DARK, SPenImageFilterConstants.FILTER_VINTAGE,
				SPenImageFilterConstants.FILTER_OLDPHOTO, SPenImageFilterConstants.FILTER_FADEDCOLOR,
				SPenImageFilterConstants.FILTER_VIGNETTE, SPenImageFilterConstants.FILTER_VIVID,
				SPenImageFilterConstants.FILTER_COLORIZE, SPenImageFilterConstants.FILTER_BLUR,
				SPenImageFilterConstants.FILTER_PENCILSKETCH, SPenImageFilterConstants.FILTER_FUSAIN,
				SPenImageFilterConstants.FILTER_PENSKETCH, SPenImageFilterConstants.FILTER_PASTELSKETCH,
				SPenImageFilterConstants.FILTER_COLORSKETCH, SPenImageFilterConstants.FILTER_PENCILPASTELSKETCH,
				SPenImageFilterConstants.FILTER_PENCILCOLORSKETCH, SPenImageFilterConstants.FILTER_RETRO,
				SPenImageFilterConstants.FILTER_SUNSHINE, SPenImageFilterConstants.FILTER_DOWNLIGHT,
				SPenImageFilterConstants.FILTER_BLUEWASH, SPenImageFilterConstants.FILTER_NOSTALGIA,
				SPenImageFilterConstants.FILTER_YELLOWGLOW, SPenImageFilterConstants.FILTER_SOFTGLOW,
				SPenImageFilterConstants.FILTER_MOSAIC, SPenImageFilterConstants.FILTER_POPART,
				SPenImageFilterConstants.FILTER_MAGICPEN, SPenImageFilterConstants.FILTER_OILPAINT,
				SPenImageFilterConstants.FILTER_POSTERIZE, SPenImageFilterConstants.FILTER_CARTOONIZE,
				SPenImageFilterConstants.FILTER_CLASSIC };

		/**
		 * Context application.
		 */
		private final Context mContext;

		/**
		 * Labels for list.
		 */
		private final CharSequence[] mLabels;;

		/**
		 * Constructor.
		 * 
		 * @param pContext
		 *            context of application
		 */
		public FilterListAdapter(final Context pContext) {
			mContext = pContext;
			final Resources r = mContext.getResources();
			mLabels = r.getTextArray(R.array.filter_types);
			if (mLabels.length != mImageOperationByIndex.length) {
				throw new IndexOutOfBoundsException("Colection of labels should be the same as colection of objects.");
			}
		}

		/**
		 * Returns information about number of elements.
		 * 
		 * @return element count
		 */
		@Override
		public int getCount() {
			return mImageOperationByIndex.length;
		}

		/**
		 * Returns image operation which was selected.
		 * 
		 * @return image operation.
		 */
		@Override
		public Object getItem(final int position) {
			return mImageOperationByIndex[position];
		}

		/**
		 * Returns item id which is the same as position.
		 * 
		 * @return item id
		 */
		@Override
		public long getItemId(final int position) {
			return position;
		}

		/**
		 * Returns view which will be used as list item.
		 * 
		 * @return view for list
		 */
		@Override
		public View getView(final int position, final View convertView, final ViewGroup parent) {
			final TextView result = (TextView) View.inflate(mContext, R.layout.filter_list_item, null);
			result.setText(mLabels[position]);
			return result;
		}
	}

}
