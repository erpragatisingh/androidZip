/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities;

import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Toast;

import com.samsung.spen.lib.input.SPenEventLibrary;
import com.samsung.spensdk.applistener.SPenHoverListener;
import com.sprc.album.R;
import com.sprc.album.db.DbUtils;
import com.sprc.album.db.data.AlbumPage;
import com.sprc.album.framework.CustomPageFlipperView;
import com.sprc.album.framework.CustomPageFlipperView.ChangeType;
import com.sprc.album.framework.CustomPageFlipperView.OnPageChangeListener;
import com.sprc.album.framework.PageWithOnePhotoAndSCanvasDesc;
import com.sprc.album.framework.PageWithPhotos;
import com.sprc.album.framework.PageWithSCanvasDesc;
import com.sprc.album.framework.TitleView.TitleViewMode;
import com.sprc.album.logic.album.Album;

/**
 * Activity which represents album. This activity displayed page of albums.
 * 
 */
public class AlbumActivity extends Activity {

	/** Logical object album. Contains collection and photo. */
	private Album mAlbum;

	/** Custom view which allows to change page with animations. */
	private CustomPageFlipperView mPageViewFlipper;

	/** Index current page. */
	private int mIndexCurrentPage;

	/** Information that message about previous button was shown. */
	private boolean mShownPreviousMessage;
	/** Information that message about next button was shown. */
	private boolean mShownNextMessage;
	private View mLeftButton;
	private View mRightButton;

	private final SPenHoverListener mOnHoverListener = new SPenHoverListener() {

		@Override
		public boolean onHover(View view, MotionEvent event) {
			final AnimationDrawable animation = (AnimationDrawable) view.getBackground();

			switch (event.getAction()) {
			case MotionEvent.ACTION_HOVER_ENTER:

				if (view.getId() == R.id.album_button_right) {
					if (!mShownNextMessage) {
						Toast.makeText(AlbumActivity.this, R.string.click_side_button_to_go_next, Toast.LENGTH_SHORT)
								.show();
						mShownNextMessage = true;
					}
				} else {
					if (!mShownPreviousMessage) {
						Toast.makeText(AlbumActivity.this, R.string.click_side_button_to_go_previous,
								Toast.LENGTH_SHORT).show();
						mShownPreviousMessage = true;
					}
				}

				animation.start();
				return true;
			case MotionEvent.ACTION_HOVER_EXIT:
				animation.stop();
				return true;
			default:
				return false;
			}
		}

		@Override
		public void onHoverButtonDown(View view, MotionEvent event) {
			if (view.isActivated()) {
				switch (view.getId()) {
				case R.id.album_button_right:
					displayPage(ChangeType.NEXT_PAGE);
					break;
				case R.id.album_button_left:
					displayPage(ChangeType.PREV_PAGE);
					break;
				default:
					throw new IllegalArgumentException(Integer.toString(view.getId()));
				}
			}
		}

		@Override
		public void onHoverButtonUp(View view, MotionEvent event) {
			// Does nothing intentionally.
		}
	};

	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.album_activity);

		final int albumID = getIntent().getIntExtra(AlbumsActivity.ALBUM_ID, 1);
		mAlbum = DbUtils.getAlbum(this, albumID);

		mIndexCurrentPage = -1;
		mPageViewFlipper = (CustomPageFlipperView) findViewById(R.id.page_flipper_view);
		final PageWithOnePhotoAndSCanvasDesc titlePage = new PageWithOnePhotoAndSCanvasDesc(this,
				TitleViewMode.ANIM_INSCRIPTION);
		titlePage.setTitlePhoto(mAlbum.getTitlePage().getTitleImage().getPhoto());
		titlePage.setFilePath(mAlbum.getTitlePage().getTitleAnimation());

		mPageViewFlipper.setCurrentPage(titlePage);
		setGestureListenerForPageView();

		mRightButton = findViewById(R.id.album_button_right);
		mLeftButton = findViewById(R.id.album_button_left);

		final SPenEventLibrary spenEventLibrary = new SPenEventLibrary();
		spenEventLibrary.setSPenHoverListener(mRightButton, mOnHoverListener);
		spenEventLibrary.setSPenHoverListener(mLeftButton, mOnHoverListener);
		setButtonsActivated(true);
		mLeftButton.setVisibility(View.GONE);
	}

	private void setGestureListenerForPageView() {
		final GestureDetector gestureDetector = new GestureDetector(AlbumActivity.this,
				new GestureDetector.SimpleOnGestureListener() {

					@Override
					public boolean onFling(final MotionEvent start, final MotionEvent finish, final float velocityX,
							final float velocityY) {
						final float diff = start.getRawX() - finish.getRawX();
						final int widthScanvas = mPageViewFlipper.getWidth();
						if (Math.abs(diff) > widthScanvas / 2.0f) {
							if (start.getRawX() < finish.getRawX()) {
								displayPage(ChangeType.PREV_PAGE);
							} else {
								displayPage(ChangeType.NEXT_PAGE);
							}
						}

						return true;
					}

				});

		mPageViewFlipper.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(final View v, final MotionEvent event) {
				gestureDetector.onTouchEvent(event);
				return true;
			}
		});

		mPageViewFlipper.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void changed() {
				setButtonsActivated(true);
			}
		});
	}

	/**
	 * Displays page witch animation.
	 * 
	 * @param pChangeType
	 *            - type which defines way to change page.
	 */
	private void displayPage(final ChangeType pChangeType) {
		setButtonsActivated(false);

		switch (pChangeType) {
		case NEXT_PAGE:
			final int countAlbumPages = mAlbum.countAlbumsPages();
			if (mIndexCurrentPage == countAlbumPages) {
				setButtonsActivated(true);
				return;
			} else if (mIndexCurrentPage == countAlbumPages - 1) {
				mRightButton.setVisibility(View.GONE);
				final PageWithSCanvasDesc endPage = new PageWithSCanvasDesc(this, TitleViewMode.ANIM_INSCRIPTION);
				endPage.setFilePath(mAlbum.getEndPage().getPathToDesc());
				mPageViewFlipper.setDisplayPage(endPage, pChangeType);
				mIndexCurrentPage++;
				return;
			} else {
				mLeftButton.setVisibility(View.VISIBLE);
				mIndexCurrentPage++;
				mPageViewFlipper.setDisplayPage(getPageToDisplay(mAlbum.getAlbumsPage(mIndexCurrentPage)), pChangeType);
			}
			((AnimationDrawable) mRightButton.getBackground()).stop();
			((AnimationDrawable) mLeftButton.getBackground()).stop();
			break;

		case PREV_PAGE:
			if (mIndexCurrentPage == -1) {
				setButtonsActivated(true);
				return;
			} else if (mIndexCurrentPage == 0) {
				final PageWithOnePhotoAndSCanvasDesc titlePage = new PageWithOnePhotoAndSCanvasDesc(this,
						TitleViewMode.SHOW_INSCRIPTION);
				mLeftButton.setVisibility(View.GONE);
				titlePage.setTitlePhoto(mAlbum.getTitlePage().getTitleImage().getPhoto());
				titlePage.setFilePath(mAlbum.getTitlePage().getTitleAnimation());
				mPageViewFlipper.setDisplayPage(titlePage, pChangeType);
				mIndexCurrentPage--;
				return;
			} else {
				mRightButton.setVisibility(View.VISIBLE);
				mIndexCurrentPage--;
				mPageViewFlipper.setDisplayPage(getPageToDisplay(mAlbum.getAlbumsPage(mIndexCurrentPage)), pChangeType);
			}
			((AnimationDrawable) mRightButton.getBackground()).stop();
			((AnimationDrawable) mLeftButton.getBackground()).stop();
			break;
		default:
			throw new IllegalArgumentException("Unsupported change type opperation");

		}

	}

	/**
	 * Creates and returns view which will be displayed on page viewer. This view is one of PageWithOnePhoto,
	 * PageWithTwoPhoto, PageWithThreePhoto.
	 * 
	 * @param pAlbumPage
	 *            - page of album which will be displayed.
	 * @return view to display on page view.
	 */
	private View getPageToDisplay(final AlbumPage pAlbumPage) {
		final PageWithPhotos result = new PageWithPhotos(this, pAlbumPage.countPhotos());
		result.setPhotos(pAlbumPage.getPhotos());
		return result;
	}

	private void setButtonsActivated(boolean enabled) {
		mRightButton.setActivated(enabled);
		mLeftButton.setActivated(enabled);
	}
}
