/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities.fragments;

import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import com.sprc.album.R;
import com.sprc.album.activities.photocreator.PhotoCreatorSave;

/**
 * Pop-up dialog fragment with option to save the photo to the database or cancel the action.
 */
public class SavePhotoFragment extends DialogFragment implements OnClickListener {

	/**
	 * Empty constructor required for DialogFragment.
	 */
	public SavePhotoFragment() {
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setStyle(DialogFragment.STYLE_NO_TITLE, android.R.style.Theme_Holo_Dialog_NoActionBar);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		final View view = inflater.inflate(R.layout.popup_save_image_layout, container);
		final View cancel = view.findViewById(R.id.popup_button_cancel);
		final View save = view.findViewById(R.id.popup_button_ok);
		cancel.setOnClickListener(this);
		save.setOnClickListener(this);
		return view;
	}

	@Override
	public void onClick(View view) {
		final OnSavePhotoListener listener = (PhotoCreatorSave) getActivity();

		switch (view.getId()) {
		case R.id.popup_button_cancel:
			listener.savePhoto(false);
			break;
		case R.id.popup_button_ok:
			listener.savePhoto(true);
			break;
		default:
			throw new IllegalArgumentException();
		}

		dismiss();
	}

	/**
	 * Interface definition for a callback to be invoked when a button is clicked.
	 */
	public interface OnSavePhotoListener {

		/**
		 * Called when a button has been clicked.
		 * 
		 * @param save
		 *            indicates whether to save the photo
		 */
		void savePhoto(boolean save);
	}
}
