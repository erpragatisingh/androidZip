/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.sprc.album.R;
import com.sprc.album.framework.TitleView;
import com.sprc.album.framework.TitleView.OnAnimationFinishedListener;
import com.sprc.album.framework.TitleView.TitleViewMode;

/**
 * Represents splash activity. It runs as first and displays splash animation.
 */
public class SplashActivity extends Activity {

	/**
	 * Path to the asset which contains an animation to play as splash.
	 */
	private static final String ASSET_PATH = "album.png";
	/**
	 * Used to play the animation.
	 */
	private TitleView mTitleView;
	/**
	 * Called when the animation has finished. Finishes the {@link SplashActivity} and starts the {@link MenuActivity}.
	 */
	private final TitleView.OnAnimationFinishedListener mOnAnimationFinishedListener = new OnAnimationFinishedListener() {

		@Override
		public void animationFinished() {
			final Intent intent = new Intent(SplashActivity.this, MenuActivity.class);
			startActivity(intent);
			finish();
		}
	};

	/**
	 * Sets path to the asset which contains an animation. Also sets the listeners.
	 * 
	 * @param savedInstanceState
	 *            saved instance state
	 */
	@Override
	protected void onCreate(final Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);

		final View canvasContainer = findViewById(R.id.canvas_container);
		canvasContainer.setBackgroundResource(R.drawable.splash_bg);
		mTitleView = (TitleView) findViewById(R.id.splash_view);
		mTitleView.setAssetPath(ASSET_PATH);
		mTitleView.setOnAnimationFinshedListener(mOnAnimationFinishedListener);
		mTitleView.setModeType(TitleViewMode.ANIM_INSCRIPTION);
	}

	/**
	 * Closes the {@link TitleView}.
	 */
	@Override
	protected void onDestroy() {
		super.onDestroy();
		mTitleView.closeTitleView();
	}
}
