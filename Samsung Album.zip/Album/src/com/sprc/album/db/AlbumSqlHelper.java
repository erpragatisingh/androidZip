/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db;

import static com.sprc.album.db.DbStructure.DATABASE_NAME;
import static com.sprc.album.db.DbStructure.DATABASE_VERSION;

import java.util.List;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.sprc.album.db.DbStructure.DbTable;

/**
 * Class which helps connect to the database.
 */
public class AlbumSqlHelper extends SQLiteOpenHelper {

	/**
	 * Application context.
	 */
	private final Context mContext;

	/**
	 * Constructs the helper.
	 * 
	 * @param pContext
	 *            application context
	 */
	public AlbumSqlHelper(final Context pContext) {
		super(pContext, DATABASE_NAME, null, DATABASE_VERSION);
		mContext = pContext;
	}

	@Override
	public void onCreate(final SQLiteDatabase pDb) {
		final List<DbTable> list = TableLoader.loadTables();

		// @formatter:off
		for (final DbTable table : list) {

			// check table
			if (table.getColumns() == null || table.getColumns().length <= 0) {
				throw new IllegalArgumentException("Table must contain at least one column!");
			}

			final String tableName = table.getTableName();
			if (tableName == null || tableName.isEmpty()) {
				throw new IllegalArgumentException("Table name can not be empty or null!");
			}

			if (table.getPrimaryKey() == null || tableName.isEmpty()) {
				throw new IllegalArgumentException("Primary key is not found or is empty!");
			}

			final StringBuilder sb = new StringBuilder().append("CREATE TABLE ").append(table.getTableName())
					.append(" (");

			for (final DbColumn dbColumn : table.getColumns()) {
				sb.append(dbColumn.getName()).append(" ").append(dbColumn.getTypeAsString()).append(" ")
						.append(dbColumn.getAllowNullInformation()).append(", ");
			}

			sb.append("PRIMARY KEY(").append(table.getPrimaryKey()).append("))");

			pDb.execSQL(sb.toString());
		}
		// @formatter:on
	}

	@Override
	public void onUpgrade(final SQLiteDatabase pDb, final int pOldVersion, final int pNewVersion) {
		deleteDatabase(pDb);
		onCreate(pDb);
	}

	/**
	 * Deletes the database.
	 * 
	 * @param pDb
	 *            database which will be deleted
	 */
	private void deleteDatabase(final SQLiteDatabase pDb) {
		if (mContext.deleteDatabase(DATABASE_NAME)) {
			Log.d(AlbumSqlHelper.class.getSimpleName(), "deleteDatabase(): database deleted.");
		} else {
			Log.d(AlbumSqlHelper.class.getSimpleName(), "deleteDatabase(): database NOT deleted.");
			throw new IllegalStateException("Database still exists");
		}
	}

}
