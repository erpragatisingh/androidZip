/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db;

import java.util.LinkedList;
import java.util.List;

import com.sprc.album.db.DbColumn.DbColumnType;

/**
 * Class which represents database structure.
 */
final class DbStructure {

	/**
	 * Database name.
	 */
	public static final String DATABASE_NAME = "ALBUM_DB";
	/**
	 * Database version.
	 */
	public static final int DATABASE_VERSION = 18;

	/**
	 * Interface for classes that represent database tables.
	 */
	interface DbTable {

		/**
		 * Returns table name.
		 * 
		 * @return table name
		 */
		String getTableName();

		/**
		 * Returns array of all columns.
		 * 
		 * @return an array of column names
		 */
		DbColumn[] getColumns();

		/**
		 * Returns the primary key.
		 * 
		 * @return column name which is the primary key
		 */
		String getPrimaryKey();
	}

	/**
	 * Class represents table which contains information about albums.
	 */
	public static class AlbumTable implements DbTable {

		public static final String TABLE_NAME = "ALBUM";
		public static final String ID_ALBUM = "_id";
		public static final String COL_NAME = "NAME";
		public static final String COL_STATUS = "STATUS";
		public static final String COL_ID_PHOTO = "ID_PHOTO";
		public static final String COL_ID_TITLE_PAGE = "ID_TITLE_PAGE";
		public static final String COL_ID_END_PAGE = "ID_END_PAGE";

		@Override
		public DbColumn[] getColumns() {
			final List<DbColumn> columns = new LinkedList<DbColumn>();
			columns.add(DbColumn.createColumn(ID_ALBUM, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_NAME, DbColumnType.VARCHAR, false));
			columns.add(DbColumn.createColumn(COL_STATUS, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_ID_PHOTO, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_ID_TITLE_PAGE, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_ID_END_PAGE, DbColumnType.INT, false));
			return columns.toArray(new DbColumn[0]);
		}

		@Override
		public String getTableName() {
			return TABLE_NAME;
		}

		@Override
		public String getPrimaryKey() {
			return ID_ALBUM;
		}
	}

	/**
	 * Class represents table which contains information about pages.
	 */
	public static class PageTable implements DbTable {

		public static final String TABLE_NAME = "PAGE";
		public static final String ID_PAGE = "_id";
		public static final String COL_STATUS = "STATUS";
		public static final String COL_ALBUM = "ID_ALBUM";

		@Override
		public DbColumn[] getColumns() {
			final List<DbColumn> columns = new LinkedList<DbColumn>();
			columns.add(DbColumn.createColumn(ID_PAGE, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_STATUS, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_ALBUM, DbColumnType.INT, false));
			return columns.toArray(new DbColumn[0]);
		}

		@Override
		public String getTableName() {
			return TABLE_NAME;
		}

		@Override
		public String getPrimaryKey() {
			return ID_PAGE;
		}
	}

	/**
	 * Class represents table which contains connections between pages and photos.
	 */
	public static class PagePhotoTable implements DbTable {

		public static final String TABLE_NAME = "PAGE_PHOTO";
		public static final String ID_PAGE_PHOTO = "_id";
		public static final String COL_PAGE = "ID_PAGE";
		public static final String COL_PHOTO = "ID_PHOTO";

		@Override
		public DbColumn[] getColumns() {
			final List<DbColumn> columns = new LinkedList<DbColumn>();
			columns.add(DbColumn.createColumn(ID_PAGE_PHOTO, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_PAGE, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_PHOTO, DbColumnType.INT, false));
			return columns.toArray(new DbColumn[0]);
		}

		@Override
		public String getTableName() {
			return TABLE_NAME;
		}

		@Override
		public String getPrimaryKey() {
			return ID_PAGE_PHOTO;
		}
	}

	/**
	 * Class represents table which contains information about pictures.
	 */
	public static class PhotoTable implements DbTable {

		public static final String TABLE_NAME = "PHOTO";
		public static final String ID_PHOTO = "_id";
		public static final String COL_NAME = "NAME";
		public static final String COL_PHOTO = "PHOTO";
		public static final String COL_STATUS = "STATUS";

		@Override
		public DbColumn[] getColumns() {
			final List<DbColumn> columns = new LinkedList<DbColumn>();
			columns.add(DbColumn.createColumn(ID_PHOTO, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_NAME, DbColumnType.VARCHAR, false));
			columns.add(DbColumn.createColumn(COL_PHOTO, DbColumnType.BLOB, false));
			columns.add(DbColumn.createColumn(COL_STATUS, DbColumnType.INT, false));
			return columns.toArray(new DbColumn[0]);
		}

		@Override
		public String getTableName() {
			return TABLE_NAME;
		}

		@Override
		public String getPrimaryKey() {
			return ID_PHOTO;
		}
	}

	/**
	 * Class represents table which contains information about first page.
	 */
	public static class TitlePageTable implements DbTable {

		public static final String TABLE_NAME = "TITLE_PAGE";
		public static final String ID_TITLE_PAGE = "_id";
		public static final String COL_ASSET = "ASSET";
		public static final String COL_PHOTO = "ID_PHOTO";

		@Override
		public DbColumn[] getColumns() {
			final List<DbColumn> columns = new LinkedList<DbColumn>();
			columns.add(DbColumn.createColumn(ID_TITLE_PAGE, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_ASSET, DbColumnType.VARCHAR, false));
			columns.add(DbColumn.createColumn(COL_PHOTO, DbColumnType.BLOB, false));
			return columns.toArray(new DbColumn[0]);
		}

		@Override
		public String getTableName() {
			return TABLE_NAME;
		}

		@Override
		public String getPrimaryKey() {
			return ID_TITLE_PAGE;
		}
	}

	/**
	 * Class represents table which contains information about end page.
	 */
	public static class EndPageTable implements DbTable {

		public static final String TABLE_NAME = "END_PAGE";
		public static final String ID_END_PAGE = "_id";
		public static final String COL_ASSET = "ASSET";

		@Override
		public DbColumn[] getColumns() {
			final List<DbColumn> columns = new LinkedList<DbColumn>();
			columns.add(DbColumn.createColumn(ID_END_PAGE, DbColumnType.INT, false));
			columns.add(DbColumn.createColumn(COL_ASSET, DbColumnType.VARCHAR, false));
			return columns.toArray(new DbColumn[0]);
		}

		@Override
		public String getTableName() {
			return TABLE_NAME;
		}

		@Override
		public String getPrimaryKey() {
			return ID_END_PAGE;
		}
	}

	/**
	 * Hide constructor.
	 */
	private DbStructure() {
	}

}
