/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db.data;

import android.graphics.Bitmap;

/**
 * Represents photo in the database.
 */
public final class Photo {

	/**
	 * The photo bitmap.
	 */
	private final Bitmap mPhoto;
	/**
	 * Name of the photo.
	 */
	private final String mName;
	/**
	 * Status of the photo.
	 */
	private final int mStatus;
	/**
	 * Identifier of the photo.
	 */
	private final int mId;

	/**
	 * Constructs the photo.
	 * 
	 * @param builder
	 *            the photo builder
	 */
	private Photo(Builder builder) {
		mPhoto = builder.mPhoto;
		mName = builder.mName;
		mStatus = builder.mStatus;
		mId = builder.mId;
	}

	/**
	 * Returns the photo which is a bitmap.
	 * 
	 * @return photo
	 */
	public Bitmap getPhoto() {
		return mPhoto;
	}

	/**
	 * Returns name of the photo.
	 * 
	 * @return name of the photo
	 */
	public String getName() {
		return mName;
	}

	/**
	 * Returns current status of the photo.
	 * 
	 * @return current status of the photo
	 */
	public int getStatus() {
		return mStatus;
	}

	/**
	 * Returns identifier of the photo.
	 * 
	 * @return identifier (primary key)
	 */
	public int getId() {
		return mId;
	}

	/**
	 * Constructs the builder of the {@link Photo}.
	 */
	public static class Builder {

		private Bitmap mPhoto;
		private String mName;
		private int mStatus = 0;
		private int mId = -1;

		/**
		 * Sets photo's bitmap.
		 * 
		 * @param photo
		 *            bitmap which represents photo
		 * @return a {@link Photo} builder
		 */
		public Builder setPhoto(Bitmap photo) {
			mPhoto = photo;
			return this;
		}

		/**
		 * Sets photo's name.
		 * 
		 * @param name
		 *            of the photo
		 * @return a {@link Photo} builder
		 */
		public Builder setName(String name) {
			mName = name;
			return this;
		}

		/**
		 * Sets photo's status.
		 * 
		 * @param status
		 *            of the photo
		 * @return a {@link Photo} builder
		 */
		public Builder setStatus(int status) {
			mStatus = status;
			return this;
		}

		/**
		 * Sets photo's identifier.
		 * 
		 * @param id
		 *            the identifier of the photo (primary key)
		 * @return a {@link Photo} builder
		 */
		public Builder setId(int id) {
			mId = id;
			return this;
		}

		/**
		 * Builds the {@link Photo}.
		 * 
		 * @return a {@link Photo} instance
		 */
		public Photo build() {
			validate();
			return new Photo(this);
		}

		/**
		 * Validates data.
		 */
		private void validate() {
			mName = mName == null ? "" : mName;
		}
	}

}
