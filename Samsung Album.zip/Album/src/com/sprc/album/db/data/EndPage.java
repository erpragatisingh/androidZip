/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db.data;

/**
 * Class which represents logic for end page every album.
 */
public final class EndPage {

	private final int mId;

	/**
	 * Path to file which will be use by SCanvas.
	 */
	private final String mPathToDesc;

	private EndPage(Builder builder) {
		mId = builder.mId;
		mPathToDesc = builder.mPathToDesc;
	}

	public int getId() {
		return mId;
	}

	public String getPathToDesc() {
		return mPathToDesc;
	}

	/**
	 * Constructs the builder of the {@link EndPage}.
	 */
	public static class Builder {

		private int mId;
		private String mPathToDesc;

		/**
		 * Sets end page's identifier.
		 * 
		 * @param id
		 *            the identifier
		 * @return a {@link EndPage} builder
		 */
		public Builder setId(int id) {
			mId = id;
			return this;
		}

		/**
		 * Sets path to animation.
		 * 
		 * @param pathToDesc
		 *            path to the animation located in the file system
		 * @return a {@link EndPage} builder
		 */
		public Builder setPathToDesc(String pathToDesc) {
			mPathToDesc = pathToDesc;
			return this;
		}

		/**
		 * Builds the {@link EndPage}.
		 * 
		 * @return a {@link EndPage} instance
		 */
		public EndPage build() {
			return new EndPage(this);
		}
	}

}
