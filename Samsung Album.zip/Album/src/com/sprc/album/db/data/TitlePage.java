/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db.data;

/**
 * This class represents title page of album.
 */
public final class TitlePage {

	private final int mId;

	/**
	 * Title image which will be displayed on title page.
	 */
	private final Photo mTitleImage;

	/**
	 * Path to file with title animation.
	 */
	private final String mTitleAnimation;

	private TitlePage(Builder builder) {
		mId = builder.mId;
		mTitleImage = builder.mTitleImage;
		mTitleAnimation = builder.mTitleAnimation;
	}

	public int getId() {
		return mId;
	}

	public Photo getTitleImage() {
		return mTitleImage;
	}

	public String getTitleAnimation() {
		return mTitleAnimation;
	}

	/**
	 * Constructs the builder of the {@link TitlePage}.
	 */
	public static class Builder {

		private int mId;
		private Photo mTitleImage;
		private String mTitleAnimation;

		/**
		 * Sets id of the title page.
		 * 
		 * @param id
		 *            title page's identifier
		 * @return a {@link TitlePage} builder
		 */
		public Builder setId(int id) {
			mId = id;
			return this;
		}

		/**
		 * Sets title image.
		 * 
		 * @param titleImage
		 *            the title photo
		 * @return a {@link TitlePage} builder
		 */
		public Builder setTitleImage(Photo titleImage) {
			mTitleImage = titleImage;
			return this;
		}

		/**
		 * Sets title animation.
		 * 
		 * @param titleAnimation
		 *            path to the title animation located in the file system
		 * @return a {@link TitlePage} builder
		 */
		public Builder setTitleAnimation(String titleAnimation) {
			mTitleAnimation = titleAnimation;
			return this;
		}

		/**
		 * Builds the {@link TitlePage}.
		 * 
		 * @return a {@link TitlePage} instance
		 */
		public TitlePage build() {
			return new TitlePage(this);
		}
	}

}
