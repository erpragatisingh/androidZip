/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db.data;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.sprc.album.utils.Preconditions;

/**
 * Class which represents page of album.
 */
public final class AlbumPage {

	private final int mId;

	/** Collection photos on page. */
	private final List<Photo> mPhotos;

	private AlbumPage(Builder builder) {
		mId = builder.mID;
		mPhotos = builder.mPhotos;
	}

	/**
	 * Returns number of photos.
	 * 
	 * @return size
	 */
	public int countPhotos() {
		return mPhotos.size();
	}

	/**
	 * Returns photo by index.
	 * 
	 * @param index
	 *            index of the photo
	 * @return photo
	 */
	public Photo getPhoto(int index) {
		return mPhotos.get(index);
	}

	public int getId() {
		return mId;
	}

	public List<Photo> getPhotos() {
		return new LinkedList<Photo>(mPhotos);
	}

	/**
	 * Constructs the builder of the {@link AlbumPage}.
	 */
	public static class Builder {

		private int mID;
		private final List<Photo> mPhotos = new ArrayList<Photo>(3);

		/**
		 * Sets album page's identifier.
		 * 
		 * @param id
		 *            the identifier
		 * @return a {@link AlbumPage} builder
		 */
		public Builder setId(int id) {
			mID = id;
			return this;
		}

		/**
		 * Adds photo at the given index.
		 * 
		 * @param photo
		 *            the photo to add
		 * @param index
		 *            index at which to add the photo
		 * @return a {@link AlbumPage} builder
		 */
		public Builder addPhoto(Photo photo, int index) {
			mPhotos.add(index, Preconditions.checkNotNull(photo));
			return this;
		}

		/**
		 * Adds photo.
		 * 
		 * @param photo
		 *            the photo to add
		 * @return a {@link AlbumPage} builder
		 */
		public Builder addPhoto(Photo photo) {
			mPhotos.add(Preconditions.checkNotNull(photo));
			return this;
		}

		/**
		 * Builds the {@link AlbumPage}.
		 * 
		 * @return an {@link AlbumPage} instance
		 */
		public AlbumPage build() {
			return new AlbumPage(this);
		}
	}

}
