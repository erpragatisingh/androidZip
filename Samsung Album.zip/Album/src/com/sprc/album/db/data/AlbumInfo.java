/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db.data;

import android.graphics.Bitmap;

/**
 * Represents basic informations about album.
 */
public final class AlbumInfo {

	private final int mId;
	private final String mAlbumName;
	private final Bitmap mPhoto;

	/**
	 * Constructs an {@link AlbumInfo}.
	 */
	private AlbumInfo(Builder builder) {
		mId = builder.mId;
		mAlbumName = builder.mAlbumName;
		mPhoto = builder.mPhoto;
	}

	public int getId() {
		return mId;
	}

	public String getAlbumName() {
		return mAlbumName;
	}

	public Bitmap getPhoto() {
		return mPhoto;
	}

	/**
	 * Constructs the builder of the {@link AlbumInfo}.
	 */
	public static class Builder {

		private int mId;
		private String mAlbumName;
		private Bitmap mPhoto;

		/**
		 * Sets album's identifier.
		 * 
		 * @param id
		 *            the identifier
		 * @return an {@link AlbumInfo} instance
		 */
		public Builder setId(int id) {
			mId = id;
			return this;
		}

		/**
		 * Sets album's name.
		 * 
		 * @param albumName
		 *            the album's name
		 * @return an {@link AlbumInfo} instance
		 */
		public Builder setAlbumName(String albumName) {
			mAlbumName = albumName;
			return this;
		}

		/**
		 * Sets album's main photo.
		 * 
		 * @param photo
		 *            the photo
		 * @return an {@link AlbumInfo} instance
		 */
		public Builder setPhoto(Bitmap photo) {
			mPhoto = photo;
			return this;
		}

		/**
		 * Builds the {@link AlbumInfo}.
		 * 
		 * @return an {@link AlbumInfo} instance
		 */
		public AlbumInfo build() {
			return new AlbumInfo(this);
		}

	}
}
