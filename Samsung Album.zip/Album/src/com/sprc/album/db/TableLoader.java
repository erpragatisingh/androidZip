/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db;

import java.util.ArrayList;
import java.util.List;

import com.sprc.album.db.DbStructure.DbTable;

/**
 * Dynamically loads all tables that implement {@link DbTable} interface.
 * 
 * Implementations of {@link DbTable} should be placed as an inner classes of the {@link DbStructure} class.
 */
public final class TableLoader {

	/**
	 * Classes that implement {@link DbTable} interface.
	 */
	private static final Class<?>[] CLASSES = DbStructure.class.getClasses();

	/**
	 * Hide constructor.
	 */
	private TableLoader() {
	};

	/**
	 * Returns all instances of classes that implement {@link DbTable} interface.
	 * 
	 * @return list consist of {@link DbTable}'s subclass instances
	 */
	public static List<DbTable> loadTables() {
		final List<DbTable> tables = new ArrayList<DbTable>(CLASSES.length);

		for (final Class<?> clazz : CLASSES) {
			try {
				tables.add(clazz.asSubclass(DbTable.class).newInstance());
			} catch (final IllegalAccessException e) {
				throw new RuntimeException(e);
			} catch (final InstantiationException e) {
				throw new RuntimeException(e);
			}
		}

		return tables;
	}

}
