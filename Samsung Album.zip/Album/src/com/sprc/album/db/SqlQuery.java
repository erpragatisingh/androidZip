/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db;

/**
 * SQL query.
 */
public final class SqlQuery {

	private final String mQuery;

	private SqlQuery(Builder builder) {
		mQuery = builder.mQueryBuilder.toString();
	}

	public String getQuery() {
		return mQuery;
	}

	/**
	 * Builder for a SQL query.
	 */
	public static class Builder {

		private static final String SELECT = "SELECT ";
		private static final String FROM = " FROM ";
		private static final String WHERE = " WHERE ";
		private static final String AND = " AND ";
		private static final String ORDER_BY = " ORDER BY ";
		private static final String COUNT_ALL = " COUNT(*) ";
		private static final String COMMA = ", ";
		private static final String EQUAL = " = ";
		private static final String ALL = " * ";

		private final StringBuilder mQueryBuilder = new StringBuilder();

		/**
		 * Appends 'SELECT' to a query.
		 * 
		 * @return a {@link SqlQuery} builder
		 */
		public Builder select() {
			mQueryBuilder.append(SELECT);
			return this;
		}

		/**
		 * Appends 'COUNT(*)' to a query.
		 * 
		 * @return a {@link SqlQuery} builder
		 */
		public Builder countAll() {
			mQueryBuilder.append(COUNT_ALL);
			return this;
		}

		/**
		 * Appends 'ORDER BY' to a query.
		 * 
		 * @return a {@link SqlQuery} builder
		 */
		public Builder orderBy() {
			mQueryBuilder.append(ORDER_BY);
			return this;
		}

		/**
		 * Appends 'FROM' to a query.
		 * 
		 * @return a {@link SqlQuery} builder
		 */
		public Builder from() {
			mQueryBuilder.append(FROM);
			return this;
		}

		/**
		 * Appends ',' (comma) to a query.
		 * 
		 * @return a {@link SqlQuery} builder
		 */
		public Builder comma() {
			mQueryBuilder.append(COMMA);
			return this;
		}

		/**
		 * Appends 'WHERE' to a query.
		 * 
		 * @return a {@link SqlQuery} builder
		 */
		public Builder where() {
			mQueryBuilder.append(WHERE);
			return this;
		}

		/**
		 * Appends 'AND' to a query.
		 * 
		 * @return a {@link SqlQuery} builder
		 */
		public Builder and() {
			mQueryBuilder.append(AND);
			return this;
		}

		/**
		 * Appends '*' (asterisk) to a query.
		 * 
		 * @return a {@link SqlQuery} builder
		 */
		public Builder all() {
			mQueryBuilder.append(ALL);
			return this;
		}

		/**
		 * Appends '=' to a query.
		 * 
		 * @return a {@link SqlQuery} builder
		 */
		public Builder equal() {
			mQueryBuilder.append(EQUAL);
			return this;
		}

		/**
		 * Appends ' a' to a query, where a is a given char.
		 * 
		 * @param a
		 *            name of the alias
		 * @return a {@link SqlQuery} builder
		 */
		public Builder alias(char a) {
			mQueryBuilder.append(' ');
			mQueryBuilder.append(a);
			return this;
		}

		/**
		 * Appends table name to a query.
		 * 
		 * @param table
		 *            a table name
		 * @return a {@link SqlQuery} builder
		 */
		public Builder table(String table) {
			return string(table);
		}

		/**
		 * Appends column name to a query.
		 * 
		 * @param column
		 *            a column name
		 * @return a {@link SqlQuery} builder
		 */
		public Builder column(String column) {
			return string(column);
		}

		/**
		 * Appends 'a.' to a query, where a is a given char.
		 * 
		 * @param a
		 *            alias of a table
		 * @return a {@link SqlQuery} builder
		 */
		public Builder inAlias(char a) {
			mQueryBuilder.append(a);
			mQueryBuilder.append('.');
			return this;
		}

		/**
		 * Appends strings to a query.
		 * 
		 * @param strings
		 *            strings to append
		 * @return a {@link SqlQuery} builder
		 */
		public Builder string(String... strings) {
			for (final String string : strings) {
				mQueryBuilder.append(string);
			}
			return this;
		}

		/**
		 * Builds the query.
		 * 
		 * @return a {@link SqlQuery} instance
		 */
		public SqlQuery build() {
			return new SqlQuery(this);
		}
	}

}
