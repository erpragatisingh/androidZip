/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db;

/**
 * Class which defines properties column from database table.
 */
public final class DbColumn {

	/**
	 * Enum which defines type data from database.
	 */
	public enum DbColumnType {
		/** SQLite-> INTEGER. */
		INT("INTEGER"),
		/** SQLite-> VARCHAR. */
		VARCHAR("VARCHAR(50)"),
		/** SQLite -> BLOB. */
		BLOB("BLOB");

		/** SQL command. */
		private final String mSQLiteDesc;

		private DbColumnType(final String pSQLiteDesc) {
			mSQLiteDesc = pSQLiteDesc;
		}

		/**
		 * Returns SQLite command which is used in SQLite query.
		 * 
		 * @return SQLite command
		 */
		public String get() {
			return mSQLiteDesc;
		}

	}

	/**
	 * Name the column.
	 */
	private final String mName;
	/**
	 * Type of the column.
	 */
	private final DbColumnType mType;
	/**
	 * Whether the value stored in the column can be null.
	 */
	private final boolean mAllowNull;

	/**
	 * Static factory method for {@link DbColumn}.
	 * 
	 * @param pName
	 *            name of the column
	 * @param pType
	 *            type of the column
	 * @param pAllowNull
	 *            whether the value stored in the column can be null
	 * @return DbColumn object which describes database column
	 */
	public static DbColumn createColumn(final String pName, final DbColumnType pType, final boolean pAllowNull) {
		return new DbColumn(pName, pType, pAllowNull);
	}

	private DbColumn(final String pName, final DbColumnType pType, final boolean pAllowNull) {
		mName = pName;
		mType = pType;
		mAllowNull = pAllowNull;
	}

	/**
	 * Returns column name.
	 * 
	 * @return column name
	 */
	public String getName() {
		return mName;
	}

	/**
	 * Returns type of data as string which can be use in SQLite query.
	 * 
	 * @return type of data
	 */
	public String getTypeAsString() {
		return mType.get();
	}

	/**
	 * Returns information than column can be null as string which can be use in SQLite query.
	 * 
	 * @return information that column can be null
	 */
	public String getAllowNullInformation() {
		return mAllowNull ? "" : "NOT NULL";
	}
}
