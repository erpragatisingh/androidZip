/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.db;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.sprc.album.AlbumApplication;
import com.sprc.album.db.DbStructure.AlbumTable;
import com.sprc.album.db.DbStructure.EndPageTable;
import com.sprc.album.db.DbStructure.PagePhotoTable;
import com.sprc.album.db.DbStructure.PageTable;
import com.sprc.album.db.DbStructure.PhotoTable;
import com.sprc.album.db.DbStructure.TitlePageTable;
import com.sprc.album.db.data.AlbumInfo;
import com.sprc.album.db.data.AlbumPage;
import com.sprc.album.db.data.EndPage;
import com.sprc.album.db.data.Photo;
import com.sprc.album.db.data.TitlePage;
import com.sprc.album.logic.album.Album;

/**
 * Utility class which allows to perform easy operations on the database.
 */
public final class DbUtils {

	private DbUtils() {
	};

	/**
	 * Returns number of the photos stored in the database.
	 * 
	 * @param context
	 *            application context
	 * @return number of photos
	 */
	public static int getPhotoCount(Context context) {
		final AlbumApplication application = (AlbumApplication) context.getApplicationContext();
		final SQLiteDatabase db = application.getReadableDatabse();
		// @formatter:off
		final String query = new SqlQuery.Builder()
			.select()
			.countAll()
			.from()
			.table(DbStructure.PhotoTable.TABLE_NAME)
			.build()
			.getQuery();
		// @formatter:on
		final Cursor cursor = db.rawQuery(query, null);
		cursor.moveToFirst();
		final int count = cursor.getInt(0);
		cursor.close();
		db.close();
		return count;
	}

	/**
	 * Returns all photos stored in the database.
	 * 
	 * @param context
	 *            application context
	 * @return all photos in the database
	 */
	public static List<Photo> getPhotos(Context context) {
		final AlbumApplication application = (AlbumApplication) context.getApplicationContext();
		final SQLiteDatabase db = application.getReadableDatabse();

		//@formatter:off
		final String query = new SqlQuery.Builder()
			.select()
			.all()
			.from() 
			.table(PhotoTable.TABLE_NAME)
			.build()
			.getQuery();
		//@formatter:on

		final Cursor cursor = db.rawQuery(query, null);
		final List<Photo> photos = new ArrayList<Photo>(cursor.getCount());

		if (cursor.moveToFirst()) {
			do {
				final Bitmap photoBitmap = obtainBitmapFromBlob(cursor.getBlob(2));

				//@formatter:off
				final Photo info = new Photo.Builder()
					.setId(cursor.getInt(0))
					.setName(cursor.getString(1))
					.setPhoto(photoBitmap)
					.setStatus(cursor.getInt(3))
					.build();
				//@formatter:on

				photos.add(info);
			} while (cursor.moveToNext());
		}

		cursor.close();
		db.close();
		return photos;
	}

	/**
	 * Returns photo from DB.
	 * 
	 * @param context
	 *            application context
	 * @param id
	 *            identifier of the photo
	 * @return the photo or null if the photo with given id does not exist
	 */
	public static Photo getPhoto(Context context, int id) {
		final AlbumApplication application = (AlbumApplication) context.getApplicationContext();
		final SQLiteDatabase db = application.getReadableDatabse();

		//@formatter:off
		final String query = new SqlQuery.Builder()
			.select()
			.all()
			.from() 
			.table(PhotoTable.TABLE_NAME)
			.where()
			.column(PhotoTable.ID_PHOTO).equal().string(Integer.toString(id))
			.build()
			.getQuery();
		//@formatter:on

		final Cursor cursor = db.rawQuery(query, null);
		Photo photo = null;

		if (cursor.moveToFirst()) {
			final Bitmap photoBitmap = obtainBitmapFromBlob(cursor.getBlob(2));

			//@formatter:off
			photo = new Photo.Builder()
				.setId(cursor.getInt(0))
				.setName(cursor.getString(1))
				.setPhoto(photoBitmap)
				.setStatus(cursor.getInt(3))
				.build();
			//@formatter:on
		}

		cursor.close();
		db.close();
		return photo;
	}

	/**
	 * Returns album with given id.
	 * 
	 * @param context
	 *            application context
	 * @param id
	 *            identifier of the album
	 * @return an {@link Album} instance with given id
	 */
	public static Album getAlbum(Context context, int id) {
		final AlbumApplication application = (AlbumApplication) context.getApplicationContext();
		final SQLiteDatabase db = application.getReadableDatabse();

		final char end = 'e';
		final char title = 't';
		final char photo = 'p';
		final char albumAlias = 'a';
		final char page = 'g';
		final char pagePhoto = 'o';

		//@formatter:off
		// get TitlePage and EndPage
		String query = new SqlQuery.Builder()
			.select()
			.inAlias(title).column(TitlePageTable.COL_ASSET).comma()
			.inAlias(photo).column(PhotoTable.COL_PHOTO).comma()
			.inAlias(photo).column(PhotoTable.ID_PHOTO).comma()
			.inAlias(end).column(EndPageTable.COL_ASSET).comma()
			.inAlias(title).column(TitlePageTable.ID_TITLE_PAGE).comma()
			.inAlias(end).column(EndPageTable.ID_END_PAGE)
			.from()
			.table(AlbumTable.TABLE_NAME).alias(albumAlias).comma()
			.table(EndPageTable.TABLE_NAME).alias(end).comma()
			.table(TitlePageTable.TABLE_NAME).alias(title).comma()
			.table(PhotoTable.TABLE_NAME).alias(photo)
			.where()
			.inAlias(albumAlias).column(AlbumTable.ID_ALBUM).equal().string(Integer.toString(id)).and()
			.inAlias(title).column(TitlePageTable.ID_TITLE_PAGE).equal().column(AlbumTable.COL_ID_TITLE_PAGE).and()
			.inAlias(end).column(EndPageTable.ID_END_PAGE).equal().column(AlbumTable.COL_ID_END_PAGE).and()
			.inAlias(photo).column(PhotoTable.ID_PHOTO).equal().inAlias(title).column(TitlePageTable.COL_PHOTO)
			.build()
			.getQuery();

		// fill TitlePage and EndPage
		Cursor cursor = db.rawQuery(query, null);
		TitlePage titlePage;
		EndPage endPage; 
		
		if (cursor.moveToFirst()) {
			final Bitmap titleImage = obtainBitmapFromBlob(cursor.getBlob(1));
			
			final Photo titlePhoto = new Photo.Builder()
				.setId(cursor.getInt(2))
				.setPhoto(titleImage)
				.build();
			
			titlePage = new TitlePage.Builder()
				.setId(cursor.getInt(4))
				.setTitleAnimation(cursor.getString(0))
				.setTitleImage(titlePhoto)
				.build();
			
			endPage = new EndPage.Builder()
				.setId(cursor.getInt(5))
				.setPathToDesc(cursor.getString(3))
				.build();
		} else {
			cursor.close();
			db.close();
			throw new IllegalStateException("Album with given ID doesn't exist. Album's ID: " + id);
		} 
		cursor.close();
		
		// get AlbumPage
		query = new SqlQuery.Builder()
			.select()
			.inAlias(page).column(PageTable.ID_PAGE).comma()
			.inAlias(photo).column(PhotoTable.ID_PHOTO).comma()
			.inAlias(photo).column(PhotoTable.COL_PHOTO)
			.from()
			.table(PageTable.TABLE_NAME).alias(page).comma()
			.table(PagePhotoTable.TABLE_NAME).alias(pagePhoto).comma()
			.table(PhotoTable.TABLE_NAME).alias(photo)
			.where()
			.inAlias(page).column(PageTable.COL_ALBUM).equal().string(Integer.toString(id)).and()
			.inAlias(page).column(PageTable.ID_PAGE).equal().inAlias(pagePhoto).column(PagePhotoTable.COL_PAGE).and()
			.inAlias(pagePhoto).column(PagePhotoTable.COL_PHOTO).equal().inAlias(photo).column(PhotoTable.ID_PHOTO)
			.orderBy()
			.inAlias(page).column(PageTable.ID_PAGE).comma()
			.inAlias(photo).column(PhotoTable.ID_PHOTO)
			.build()
			.getQuery();
		
		// fill AlbumPages
		cursor = db.rawQuery(query, null);
		final List<AlbumPage> pages = new ArrayList<AlbumPage>();
		
		if (cursor.moveToFirst()) {
			AlbumPage.Builder pageBuilder = null;
			int prevPageId = Integer.MIN_VALUE;
			
			do {
				final int albumPageId = cursor.getInt(0);
				if (prevPageId != albumPageId) {
					if (pageBuilder != null) {
						pages.add(pageBuilder.build());
					}
					
					pageBuilder = new AlbumPage.Builder();
					pageBuilder.setId(albumPageId);
					prevPageId = albumPageId;
				}
					
				final Bitmap image = obtainBitmapFromBlob(cursor.getBlob(2));

				final Photo albumPhoto = new Photo.Builder()
					.setId(cursor.getInt(1))
					.setPhoto(image)
					.build();
					
				
				if (pageBuilder != null) {
					pageBuilder.addPhoto(albumPhoto);
				}
			} while (cursor.moveToNext());
			if (pageBuilder != null) {
				pages.add(pageBuilder.build());
			}
		} else {
			cursor.close();
			db.close();
			throw new IllegalStateException("Album with given ID doesn't have any pages. Album's ID: " + id);
		}
		// @formatter:on
		cursor.close();
		db.close();
		return new Album(titlePage, endPage, pages, "");
	}

	/**
	 * Returns list consists of {@link AlbumInfo} objects.
	 * 
	 * @param context
	 *            application context
	 * @return list consists of {@link AlbumInfo} objects
	 */
	public static List<AlbumInfo> getAlbumsInfo(Context context) {
		final AlbumApplication application = (AlbumApplication) context.getApplicationContext();
		final SQLiteDatabase db = application.getReadableDatabse();

		final char album = 'a';
		final char photo = 'p';

		//@formatter:off
		final String query = new SqlQuery.Builder()
			.select()
			.inAlias(album).column(AlbumTable.ID_ALBUM).comma()
			.inAlias(album).column(AlbumTable.COL_NAME).comma()
			.column(PhotoTable.COL_PHOTO)
			.from()
			.table(AlbumTable.TABLE_NAME).alias(album).comma()
			.table(PhotoTable.TABLE_NAME).alias(photo)
			.where()
			.column(AlbumTable.COL_ID_PHOTO).equal().inAlias(photo).column(PhotoTable.ID_PHOTO)
			.build()
			.getQuery();
		//@formatter:on

		final Cursor cursor = db.rawQuery(query, null);
		final List<AlbumInfo> albums = new ArrayList<AlbumInfo>(cursor.getCount());

		if (cursor.moveToFirst()) {
			do {
				final Bitmap bitmap = obtainBitmapFromBlob(cursor.getBlob(2));

				//@formatter:off
					final AlbumInfo info = new AlbumInfo.Builder()
						.setId(cursor.getInt(0))
						.setAlbumName(cursor.getString(1))
						.setPhoto(bitmap)
						.build();
				//@formatter:on
				albums.add(info);
			} while (cursor.moveToNext());
		}

		cursor.close();
		db.close();
		return albums;
	}

	private static final int PHOTO_QUALITY = 100;

	/**
	 * Inserts the given photo to the database.
	 * 
	 * @param context
	 *            application context
	 * @param photo
	 *            the photo to be inserted
	 */
	public static void insertPhoto(Context context, Photo photo) {
		final AlbumApplication application = (AlbumApplication) context.getApplicationContext();
		final SQLiteDatabase db = application.getWritableDatabase();

		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		photo.getPhoto().compress(Bitmap.CompressFormat.PNG, PHOTO_QUALITY, outputStream);

		final ContentValues values = new ContentValues();
		values.put(DbStructure.PhotoTable.COL_NAME, photo.getName());
		values.put(DbStructure.PhotoTable.COL_PHOTO, outputStream.toByteArray());
		values.put(DbStructure.PhotoTable.COL_STATUS, photo.getStatus());
		db.insert(DbStructure.PhotoTable.TABLE_NAME, null, values);
		db.close();
	}

	/**
	 * Inserts given album to the database.
	 * 
	 * @param context
	 *            application context
	 * @param album
	 *            the album to be inserted
	 */
	public static void insertAlbum(Context context, Album album) {
		final AlbumApplication application = (AlbumApplication) context.getApplicationContext();
		final SQLiteDatabase db = application.getWritableDatabase();

		db.beginTransaction();
		final TitlePage titlePage = album.getTitlePage();
		final ContentValues values = new ContentValues();
		values.put(TitlePageTable.COL_ASSET, titlePage.getTitleAnimation());
		values.put(TitlePageTable.COL_PHOTO, titlePage.getTitleImage().getId());
		final long titlePageId = db.insert(TitlePageTable.TABLE_NAME, null, values);
		values.clear();

		final EndPage endPage = album.getEndPage();
		values.put(EndPageTable.COL_ASSET, endPage.getPathToDesc());
		final long endPageId = db.insert(EndPageTable.TABLE_NAME, null, values);
		values.clear();

		values.put(AlbumTable.COL_NAME, album.getName());
		values.put(AlbumTable.COL_STATUS, 0);
		values.put(AlbumTable.COL_ID_PHOTO, titlePage.getTitleImage().getId());
		values.put(AlbumTable.COL_ID_TITLE_PAGE, titlePageId);
		values.put(AlbumTable.COL_ID_END_PAGE, endPageId);
		final long albumId = db.insert(AlbumTable.TABLE_NAME, null, values);
		values.clear();

		final List<AlbumPage> albumPages = album.getAlbumPages();
		for (final AlbumPage page : albumPages) {
			values.put(PageTable.COL_ALBUM, albumId);
			values.put(PageTable.COL_STATUS, 0);
			final long pageId = db.insert(PageTable.TABLE_NAME, null, values);
			values.clear();

			for (int i = 0; i < page.countPhotos(); i++) {
				values.put(PagePhotoTable.COL_PAGE, pageId);
				values.put(PagePhotoTable.COL_PHOTO, page.getPhoto(i).getId());
				db.insert(PagePhotoTable.TABLE_NAME, null, values);
				values.clear();
			}
		}

		db.setTransactionSuccessful();
		db.endTransaction();
		db.close();
	}

	private static Bitmap obtainBitmapFromBlob(byte[] blob) {
		final ByteArrayInputStream inputStream = new ByteArrayInputStream(blob);
		return BitmapFactory.decodeStream(inputStream);
	}
}
