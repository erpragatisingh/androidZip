/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.logic.album;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.sprc.album.db.data.AlbumPage;
import com.sprc.album.db.data.EndPage;
import com.sprc.album.db.data.TitlePage;

/**
 * Class which represents Album.
 */
public class Album {

	/**
	 * Name of album.
	 */
	private final String mName;

	/**
	 * Title pages.
	 */
	private final TitlePage mTitlePage;
	/**
	 * List albums pages.
	 */
	private final List<AlbumPage> mAlbumsPages;
	/**
	 * End pages.
	 */
	private final EndPage mEndPage;

	/**
	 * Constructor.
	 * 
	 * @param titlePage
	 *            title page
	 * @param endPage
	 *            end page
	 * @param pages
	 *            list of pages
	 * @param name
	 *            name of album
	 */
	public Album(TitlePage titlePage, EndPage endPage, List<AlbumPage> pages, String name) {
		mAlbumsPages = new LinkedList<AlbumPage>(pages);
		mTitlePage = titlePage;
		mEndPage = endPage;
		mName = name;
	}

	/**
	 * Returns information about number of pages.
	 * 
	 * @return count pages.
	 */
	public int countAlbumsPages() {
		return mAlbumsPages.size();
	}

	/**
	 * Adds page to album.
	 * 
	 * @param pAlbumsPage
	 *            page which will be added to album.
	 */
	public void addAlbumsPages(final AlbumPage pAlbumsPage) {
		mAlbumsPages.add(pAlbumsPage);
	}

	/**
	 * Returns page by index. If page with index is null throws exception.
	 * 
	 * @param pIndex
	 *            index of page.
	 * @return page from album.
	 */
	public AlbumPage getAlbumsPage(final int pIndex) {
		final AlbumPage result = mAlbumsPages.get(pIndex);
		if (result == null) {
			throw new IndexOutOfBoundsException("Index out of ragne album page count!!!");
		}
		return mAlbumsPages.get(pIndex);
	}

	/**
	 * Returns information about title page.
	 * 
	 * @return title page
	 */
	public TitlePage getTitlePage() {
		return mTitlePage;
	}

	/**
	 * Returns information about albums end page.
	 * 
	 * @return end page
	 */
	public EndPage getEndPage() {
		return mEndPage;
	}

	/**
	 * Returns copy of the album pages.
	 * 
	 * @return list consisting of album pages
	 */
	public List<AlbumPage> getAlbumPages() {
		return new ArrayList<AlbumPage>(mAlbumsPages);
	}

	/**
	 * Returns name of album.
	 * 
	 * @return albums name
	 */
	public String getName() {
		return mName;
	}

}
