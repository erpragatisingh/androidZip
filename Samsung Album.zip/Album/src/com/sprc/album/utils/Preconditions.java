/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.utils;

/**
 * Preconditions.
 */
public final class Preconditions {

	/**
	 * Hide constructor.
	 */
	private Preconditions() {
	}

	/**
	 * Checks if the given value is not null. Fast fails on null references.
	 * 
	 * @param reference
	 *            reference to an object
	 * @param <T>
	 *            type
	 * @return T reference or throws {@link NullPointerException} if given reference was null
	 */
	public static <T> T checkNotNull(final T reference) {
		if (reference == null) {
			throw new NullPointerException();
		}
		return reference;
	}
}
