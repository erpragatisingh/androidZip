/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;

/**
 * File tools class.
 * 
 */
public final class FileUtils {

	/**
	 * The best quality <b>100</b>.
	 */
	private static final int BEST_QUALITY = 100;

	/**
	 * Hide constructor.
	 */
	private FileUtils() {

	}

	/**
	 * Saves bitmap to temporary file.
	 * 
	 * @param bitmap
	 *            bitmap which will be save
	 * @throws IOException
	 */
	public static void saveBitmap(Bitmap bitmap) {

		final String extStorageDirectory = Environment.getExternalStorageDirectory().toString();

		final File file = new File(extStorageDirectory, "TEMP.PNG");
		OutputStream outStream = null;
		try {
			outStream = new FileOutputStream(file);
			bitmap.compress(Bitmap.CompressFormat.PNG, BEST_QUALITY, outStream);
			outStream.flush();
		} catch (final IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (outStream != null) {
				try {
					outStream.close();
				} catch (final IOException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}

	/**
	 * Loads bitmap from temporary file.
	 * 
	 * @return bitmap from temporary file
	 */
	public static Bitmap loadBitmap() {

		final String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
		final File file = new File(extStorageDirectory, "TEMP.PNG");
		final Bitmap result = BitmapFactory.decodeFile(file.getAbsolutePath());
		return result;
	}

	/**
	 * Returns URI to temporary file.
	 * 
	 * @return URI to temporary file
	 */
	public static Uri getTempUri() {
		final String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
		final File file = new File(extStorageDirectory, "TEMP.PNG");
		return Uri.fromFile(file);
	}
}
