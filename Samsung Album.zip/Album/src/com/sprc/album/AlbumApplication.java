/*
 ********************************************************************************
 * Copyright (c) 2012 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.sprc.album;

import android.app.Application;
import android.database.sqlite.SQLiteDatabase;

import com.sprc.album.db.AlbumSqlHelper;

/**
 * Album application which stores the data shared between an activities.
 */
public class AlbumApplication extends Application {

	/**
	 * SQL helper.
	 */
	private AlbumSqlHelper mHelper;

	@Override
	public void onCreate() {
		super.onCreate();
		mHelper = new AlbumSqlHelper(this);
	}

	/**
	 * Returns readable instance of the database.
	 * 
	 * @return readable database
	 */
	public SQLiteDatabase getReadableDatabse() {
		return mHelper.getReadableDatabase();
	}

	/**
	 * Returns writable instance of the database.
	 * 
	 * @return writable database
	 */
	public SQLiteDatabase getWritableDatabase() {
		return mHelper.getWritableDatabase();
	}

}
