Change Log
==========
Version 1.0.3 *(2013-06-10)*
----------------------------
Improved handling of badges, preventing creation of new one on every call to "showBadge()".

Version 1.0.2 *(2013-05-30)*
----------------------------
Fixed bug which prevented the determinate progress indicator from displaying properly on API <11.

Version 1.0.1 *(2013-05-15)*
----------------------------
Update versions of ABS (4.3.1) and android maven plugin (3.3.2).

Version 1.0.0 *(2013-04-10)*
----------------------------
Initial release.
