/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.assets.loaders.BitmapFontLoader.BitmapFontParameter;
import com.badlogic.gdx.assets.loaders.TextureLoader.TextureParameter;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.Align;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.srpol.golf.ScreenType;
import com.srpol.golf.utils.Assets;
import com.srpol.golf.utils.AudioPaths;
import com.srpol.golf.utils.GolfAudioManager;
import com.srpol.golf.utils.Labelizer;

/**
 * A {@link com.badlogic.gdx.Screen} implementation that shows information about this game.
 */
public class AboutScreen extends UiScreen implements InputProcessor {

	private static final boolean DEBUG_TABLE = false;

	private static final String FONT_PATH = "common/font.fnt";
	private static final String ABOUT_TXT_FILE = "about/about.txt";
	private static final String BUTTON_BACKGROUND = "common/button_background.png";
	private static final float CONTENT_PADDING_TOP = 200.0f;
	private static final float CONTENT_PADDING_LEFT = 20.0f;
	private static final float CONTENT_PADDING_RIGHT = 20.0f;
	private static final float CONTENT_PADDING_BOTTOM = 200.0f;

	private BitmapFont mFont;

	/**
	 * Constructs the {@link AboutScreen}.
	 * 
	 * @param game
	 *            {@link Game} instance
	 * @param type
	 *            {@link ScreenType} of the screen
	 */
	public AboutScreen(Game game, ScreenType type) {
		super(game, type);
	}

	@Override
	void onRender(float delta) {
		super.onRender(delta);

		if (DEBUG_TABLE) {
			Table.drawDebug(getStage());
		}
	}

	@Override
	protected void onShow() {
		getInputMultiplexer().addProcessor(this);
	}

	@Override
	protected void onHide() {
		getInputMultiplexer().removeProcessor(this);
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void create() {
		super.create();
		final TextureParameter param = new TextureParameter();
		param.minFilter = TextureFilter.MipMapLinearLinear;
		param.magFilter = TextureFilter.Linear;
		param.genMipMaps = true;

		final BitmapFontParameter fontParam = new BitmapFontParameter();
		fontParam.maxFilter = TextureFilter.Linear;
		fontParam.minFitler = TextureFilter.Linear;

		Assets.get().load(FONT_PATH, BitmapFont.class, fontParam);
		Assets.get().load(BUTTON_BACKGROUND, Texture.class, param);
		Assets.get().load(MainMenuScreen.BUTTON_ABOUT_PATH, Texture.class, param);
		Assets.get().load(MainMenuScreen.BUTTON_ABOUT_PRESSED_PATH, Texture.class, param);
		Assets.get().load(MainMenuScreen.BACKGROUND_PATH, Texture.class, param);
	}

	@Override
	public void dispose() {
		super.dispose();
		Assets.get().unload(FONT_PATH);
		Assets.get().unload(BUTTON_BACKGROUND);
		Assets.get().unload(MainMenuScreen.BUTTON_ABOUT_PATH);
		Assets.get().unload(MainMenuScreen.BUTTON_ABOUT_PRESSED_PATH);
		Assets.get().unload(MainMenuScreen.BACKGROUND_PATH);
	}

	@Override
	public boolean keyDown(int keycode) {
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		switch (keycode) {
		case Keys.BACK:
		case Keys.ESCAPE:
			back();
			return true;
		default:
			return false;
		}
	}

	@Override
	public boolean keyTyped(char character) {
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		return false;
	}

	/**
	 * Exits the {@link AboutScreen} and goes back to the previous one.
	 */
	private void back() {
		setScreen(ScreenType.SCREEN_MAIN_MENU);
	}

	@Override
	protected Actor onCreateLayout() {
		final Table table = new Table();
		table.setFillParent(true);

		// Background

		final Image backgroundImage = new Image(Assets.get().get(MainMenuScreen.BACKGROUND_PATH, Texture.class));
		setBackground(backgroundImage);

		// Back button

		final Button backButton = new Button(Assets.get().getTextureRegionDrawable(
				MainMenuScreen.BUTTON_ABOUT_PRESSED_PATH), Assets.get().getTextureRegionDrawable(
				MainMenuScreen.BUTTON_ABOUT_PATH));
		backButton.addListener(new ClickListener() {
			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				GolfAudioManager.playSound(AudioPaths.CLICK);
				return super.touchDown(event, x, y, pointer, button);
			}

			@Override
			public void clicked(InputEvent event, float x, float y) {
				if (backButton.equals(event.getListenerActor())) {
					back();
				}
			}
		});

		table.add(backButton).bottom().left().size(MainMenuScreen.LAYOUT_BUTTON_ABOUT_SIZE)
				.padLeft(MainMenuScreen.LAYOUT_BUTTON_PADDING).padBottom(MainMenuScreen.LAYOUT_BUTTON_PADDING);

		// And now the scrollable credits list

		final Table content = new Table();
		content.pad(CONTENT_PADDING_TOP, CONTENT_PADDING_LEFT, CONTENT_PADDING_BOTTOM, CONTENT_PADDING_RIGHT);

		final ScrollPane scrollPane = new ScrollPane(content) {
			@Override
			public void draw(SpriteBatch batch, float parentAlpha) {
				final Sprite sprite = new Sprite(Assets.get().get(BUTTON_BACKGROUND, Texture.class));
				sprite.setSize(getWidth(), getHeight());
				sprite.setPosition(getX(), getY());
				sprite.draw(batch);
				super.draw(batch, parentAlpha);
			};
		};
		scrollPane.setOverscroll(false, true);

		mFont = Assets.get().get(FONT_PATH, BitmapFont.class);

		// Parse URLs

		final ClickListener clickListener = new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				final Label label = (Label) event.getListenerActor();
				GolfAudioManager.playSound(AudioPaths.CLICK);
				Gdx.net.openURI(label.getText().toString());
			}
		};

		final FileHandle handle = Gdx.files.internal(ABOUT_TXT_FILE);

		final Labelizer labelizer = new Labelizer(handle.readString());

		while (labelizer.parse()) {
			final String text = labelizer.getText();

			if (labelizer.isUrl()) {
				final Label label = new Label(text, new LabelStyle(mFont, Color.WHITE));
				label.addListener(clickListener);
				label.setAlignment(Align.top, Align.center);
				label.setWrap(true);

				content.add(label).fill().expand();
				content.row();
			} else {
				final Label label = new Label(text, new LabelStyle(mFont, Color.GREEN));
				label.setAlignment(Align.top, Align.center);
				label.setWrap(true);

				content.add(label).fill().expand();
				content.row();
			}
		}

		table.add(scrollPane).expand().fill();

		if (DEBUG_TABLE) {
			table.debug();
			content.debug();
		}

		return table;
	}
}
