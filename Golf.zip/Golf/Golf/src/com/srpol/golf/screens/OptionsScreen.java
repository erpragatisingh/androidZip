/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.assets.loaders.TextureLoader.TextureParameter;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.srpol.golf.ScreenType;
import com.srpol.golf.utils.Assets;
import com.srpol.golf.utils.AudioPaths;
import com.srpol.golf.utils.GolfAudioManager;
import com.srpol.golf.utils.GolfPreferences;

/**
 * A {@link com.badlogic.gdx.Screen} implementation that contains game options.
 */
public class OptionsScreen extends UiScreen implements InputProcessor {

	private static final boolean DEBUG_TABLE = false;

	private static final String BUTTON_SOUND_ON_PATH = "options/button_sound_on.png";
	private static final String BUTTON_SOUND_OFF_PATH = "options/button_sound_off.png";
	private static final String BUTTON_MUSIC_ON_PATH = "options/button_music_on.png";
	private static final String BUTTON_MUSIC_OFF_PATH = "options/button_music_off.png";
	private static final String BUTTON_BACKGROUND_PATH = "common/button_background.png";

	private static final float LAYOUT_BUTTON_OPTION_SIZE = 200.0f;

	private Texture mSoundButtonOnTexture;
	private Texture mSoundButtonOffTexture;
	private Texture mMusicButtonOnTexture;
	private Texture mMusicButtonOffTexture;
	private Texture mButtonBackgroundTexture;

	/**
	 * Constructs the {@link OptionsScreen}.
	 * 
	 * @param game
	 *            {@link Game} instance
	 * @param type
	 *            {@link ScreenType} of this screen
	 */
	public OptionsScreen(Game game, ScreenType type) {
		super(game, type);
	}

	@Override
	public void create() {
		super.create();
		final TextureParameter param = new TextureParameter();
		param.minFilter = TextureFilter.MipMapLinearLinear;
		param.magFilter = TextureFilter.Linear;
		param.genMipMaps = true;

		Assets.get().load(MainMenuScreen.BUTTON_OPTIONS_PATH, Texture.class, param);
		Assets.get().load(MainMenuScreen.BUTTON_OPTIONS_PRESSED_PATH, Texture.class, param);
		Assets.get().load(MainMenuScreen.BACKGROUND_PATH, Texture.class, param);
		Assets.get().load(BUTTON_SOUND_ON_PATH, Texture.class, param);
		Assets.get().load(BUTTON_SOUND_OFF_PATH, Texture.class, param);
		Assets.get().load(BUTTON_MUSIC_ON_PATH, Texture.class, param);
		Assets.get().load(BUTTON_MUSIC_OFF_PATH, Texture.class, param);
		Assets.get().load(BUTTON_BACKGROUND_PATH, Texture.class, param);
	}

	@Override
	void onRender(float delta) {
		super.onRender(delta);
		if (DEBUG_TABLE) {
			Table.drawDebug(getStage());
		}
	}

	@Override
	protected void onShow() {
		getInputMultiplexer().addProcessor(this);
	}

	@Override
	protected void onHide() {
		getInputMultiplexer().removeProcessor(this);
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void dispose() {
		super.dispose();
		Assets.get().unload(MainMenuScreen.BUTTON_OPTIONS_PATH);
		Assets.get().unload(MainMenuScreen.BUTTON_OPTIONS_PRESSED_PATH);
		Assets.get().unload(MainMenuScreen.BACKGROUND_PATH);
		Assets.get().unload(BUTTON_SOUND_ON_PATH);
		Assets.get().unload(BUTTON_SOUND_OFF_PATH);
		Assets.get().unload(BUTTON_MUSIC_ON_PATH);
		Assets.get().unload(BUTTON_MUSIC_OFF_PATH);
		Assets.get().unload(BUTTON_BACKGROUND_PATH);
	}

	@Override
	public boolean keyDown(int keycode) {
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		switch (keycode) {
		case Keys.BACK:
		case Keys.ESCAPE:
			back();
			return true;
		default:
			return false;
		}
	}

	@Override
	public boolean keyTyped(char character) {
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		return false;
	}

	/**
	 * Exits the {@link OptionsScreen} and goes back to the previous one.
	 */
	private void back() {
		setScreen(ScreenType.SCREEN_MAIN_MENU);
	}

	@Override
	protected Actor onCreateLayout() {
		mSoundButtonOnTexture = Assets.get().get(BUTTON_SOUND_ON_PATH);
		mSoundButtonOffTexture = Assets.get().get(BUTTON_SOUND_OFF_PATH);
		mMusicButtonOnTexture = Assets.get().get(BUTTON_MUSIC_ON_PATH);
		mMusicButtonOffTexture = Assets.get().get(BUTTON_MUSIC_OFF_PATH);
		mButtonBackgroundTexture = Assets.get().get(BUTTON_BACKGROUND_PATH);

		final Table table = new Table();
		table.setFillParent(true);
		table.pad(MainMenuScreen.LAYOUT_BUTTON_PADDING);

		// Background

		final Image backgroundImage = new Image(Assets.get().get(MainMenuScreen.BACKGROUND_PATH, Texture.class));
		setBackground(backgroundImage);

		if (DEBUG_TABLE) {
			table.debug();
		}

		final Table buttonTable = createButtonTable();

		table.add(buttonTable).expand().fill();

		// Back button

		final Button backButton = new Button(Assets.get().getTextureRegionDrawable(
				MainMenuScreen.BUTTON_OPTIONS_PRESSED_PATH), Assets.get().getTextureRegionDrawable(
				MainMenuScreen.BUTTON_OPTIONS_PATH));
		backButton.addListener(new ClickListener() {

			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				GolfAudioManager.playSound(AudioPaths.CLICK);
				return super.touchDown(event, x, y, pointer, button);
			}

			@Override
			public void clicked(InputEvent event, float x, float y) {
				if (backButton.equals(event.getListenerActor())) {
					back();
				}
			}
		});

		table.row();
		table.add(backButton).bottom().center().size(MainMenuScreen.LAYOUT_BUTTON_OPTIONS_SIZE);

		return table;
	}

	/**
	 * Creates the {@link Table} with option buttons and separate background.
	 * 
	 * @return {@link Table} actor
	 */
	private Table createButtonTable() {
		final Table table = new Table();
		final Actor buttonBackgroundActor = new Actor() {
			@Override
			public void draw(SpriteBatch batch, float parentAlpha) {
				final Sprite sprite = new Sprite(mButtonBackgroundTexture);
				sprite.setSize(getParent().getWidth(), getParent().getHeight());
				sprite.setPosition(getX(), getY());
				sprite.draw(batch);
			};
		};
		table.addActor(buttonBackgroundActor);

		// Option buttons

		final Button soundButton = new Button(new TextureRegionDrawable(new TextureRegion(mSoundButtonOffTexture)),
				new TextureRegionDrawable(new TextureRegion(mSoundButtonOnTexture)), new TextureRegionDrawable(
						new TextureRegion(mSoundButtonOnTexture)));
		soundButton.setChecked(GolfAudioManager.isSoundsOn());
		soundButton.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				final Actor actor = event.getListenerActor();
				if (soundButton.equals(actor)) {
					final Button btn = (Button) event.getListenerActor();
					GolfPreferences.INSTANCE.setSoundOn(btn.isChecked());
					GolfAudioManager.setSoundsOn(btn.isChecked());
				}
			}
		});

		final Button musicButton = new Button(new TextureRegionDrawable(new TextureRegion(mMusicButtonOffTexture)),
				new TextureRegionDrawable(new TextureRegion(mMusicButtonOnTexture)), new TextureRegionDrawable(
						new TextureRegion(mMusicButtonOnTexture)));
		musicButton.setChecked(GolfAudioManager.isMusicsOn());
		musicButton.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				final Actor actor = event.getListenerActor();
				if (musicButton.equals(actor)) {
					final Button btn = (Button) event.getListenerActor();
					GolfPreferences.INSTANCE.setMusicOn(btn.isChecked());
					GolfAudioManager.setAndSwitchMusicsOn(btn.isChecked());
				}
			}
		});

		table.add(soundButton).expand().size(LAYOUT_BUTTON_OPTION_SIZE);
		table.add(musicButton).expand().size(LAYOUT_BUTTON_OPTION_SIZE);

		return table;
	}
}
