/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.screens;

import java.util.Arrays;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.assets.loaders.TextureLoader.TextureParameter;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.input.GestureDetector;
import com.badlogic.gdx.input.GestureDetector.GestureListener;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.ButtonGroup;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Stack;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.srpol.golf.ScreenType;
import com.srpol.golf.utils.Assets;
import com.srpol.golf.utils.AudioPaths;
import com.srpol.golf.utils.GolfAudioManager;

/** This class presents the available help screens. */
public class HelpScreen extends UiScreen implements InputProcessor, GestureListener {
	private static final String TAG = HelpScreen.class.getSimpleName();
	private static final boolean DEBUG_TABLE = false;

	private static final float TRANSITION_TIME = 0.7f;
	private static final float TERMINAL_VELOCITY = 800.0f;
	private static final float CATEGORY_BUTTON_HEIGHT = 100.0f;
	private static final float RELATIVE_DOT_SIZE = 30.0f;

	private static final float CATEGORY_BUTTON_WIDTH = 121.0f;
	private static final float CATEGORY_LAYOUT_BUTTON_PADDING = 10.0f;

	private static final String BUTTON_AIM = "helpscreen/button_aim.png";
	private static final String BUTTON_AIM_CHECKED = "helpscreen/button_aim_checked.png";
	private static final String BUTTON_AIM_PRESSED = "helpscreen/button_aim_pressed.png";

	private static final String BUTTON_OBSTACLES = "helpscreen/button_obstacles.png";
	private static final String BUTTON_OBSTACLES_CHECKED = "helpscreen/button_obstacles_checked.png";
	private static final String BUTTON_OBSTACLES_PRESSED = "helpscreen/button_obstacles_pressed.png";

	private static final String BUTTON_CLUBS = "helpscreen/button_clubs.png";
	private static final String BUTTON_CLUBS_CHECKED = "helpscreen/button_clubs_checked.png";
	private static final String BUTTON_CLUBS_PRESSED = "helpscreen/button_clubs_pressed.png";

	private static final String BUTTON_GOAL = "helpscreen/button_goal.png";
	private static final String BUTTON_GOAL_CHECKED = "helpscreen/button_goal_checked.png";
	private static final String BUTTON_GOAL_PRESSED = "helpscreen/button_goal_pressed.png";

	private static final String BUTTON_BACKGROUND = "common/button_background.png";
	private static final String BIG_DOT = "helpscreen/screen_marker_active.png";
	private static final String SMALL_DOT = "helpscreen/screen_marker_normal.png";

	private static final int AIM_CATEGORY_INDEX = 0;
	private static final int GOAL_CATEGORY_INDEX = 1;
	private static final int CLUBS_CATEGORY_INDEX = 2;
	private static final int OBSTACLES_CATEGORY_INDEX = 3;

	// @formatter:off
	private static final String[][] SCREEN_IMAGE_PATHS = { 
			{"helpscreen/help_aim.png"},
			{"helpscreen/help_goal.png", "helpscreen/help_goal2.png"}, 
			{"helpscreen/help_clubs.png"},
			{"helpscreen/help_obstacles.png", "helpscreen/help_obstacles2.png"}};
	// @formatter:on

	private static final int NUMBER_OF_CATEGORIES = SCREEN_IMAGE_PATHS.length;
	private Texture[][] mTextures;
	private final Image[][] mDotImages;
	private final Image[][] mImages;

	private final int[] mCurrentIndexes;
	private int mCurrentCategory;
	private final GestureDetector mGestureDetector;
	private Texture mButtonBackgroundTexture;

	/**
	 * Constructor.
	 * 
	 * @param game
	 *            {@link Game} instance
	 * @param type
	 *            {@link ScreenType} of this screen
	 **/
	public HelpScreen(Game game, ScreenType type) {
		super(game, type);
		mGestureDetector = new GestureDetector(this);
		mCurrentIndexes = new int[NUMBER_OF_CATEGORIES];
		mCurrentCategory = 0;
		Arrays.fill(mCurrentIndexes, 0);

		mImages = new Image[NUMBER_OF_CATEGORIES][];
		mDotImages = new Image[NUMBER_OF_CATEGORIES][];

		for (int i = 0; i < NUMBER_OF_CATEGORIES; i++) {
			mImages[i] = new Image[SCREEN_IMAGE_PATHS[i].length];
			mDotImages[i] = new Image[SCREEN_IMAGE_PATHS[i].length];
		}
	}

	@Override
	void onRender(float delta) {
		super.onRender(delta);

		if (DEBUG_TABLE) {
			Table.drawDebug(getStage());
		}
	}

	@Override
	public void pause() {
		// do nothing
	}

	@Override
	public void resume() {
		// do nothing
	}

	@Override
	public void create() {
		super.create();
		final TextureParameter param = new TextureParameter();
		param.minFilter = TextureFilter.MipMapLinearLinear;
		param.magFilter = TextureFilter.Linear;
		param.genMipMaps = true;

		for (String[] categories : SCREEN_IMAGE_PATHS) {
			for (String textureName : categories) {
				Assets.get().load(textureName, Texture.class, param);
			}
		}

		Assets.get().load(MainMenuScreen.BACKGROUND_PATH, Texture.class, param);
		Assets.get().load(MainMenuScreen.BUTTON_HELP_PRESSED_PATH, Texture.class, param);
		Assets.get().load(MainMenuScreen.BUTTON_HELP_UP_PATH, Texture.class, param);

		Assets.get().load(BUTTON_AIM, Texture.class, param);
		Assets.get().load(BUTTON_AIM_CHECKED, Texture.class, param);
		Assets.get().load(BUTTON_AIM_PRESSED, Texture.class, param);

		Assets.get().load(BUTTON_OBSTACLES, Texture.class, param);
		Assets.get().load(BUTTON_OBSTACLES_CHECKED, Texture.class, param);
		Assets.get().load(BUTTON_OBSTACLES_PRESSED, Texture.class, param);

		Assets.get().load(BUTTON_CLUBS, Texture.class, param);
		Assets.get().load(BUTTON_CLUBS_CHECKED, Texture.class, param);
		Assets.get().load(BUTTON_CLUBS_PRESSED, Texture.class, param);

		Assets.get().load(BUTTON_GOAL, Texture.class, param);
		Assets.get().load(BUTTON_GOAL_CHECKED, Texture.class, param);
		Assets.get().load(BUTTON_GOAL_PRESSED, Texture.class, param);

		Assets.get().load(BUTTON_BACKGROUND, Texture.class, param);
		Assets.get().load(BIG_DOT, Texture.class, param);
		Assets.get().load(SMALL_DOT, Texture.class, param);
	}

	@Override
	public void dispose() {
		super.dispose();
		for (String[] categories : SCREEN_IMAGE_PATHS) {
			for (String textureName : categories) {
				Assets.get().unload(textureName);
			}
		}

		Assets.get().unload(MainMenuScreen.BACKGROUND_PATH);
		Assets.get().unload(MainMenuScreen.BUTTON_HELP_PRESSED_PATH);
		Assets.get().unload(MainMenuScreen.BUTTON_HELP_UP_PATH);

		Assets.get().unload(BUTTON_AIM);
		Assets.get().unload(BUTTON_AIM_CHECKED);
		Assets.get().unload(BUTTON_AIM_PRESSED);

		Assets.get().unload(BUTTON_OBSTACLES);
		Assets.get().unload(BUTTON_OBSTACLES_CHECKED);
		Assets.get().unload(BUTTON_OBSTACLES_PRESSED);

		Assets.get().unload(BUTTON_CLUBS);
		Assets.get().unload(BUTTON_CLUBS_CHECKED);
		Assets.get().unload(BUTTON_CLUBS_PRESSED);

		Assets.get().unload(BUTTON_GOAL);
		Assets.get().unload(BUTTON_GOAL_CHECKED);
		Assets.get().unload(BUTTON_GOAL_PRESSED);

		Assets.get().unload(BUTTON_BACKGROUND);
		Assets.get().unload(BIG_DOT);
		Assets.get().unload(SMALL_DOT);
	}

	private void layoutDots() {
		// hide all dots from inactive categories
		for (int i = 0; i < mDotImages.length; i++) {
			for (int j = 0; j < mDotImages[i].length; j++) {
				if (mCurrentCategory != i) {
					mDotImages[i][j].addAction(Actions.fadeOut(0.0f));
				} else {
					mDotImages[i][j].addAction(Actions.fadeIn(0.0f));
				}

				if (mDotImages[i].length <= 1) { // don't show a single dot
					mDotImages[i][j].setVisible(false);
				}
			}
		}
	}

	private void layoutImages() {
		for (int i = 0; i < mImages.length; i++) {
			for (int j = 0; j < mImages[i].length; j++) {
				if (mCurrentCategory != i || mCurrentIndexes[mCurrentCategory] != j) {
					mImages[i][j].addAction(Actions.fadeOut(0.0f));
				} else {
					mImages[i][j].addAction(Actions.fadeIn(0.0f));
				}
			}
		}
	}

	private void changePage(boolean pShowNext) {
		Gdx.app.log(TAG, "changePage, current category: " + mCurrentCategory + " page: "
				+ mCurrentIndexes[mCurrentCategory] + " shownext: " + pShowNext);

		if (pShowNext && mCurrentIndexes[mCurrentCategory] < mImages[mCurrentCategory].length - 1) {
			mCurrentIndexes[mCurrentCategory]++;
			mImages[mCurrentCategory][mCurrentIndexes[mCurrentCategory] - 1]
					.addAction(Actions.fadeOut(TRANSITION_TIME));
			mImages[mCurrentCategory][mCurrentIndexes[mCurrentCategory]].addAction(Actions.fadeIn(TRANSITION_TIME));

			mDotImages[mCurrentCategory][mCurrentIndexes[mCurrentCategory] - 1].setDrawable(Assets.get()
					.getTextureRegionDrawable(SMALL_DOT));
			mDotImages[mCurrentCategory][mCurrentIndexes[mCurrentCategory]].setDrawable(Assets.get()
					.getTextureRegionDrawable(BIG_DOT));

		} else if (!pShowNext && mCurrentIndexes[mCurrentCategory] > 0) {
			mCurrentIndexes[mCurrentCategory]--;
			mImages[mCurrentCategory][mCurrentIndexes[mCurrentCategory]].addAction(Actions.fadeIn(TRANSITION_TIME));
			mImages[mCurrentCategory][mCurrentIndexes[mCurrentCategory] + 1]
					.addAction(Actions.fadeOut(TRANSITION_TIME));

			mDotImages[mCurrentCategory][mCurrentIndexes[mCurrentCategory]].setDrawable(Assets.get()
					.getTextureRegionDrawable(BIG_DOT));
			mDotImages[mCurrentCategory][mCurrentIndexes[mCurrentCategory] + 1].setDrawable(Assets.get()
					.getTextureRegionDrawable(SMALL_DOT));
		}
	}

	private void changeCategory(int pCategoryIndex) {
		Gdx.app.log(TAG, "changeCategory current category: " + mCurrentCategory + "  new category: " + pCategoryIndex);

		mImages[mCurrentCategory][mCurrentIndexes[mCurrentCategory]].addAction(Actions.fadeOut(TRANSITION_TIME));
		mImages[pCategoryIndex][mCurrentIndexes[pCategoryIndex]].addAction(Actions.fadeIn(TRANSITION_TIME));

		for (final Image image : mDotImages[mCurrentCategory]) {
			image.addAction(Actions.fadeOut(TRANSITION_TIME));
		}

		for (final Image image : mDotImages[pCategoryIndex]) {
			image.addAction(Actions.fadeIn(TRANSITION_TIME));
		}

		mCurrentCategory = pCategoryIndex;
	}

	private Stack createDotsStack() {
		final Stack dotsStack = new Stack() {

			@Override
			public void layout() {
				super.layout();
				layoutDots();
			}
		};

		for (int i = mTextures.length - 1; i >= 0; i--) {
			dotsStack.add(createDotsTable(i));
		}
		layoutDots();

		return dotsStack;
	}

	private Table createDotsTable(int pCategoryIndex) {
		final Table dotTable = new Table();

		for (int j = 0; j < mDotImages[pCategoryIndex].length; j++) {
			if (mCurrentIndexes[pCategoryIndex] == j) {
				mDotImages[pCategoryIndex][j] = new Image(Assets.get().getTextureRegionDrawable(BIG_DOT));
				dotTable.add(mDotImages[pCategoryIndex][j]).size(RELATIVE_DOT_SIZE)
						.padTop(CATEGORY_LAYOUT_BUTTON_PADDING);
			} else {
				mDotImages[pCategoryIndex][j] = new Image(Assets.get().getTextureRegionDrawable(SMALL_DOT));
				dotTable.add(mDotImages[pCategoryIndex][j]).size(RELATIVE_DOT_SIZE)
						.padTop(CATEGORY_LAYOUT_BUTTON_PADDING);
			}

			dotTable.row();
		}

		return dotTable;
	}

	private Table createCategoriesTable() {
		final Table categoriesTable = new Table();

		final Button aimButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_AIM), Assets.get()
				.getTextureRegionDrawable(BUTTON_AIM_PRESSED), Assets.get()
				.getTextureRegionDrawable(BUTTON_AIM_CHECKED));

		final Button clubsButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_CLUBS), Assets.get()
				.getTextureRegionDrawable(BUTTON_CLUBS_PRESSED), Assets.get().getTextureRegionDrawable(
				BUTTON_CLUBS_CHECKED));

		final Button goalButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_GOAL), Assets.get()
				.getTextureRegionDrawable(BUTTON_GOAL_PRESSED), Assets.get().getTextureRegionDrawable(
				BUTTON_GOAL_CHECKED));

		final Button obstaclesButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_OBSTACLES), Assets.get()
				.getTextureRegionDrawable(BUTTON_OBSTACLES_PRESSED), Assets.get().getTextureRegionDrawable(
				BUTTON_OBSTACLES_CHECKED));

		final ButtonGroup categoriesButtonGroup = new ButtonGroup();
		categoriesButtonGroup.add(aimButton);
		categoriesButtonGroup.add(goalButton);
		categoriesButtonGroup.add(clubsButton);
		categoriesButtonGroup.add(obstaclesButton);

		final ClickListener categoryClickListener = new ClickListener() {

			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				GolfAudioManager.playSound(AudioPaths.CLICK);
				return super.touchDown(event, x, y, pointer, button);
			}

			@Override
			public void clicked(InputEvent event, float x, float y) {
				final Actor actor = event.getListenerActor();

				if (aimButton.equals(actor)) {
					changeCategory(AIM_CATEGORY_INDEX);
				} else if (goalButton.equals(actor)) {
					changeCategory(GOAL_CATEGORY_INDEX);
				} else if (clubsButton.equals(actor)) {
					changeCategory(CLUBS_CATEGORY_INDEX);
				} else if (obstaclesButton.equals(actor)) {
					changeCategory(OBSTACLES_CATEGORY_INDEX);
				}
			}
		};

		for (final Button button : categoriesButtonGroup.getButtons()) {
			button.addListener(categoryClickListener);
		}

		final Image buttonBackgroundActor = new Image() {

			@Override
			public void draw(SpriteBatch batch, float parentAlpha) {
				final Sprite sprite = new Sprite(mButtonBackgroundTexture);
				sprite.setSize(getParent().getWidth() + MainMenuScreen.LAYOUT_BUTTON_PADDING, getParent().getHeight()
						+ 2 * MainMenuScreen.LAYOUT_BUTTON_PADDING);
				sprite.setPosition(0.0f, 0.0f);
				sprite.draw(batch);
			};
		};

		final Stack imagesStack = new Stack() {

			@Override
			public void layout() {
				super.layout();
				layoutImages();
			}
		};

		for (int i = mTextures.length - 1; i >= 0; i--) {
			for (int j = mTextures[i].length - 1; j >= 0; j--) {
				mImages[i][j] = new Image(mTextures[i][j]);
				imagesStack.add(mImages[i][j]);
			}
		}
		layoutImages();

		final Table imagesTable = new Table();

		for (final Button button : categoriesButtonGroup.getButtons()) {
			imagesTable.add(button).height(CATEGORY_BUTTON_HEIGHT).width(CATEGORY_BUTTON_WIDTH).left();
		}

		imagesTable.row();
		imagesTable.add(imagesStack).bottom().colspan(NUMBER_OF_CATEGORIES).pad(CATEGORY_LAYOUT_BUTTON_PADDING);

		categoriesTable.addActor(buttonBackgroundActor);

		categoriesTable.add(createDotsStack()).left();
		categoriesTable.add(imagesTable).expand().fill();

		return categoriesTable;
	}

	@Override
	protected Actor onCreateLayout() {
		mTextures = new Texture[NUMBER_OF_CATEGORIES][];

		for (int i = 0; i < SCREEN_IMAGE_PATHS.length; i++) {
			mTextures[i] = new Texture[SCREEN_IMAGE_PATHS[i].length];
			for (int j = 0; j < mTextures[i].length; j++) {
				mTextures[i][j] = Assets.get().get(SCREEN_IMAGE_PATHS[i][j]);
			}
		}

		mButtonBackgroundTexture = Assets.get().get(BUTTON_BACKGROUND);

		final Table table = new Table();
		table.pad(MainMenuScreen.LAYOUT_BUTTON_PADDING);
		table.setFillParent(true);
		setBackground(new Image(Assets.get().getTextureRegionDrawable(MainMenuScreen.BACKGROUND_PATH)));

		// Back button

		final Button helpButton = new Button(Assets.get().getTextureRegionDrawable(
				MainMenuScreen.BUTTON_HELP_PRESSED_PATH), Assets.get().getTextureRegionDrawable(
				MainMenuScreen.BUTTON_HELP_UP_PATH));

		helpButton.addListener(new ClickListener() {

			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				GolfAudioManager.playSound(AudioPaths.CLICK);
				return super.touchDown(event, x, y, pointer, button);
			}

			@Override
			public void clicked(InputEvent event, float x, float y) {
				final Actor actor = event.getListenerActor();
				if (helpButton.equals(actor)) {
					back();
				}
			}
		});

		table.add(createCategoriesTable()).expand().fill().left();
		table.add(helpButton).bottom().right().size(MainMenuScreen.LAYOUT_BUTTON_HELP_SIZE);

		return table;
	}

	@Override
	protected void onShow() {
		getInputMultiplexer().addProcessor(this);
		getInputMultiplexer().addProcessor(mGestureDetector);
	}

	@Override
	protected void onHide() {
		getInputMultiplexer().removeProcessor(mGestureDetector);
		getInputMultiplexer().removeProcessor(this);
	}

	private void back() {
		// XXX: Change this method if HelpScreen is started from outside of the main menu
		setScreen(ScreenType.SCREEN_MAIN_MENU);
	}

	@Override
	public boolean keyDown(int keycode) {
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		switch (keycode) {
		case Keys.BACK:
		case Keys.ESCAPE:
			back();
			return true;
		default:
			return false;
		}
	}

	@Override
	public boolean keyTyped(char character) {
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		return false;
	}

	@Override
	public boolean touchDown(float x, float y, int pointer, int button) {
		return false;
	}

	@Override
	public boolean tap(float x, float y, int count, int button) {
		return false;
	}

	@Override
	public boolean longPress(float x, float y) {
		return false;
	}

	@Override
	public boolean fling(float velocityX, float velocityY, int button) {
		if (Math.abs(velocityY) > TERMINAL_VELOCITY) {
			changePage(velocityY < 0);
		}
		return true;
	}

	@Override
	public boolean pan(float x, float y, float deltaX, float deltaY) {
		return false;
	}

	@Override
	public boolean zoom(float initialDistance, float distance) {
		return false;
	}

	@Override
	public boolean pinch(Vector2 initialPointer1, Vector2 initialPointer2, Vector2 pointer1, Vector2 pointer2) {
		return false;
	}
}
