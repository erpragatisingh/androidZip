/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.assets.loaders.TextureLoader.TextureParameter;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.srpol.golf.ScreenType;
import com.srpol.golf.utils.Assets;
import com.srpol.golf.utils.AudioPaths;
import com.srpol.golf.utils.GolfAudioManager;

/**
 * A {@link GolfScreen} implementation that shows the main menu.
 */
public class MainMenuScreen extends UiScreen implements InputProcessor {

	private static final String TAG = MainMenuScreen.class.getSimpleName();

	private static final boolean DEBUG_TABLE = false;

	private static final String BUTTON_PLAY_PRESSED_PATH = "mainmenu/button_play_pressed.png";
	private static final String BUTTON_PLAY_PATH = "mainmenu/button_play.png";
	/** About button image path (pressed). */
	static final String BUTTON_ABOUT_PRESSED_PATH = "mainmenu/button_about_pressed.png";
	/** About button image path (not pressed). */
	static final String BUTTON_ABOUT_PATH = "mainmenu/button_about.png";
	/** Options button image path (pressed). */
	static final String BUTTON_OPTIONS_PRESSED_PATH = "mainmenu/button_options_pressed.png";
	/** Options button image path (not pressed). */
	static final String BUTTON_OPTIONS_PATH = "mainmenu/button_options.png";
	/** Help button image path (not pressed). */
	static final String BUTTON_HELP_UP_PATH = "mainmenu/button_help.png";
	/** Help button image path (pressed). */
	static final String BUTTON_HELP_PRESSED_PATH = "mainmenu/button_help_pressed.png";
	/** Common background image path. */
	static final String BACKGROUND_PATH = "mainmenu/background.png";

	/** Common padding for all menu tables. */
	static final float LAYOUT_BUTTON_PADDING = 25.0f;

	private static final float LAYOUT_BUTTON_PLAY_SIZE = 200.0f;
	/** About button size. */
	static final float LAYOUT_BUTTON_ABOUT_SIZE = 150.0f;
	/** Help button size. */
	static final float LAYOUT_BUTTON_HELP_SIZE = 150.0f;
	/** Options button size. */
	static final float LAYOUT_BUTTON_OPTIONS_SIZE = 150.0f;

	/**
	 * Constructs the {@link MainMenuScreen}.
	 * 
	 * @param game
	 *            {@link Game} instance
	 * @param type
	 *            {@link ScreenType} of this screen
	 */
	public MainMenuScreen(Game game, ScreenType type) {
		super(game, type);
	}

	@Override
	void onRender(float delta) {
		super.onRender(delta);
		if (DEBUG_TABLE) {
			Table.drawDebug(getStage());
		}
	}

	@Override
	protected void onShow() {
		GolfAudioManager.playMusic(AudioPaths.MENU_MUSIC);
		GolfAudioManager.setLoopingMusic(AudioPaths.MENU_MUSIC, true);
		getInputMultiplexer().addProcessor(this);
	}

	@Override
	protected void onHide() {
		// XXX Temporary code
		getInputMultiplexer().removeProcessor(this);
	}

	@Override
	public void create() {
		super.create();
		final TextureParameter param = new TextureParameter();
		param.minFilter = TextureFilter.MipMapLinearLinear;
		param.magFilter = TextureFilter.Linear;
		param.genMipMaps = true;

		Assets.get().load(BUTTON_PLAY_PRESSED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_PLAY_PATH, Texture.class, param);
		Assets.get().load(BUTTON_ABOUT_PRESSED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_ABOUT_PATH, Texture.class, param);
		Assets.get().load(BUTTON_OPTIONS_PRESSED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_OPTIONS_PATH, Texture.class, param);
		Assets.get().load(BUTTON_HELP_PRESSED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_HELP_UP_PATH, Texture.class, param);
		Assets.get().load(BACKGROUND_PATH, Texture.class, param);
		GolfAudioManager.addMusic(AudioPaths.MENU_MUSIC);
	}

	@Override
	public void dispose() {
		super.dispose();

		Assets.get().unload(BUTTON_PLAY_PRESSED_PATH);
		Assets.get().unload(BUTTON_PLAY_PATH);
		Assets.get().unload(BUTTON_ABOUT_PRESSED_PATH);
		Assets.get().unload(BUTTON_ABOUT_PATH);
		Assets.get().unload(BUTTON_OPTIONS_PRESSED_PATH);
		Assets.get().unload(BUTTON_OPTIONS_PATH);
		Assets.get().unload(BUTTON_HELP_PRESSED_PATH);
		Assets.get().unload(BUTTON_HELP_UP_PATH);
		Assets.get().unload(BACKGROUND_PATH);
		GolfAudioManager.disposeMusic(AudioPaths.MENU_MUSIC);
	}

	@Override
	public void pause() {

	}

	@Override
	public void resume() {
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		switch (keycode) {
		case Keys.BACK:
		case Keys.ESCAPE:
			exit();
			return true;
		default:
			return false;
		}
	}

	@Override
	public boolean keyTyped(char character) {
		return false;
	}

	@Override
	public boolean keyDown(int keycode) {
		return false;
	}

	/**
	 * Exits the application.
	 */
	private void exit() {
		final QuitDialog screen = (QuitDialog) findScreen(ScreenType.SCREEN_QUIT_DIALOG);
		screen.setParent(this);
		setScreen(screen);
	}

	@Override
	protected Actor onCreateLayout() {
		final Table table = new Table();
		table.setFillParent(true);
		table.pad(LAYOUT_BUTTON_PADDING);

		if (DEBUG_TABLE) {
			table.debug();
		}

		// Background

		final Image backgroundImage = new Image(Assets.get().get(BACKGROUND_PATH, Texture.class));
		setBackground(backgroundImage);

		final Button playButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_PLAY_PATH), Assets.get()
				.getTextureRegionDrawable(BUTTON_PLAY_PRESSED_PATH));

		final Button aboutButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_ABOUT_PATH), Assets.get()
				.getTextureRegionDrawable(BUTTON_ABOUT_PRESSED_PATH));

		final Button helpButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_HELP_UP_PATH), Assets.get()
				.getTextureRegionDrawable(BUTTON_HELP_PRESSED_PATH));

		final Button optionsButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_OPTIONS_PATH), Assets
				.get().getTextureRegionDrawable(BUTTON_OPTIONS_PRESSED_PATH));

		final ClickListener clickListener = new ClickListener() {

			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				GolfAudioManager.playSound(AudioPaths.CLICK);
				return super.touchDown(event, x, y, pointer, button);
			}

			@Override
			public void clicked(InputEvent event, float x, float y) {
				final Actor buttonActor = event.getListenerActor();
				if (aboutButton.equals(buttonActor)) {
					setScreen(ScreenType.SCREEN_ABOUT);
				} else if (playButton.equals(buttonActor)) {
					setScreen(ScreenType.SCREEN_CHAPTER_SELECTION);
				} else if (optionsButton.equals(buttonActor)) {
					setScreen(ScreenType.SCREEN_OPTIONS);
				} else if (helpButton.equals(buttonActor)) {
					setScreen(ScreenType.SCREEN_HELP);
				}
			}
		};

		table.add(playButton).colspan(3).expand().size(LAYOUT_BUTTON_PLAY_SIZE);
		table.row();
		table.add(aboutButton).bottom().left().size(LAYOUT_BUTTON_ABOUT_SIZE);
		table.add(optionsButton).bottom().center().size(LAYOUT_BUTTON_OPTIONS_SIZE);
		table.add(helpButton).bottom().right().size(LAYOUT_BUTTON_HELP_SIZE);

		playButton.addListener(clickListener);
		aboutButton.addListener(clickListener);
		optionsButton.addListener(clickListener);
		helpButton.addListener(clickListener);

		return table;
	}
}
