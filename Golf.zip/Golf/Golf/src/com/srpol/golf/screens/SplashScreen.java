/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.loaders.TextureLoader.TextureParameter;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.srpol.golf.ScreenType;
import com.srpol.golf.utils.Assets;
import com.srpol.golf.utils.GolfAudioManager;
import com.srpol.golf.utils.GolfPreferences;

/**
 * This class represents splash screen of the game.
 */
public class SplashScreen extends UiScreen {

	private static final float SPLASH_TIME = 3.0f;
	private static final String SPLASH_IMAGE_PATH = "splash.png";
	private float mTime;
	private GolfScreen mNextScreen;

	/**
	 * Constructor.
	 * 
	 * @param game
	 *            {@link Game} instance
	 * @param type
	 *            {@link ScreenType} of this screen
	 */
	public SplashScreen(Game game, ScreenType type) {
		super(game, type);
	}

	@Override
	public void pause() {

	}

	@Override
	public void resume() {

	}

	@Override
	public void create() {
		super.create();
		final TextureParameter param = new TextureParameter();
		param.minFilter = TextureFilter.MipMapLinearLinear;
		param.magFilter = TextureFilter.Linear;
		param.genMipMaps = true;

		Assets.get().load(SPLASH_IMAGE_PATH, Texture.class, param);
		Assets.get().finishLoading();

		final Image background = new Image(Assets.get().get(SPLASH_IMAGE_PATH, Texture.class));
		setBackground(background);
	}

	@Override
	public void dispose() {
		super.dispose();
		Assets.get().unload(SPLASH_IMAGE_PATH);
	}

	@Override
	protected Actor onCreateLayout() {
		return null;
	}

	@Override
	void onRender(float delta) {
		super.onRender(delta);

		mTime += delta;

		if (Assets.get().update() && (Gdx.input.justTouched() || mTime > SPLASH_TIME)) {

			// All assets loaded
			mGame.setScreen(mNextScreen);
		}
	}

	@Override
	protected void onShow() {
		GolfAudioManager.setAndSwitchMusicsOn(GolfPreferences.INSTANCE.isMusicOn());
		GolfAudioManager.setSoundsOn(GolfPreferences.INSTANCE.isSoundOn());

		mNextScreen = findScreen(ScreenType.SCREEN_MAIN_MENU);
		mNextScreen.getParentNode().createScreens();
	}

	@Override
	protected void onHide() {
		dispose();
	}
}
