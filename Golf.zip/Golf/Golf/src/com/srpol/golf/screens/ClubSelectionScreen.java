/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.assets.loaders.TextureLoader.TextureParameter;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.ButtonGroup;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Array;
import com.srpol.golf.ScreenType;
import com.srpol.golf.models.ClubModel;
import com.srpol.golf.models.ClubModel.ClubType;
import com.srpol.golf.utils.Assets;
import com.srpol.golf.utils.AudioPaths;
import com.srpol.golf.utils.GolfAudioManager;

/**
 * Golf club selection screen.
 */
public class ClubSelectionScreen extends AbstractTransparentScreen {

	private static final String TAG = ClubSelectionScreen.class.getSimpleName();
	private static final boolean DEBUG_TABLE = false;

	private static final String CLUB_SELECTION_BACKGROUND = "gamescreen/club_selection_background.png";
	private static final String TEXT_SELECT_GOLF_CLUB = "gamescreen/select_golf_club.png";
	private static final String BUTTON_CLUB_SELECTION_PRESSED_PATH = "gamescreen/button_club_selection_pressed.png";
	private static final String BUTTON_WOODEN_CLUB_PATH = "gamescreen/button_wooden_club.png";
	private static final String BUTTON_WOODEN_CLUB_CHECKED_PATH = "gamescreen/button_wooden_club_checked.png";
	private static final String BUTTON_WOODEN_CLUB_PRESSED_PATH = "gamescreen/button_wooden_club_pressed.png";
	private static final String BUTTON_IRON_CLUB_PATH = "gamescreen/button_iron_club.png";
	private static final String BUTTON_IRON_CLUB_CHECKED_PATH = "gamescreen/button_iron_club_checked.png";
	private static final String BUTTON_IRON_CLUB_PRESSED_PATH = "gamescreen/button_iron_club_pressed.png";
	private static final String BUTTON_PUTTER_CLUB_PATH = "gamescreen/button_putter_club.png";
	private static final String BUTTON_PUTTER_CLUB_CHECKED_PATH = "gamescreen/button_putter_club_checked.png";
	private static final String BUTTON_PUTTER_CLUB_PRESSED_PATH = "gamescreen/button_putter_club_pressed.png";
	private static final float LAYOUT_BUTTON_PADDING = 25.0f;
	private static final float BUTTON_CLUB_WIDTH = 120.0f;
	private static final float BUTTON_CLUB_HEIGHT = 200.0f;
	private static final float SIGN_WIDTH = 516.0f;
	private static final float SIGN_HEIGHT = 67.0f;
	private ButtonGroup mButtonGroup;
	private ClubModel.ClubType mCurrentClubType;

	private final GolfClubButtonMap mGolfClubButtonMap;

	/**
	 * Constructs the {@link ClubSelectionScreen}.
	 * 
	 * @param game
	 *            {@link Game} instance
	 * @param type
	 *            {@link ScreenType} of this screen
	 */
	public ClubSelectionScreen(Game game, ScreenType type) {
		super(game, type);
		mGolfClubButtonMap = new GolfClubButtonMap();
	}

	void setCurrentClubType(ClubModel.ClubType pCurrentClubType) {
		mCurrentClubType = pCurrentClubType;
		invalidateButtonSelection();
	}

	@Override
	public void create() {
		super.create();

		final TextureParameter param = new TextureParameter();
		param.minFilter = TextureFilter.MipMapLinearLinear;
		param.magFilter = TextureFilter.Linear;
		param.genMipMaps = true;
		Assets.get().load(CLUB_SELECTION_BACKGROUND, Texture.class, param);
		Assets.get().load(TEXT_SELECT_GOLF_CLUB, Texture.class, param);
		Assets.get().load(BUTTON_CLUB_SELECTION_PRESSED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_WOODEN_CLUB_PATH, Texture.class, param);
		Assets.get().load(BUTTON_WOODEN_CLUB_CHECKED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_WOODEN_CLUB_PRESSED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_IRON_CLUB_PATH, Texture.class, param);
		Assets.get().load(BUTTON_IRON_CLUB_CHECKED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_IRON_CLUB_PRESSED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_PUTTER_CLUB_PATH, Texture.class, param);
		Assets.get().load(BUTTON_PUTTER_CLUB_CHECKED_PATH, Texture.class, param);
		Assets.get().load(BUTTON_PUTTER_CLUB_PRESSED_PATH, Texture.class, param);
	}

	@Override
	public void show() {
		super.show();

		invalidateButtonSelection();
	}

	@Override
	protected Actor onCreateLayout() {
		Gdx.app.debug(TAG, "createLayout start");

		final Table table = new Table();
		table.setFillParent(true);
		table.setBackground(Assets.get().getTextureRegionDrawable(CLUB_SELECTION_BACKGROUND));
		table.pad(LAYOUT_BUTTON_PADDING);

		if (DEBUG_TABLE) {
			table.debug();
		}

		createClubSelectionTable(table);
		createClubSelectionButton(table);

		return table;
	}

	@Override
	void onRender(float delta) {
		super.onRender(delta);
		if (DEBUG_TABLE) {
			Table.drawDebug(getStage());
		}
	}

	private void createClubSelectionTable(Table pParentTable) {
		final Table clubSelectionTable = new Table();
		clubSelectionTable.pad(LAYOUT_BUTTON_PADDING);

		clubSelectionTable.add(new Image(Assets.get().getTextureRegionDrawable(TEXT_SELECT_GOLF_CLUB)))
				.width(SIGN_WIDTH).height(SIGN_HEIGHT).expand().center();
		clubSelectionTable.row();

		final Table internalClubSelectionTable = new Table();
		internalClubSelectionTable.pad(LAYOUT_BUTTON_PADDING);

		// Create club buttons
		final Button ironClubButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_IRON_CLUB_PATH), Assets
				.get().getTextureRegionDrawable(BUTTON_IRON_CLUB_PRESSED_PATH), Assets.get().getTextureRegionDrawable(
				BUTTON_IRON_CLUB_CHECKED_PATH));

		final Button woodenClubButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_WOODEN_CLUB_PATH),
				Assets.get().getTextureRegionDrawable(BUTTON_WOODEN_CLUB_PRESSED_PATH), Assets.get()
						.getTextureRegionDrawable(BUTTON_WOODEN_CLUB_CHECKED_PATH));

		final Button putterClubButton = new Button(Assets.get().getTextureRegionDrawable(BUTTON_PUTTER_CLUB_PATH),
				Assets.get().getTextureRegionDrawable(BUTTON_PUTTER_CLUB_PRESSED_PATH), Assets.get()
						.getTextureRegionDrawable(BUTTON_PUTTER_CLUB_CHECKED_PATH));

		// Common click listener for all the clubs
		final ClickListener golfClubClickListener = new ClickListener() {

			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				GolfAudioManager.playSound(AudioPaths.CLICK);
				return true;
			}

			@Override
			public void touchUp(InputEvent event, float x, float y, int pointer, int button) {
				final Actor buttonActor = event.getListenerActor();
				if (ironClubButton.equals(buttonActor.hit(x, y, false))
						|| woodenClubButton.equals(buttonActor.hit(x, y, false))
						|| putterClubButton.equals(buttonActor.hit(x, y, false))) {
					applyClubSelection();
				}
			}
		};

		ironClubButton.addListener(golfClubClickListener);
		woodenClubButton.addListener(golfClubClickListener);
		putterClubButton.addListener(golfClubClickListener);

		internalClubSelectionTable.add(ironClubButton).width(BUTTON_CLUB_WIDTH).height(BUTTON_CLUB_HEIGHT).left();
		internalClubSelectionTable.add(woodenClubButton).width(BUTTON_CLUB_WIDTH).height(BUTTON_CLUB_HEIGHT).center();
		internalClubSelectionTable.add(putterClubButton).width(BUTTON_CLUB_WIDTH).height(BUTTON_CLUB_HEIGHT).right();

		clubSelectionTable.add(internalClubSelectionTable).expand().center();

		pParentTable.add(clubSelectionTable).expand().colspan(2).center();
		pParentTable.row();

		// Fill the Button -> ClubType map
		mGolfClubButtonMap.clear();
		mGolfClubButtonMap.put(ironClubButton, ClubModel.ClubType.IRON);
		mGolfClubButtonMap.put(woodenClubButton, ClubModel.ClubType.WOODEN);
		mGolfClubButtonMap.put(putterClubButton, ClubModel.ClubType.PUTTER);

		// Group all club buttons, so that exactly one button is always checked
		mButtonGroup = new ButtonGroup();
		mButtonGroup.add(woodenClubButton);
		mButtonGroup.add(ironClubButton);
		mButtonGroup.add(putterClubButton);

		invalidateButtonSelection();
	}

	private void invalidateButtonSelection() {
		final Button button = mGolfClubButtonMap.getButton(mCurrentClubType);
		if (button != null) {
			mButtonGroup.uncheckAll();
			button.setChecked(true);
		}
	}

	private void createClubSelectionButton(Table pParentTable) {
		Gdx.app.debug(TAG, "createClubSelectionButton start");

		final Button mClubSelectionButton = new Button(Assets.get().getTextureRegionDrawable(
				BUTTON_CLUB_SELECTION_PRESSED_PATH), Assets.get().getTextureRegionDrawable(
				BUTTON_CLUB_SELECTION_PRESSED_PATH), Assets.get().getTextureRegionDrawable(
				BUTTON_CLUB_SELECTION_PRESSED_PATH));
		mClubSelectionButton.addListener(new ClickListener() {

			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				GolfAudioManager.playSound(AudioPaths.CLICK);
				return super.touchDown(event, x, y, pointer, button);
			}

			@Override
			public void clicked(InputEvent event, float x, float y) {
				final Actor actor = event.getListenerActor();

				if (mClubSelectionButton.equals(actor)) {
					showParent();
				}
			}
		});

		mClubSelectionButton.setChecked(true);

		pParentTable.add(mClubSelectionButton).expand().bottom().right();
	}

	private void applyClubSelection() {
		final ClubType clubType = mGolfClubButtonMap.getClubType(mButtonGroup.getChecked());
		setCurrentClubType(clubType);
		((GameScreen) getParent()).setClubType(clubType);
		showParent();
	}

	@Override
	public void pause() {
		// Do nothing.
	}

	@Override
	public void resume() {
		// Do nothing.
	}

	@Override
	public void dispose() {
		super.dispose();

		Assets.get().unload(CLUB_SELECTION_BACKGROUND);
		Assets.get().unload(TEXT_SELECT_GOLF_CLUB);
		Assets.get().unload(BUTTON_CLUB_SELECTION_PRESSED_PATH);
		Assets.get().unload(BUTTON_WOODEN_CLUB_PATH);
		Assets.get().unload(BUTTON_WOODEN_CLUB_CHECKED_PATH);
		Assets.get().unload(BUTTON_WOODEN_CLUB_PRESSED_PATH);
		Assets.get().unload(BUTTON_IRON_CLUB_PATH);
		Assets.get().unload(BUTTON_IRON_CLUB_CHECKED_PATH);
		Assets.get().unload(BUTTON_IRON_CLUB_PRESSED_PATH);
		Assets.get().unload(BUTTON_PUTTER_CLUB_PATH);
		Assets.get().unload(BUTTON_PUTTER_CLUB_CHECKED_PATH);
		Assets.get().unload(BUTTON_PUTTER_CLUB_PRESSED_PATH);
	}

	@Override
	boolean onKeyUpClick(int keyCode) {
		if (keyCode == Keys.BACK || keyCode == Keys.ESCAPE) {
			showParent();
			return true;
		}
		return false;
	}

	@Override
	boolean onKeyDownClick(int keyCode) {
		if (keyCode == Keys.BACK || keyCode == Keys.ESCAPE) {
			return true;
		}
		return false;
	}

	/**
	 * Class representing a <Button, ClubModel.ClubType> pair. In case of two identical 'key' elements, the first value
	 * will be returned.
	 */
	private final class GolfClubButtonMap {
		private final int mInitialArraySize = ClubModel.ClubType.values().length;
		private final Array<Button> mButtons = new Array<Button>(mInitialArraySize);
		private final Array<ClubModel.ClubType> mClubTypes = new Array<ClubModel.ClubType>(mInitialArraySize);

		// Protect the constructor
		private GolfClubButtonMap() {
			// do nothing
		}

		private void clear() {
			mButtons.clear();
			mClubTypes.clear();
		}

		private void put(Button pButton, ClubModel.ClubType pClubType) {
			mButtons.add(pButton);
			mClubTypes.add(pClubType);
		}

		private Button getButton(ClubModel.ClubType pClubType) {
			final int index = mClubTypes.indexOf(pClubType, true);
			if (index < 0) {
				return null;
			} else {
				return mButtons.get(index);
			}
		}

		private ClubModel.ClubType getClubType(Button pButton) {
			final int index = mButtons.indexOf(pButton, true);
			if (index < 0) {
				return null;
			} else {
				return mClubTypes.get(index);
			}
		}
	}
}
