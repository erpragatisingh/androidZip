/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.InputProcessor;
import com.srpol.golf.ScreenType;

/**
 * Base class for semi-transparent Screens displayed on top of a parent Screen.
 */
public abstract class AbstractTransparentScreen extends UiScreen implements InputProcessor {

	private GolfScreen mParent;

	/**
	 * Constructs {@link AbstractTransparentScreen}.
	 * 
	 * @param game
	 *            instance of {@link Game}
	 * @param parent
	 *            instance of {@link GolfScreen}
	 */
	AbstractTransparentScreen(Game game, ScreenType type) {
		super(game, type);
	}

	public void setParent(GolfScreen parent) {
		mParent = parent;
	}

	public GolfScreen getParent() {
		return mParent;
	}

	@Override
	public boolean keyDown(int keycode) {
		return onKeyDownClick(keycode);
	}

	@Override
	public boolean keyUp(int keycode) {
		return onKeyUpClick(keycode);
	}

	/**
	 * Calls when some key is up.
	 * 
	 * @param keycode
	 *            code of button
	 * @return true if action is handled, otherwise false
	 */
	abstract boolean onKeyUpClick(int keycode);

	/**
	 * Calls when some key is down.
	 * 
	 * @param keycode
	 *            code of button
	 * @return true if action is handled, otherwise false
	 */
	abstract boolean onKeyDownClick(int keycode);

	@Override
	public boolean keyTyped(char character) {
		// Do nothing
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		// Do nothing
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		// Do nothing
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		// Do nothing
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		// Do nothing
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		// Do nothing
		return false;
	}

	@Override
	public void resize(int width, int height) {
		mParent.resize(width, height);
		super.resize(width, height);
	}

	@Override
	void onRender(float delta) {
		if (!equals(mParent)) {
			mParent.onRender(delta);
		}
		super.onRender(delta);
	}

	@Override
	protected void onShow() {
		getInputMultiplexer().addProcessor(this);
	}

	@Override
	protected void onHide() {
		getInputMultiplexer().removeProcessor(this);
	}

	/**
	 * Shows the parent screen.
	 */
	protected void showParent() {
		setScreen(mParent);
	}
}
