/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Logger;
import com.srpol.golf.screens.AboutScreen;
import com.srpol.golf.screens.ChapterSelectionScreen;
import com.srpol.golf.screens.ClubSelectionScreen;
import com.srpol.golf.screens.EndLevelDialog;
import com.srpol.golf.screens.GameMenuScreen;
import com.srpol.golf.screens.GameScreen;
import com.srpol.golf.screens.GolfScreen;
import com.srpol.golf.screens.HelpScreen;
import com.srpol.golf.screens.LevelSelectionScreen;
import com.srpol.golf.screens.LoadingScreen;
import com.srpol.golf.screens.MainMenuScreen;
import com.srpol.golf.screens.OptionsScreen;
import com.srpol.golf.screens.QuitDialog;
import com.srpol.golf.screens.SplashScreen;
import com.srpol.golf.utils.Assets;
import com.srpol.golf.utils.GolfAudioManager;

/**
 * Main {@link Game} implementation.
 */
public class GolfGame extends Game {

	@Override
	public void create() {

		// Create the screen flow graph

		final GolfScreen splashScreen = new SplashScreen(this, ScreenType.SCREEN_SPLASH);
		final GolfScreen mainMenuScreen = new MainMenuScreen(this, ScreenType.SCREEN_MAIN_MENU);
		final GolfScreen helpScreen = new HelpScreen(this, ScreenType.SCREEN_HELP);
		final GolfScreen optionsScreen = new OptionsScreen(this, ScreenType.SCREEN_OPTIONS);
		final GolfScreen aboutScreen = new AboutScreen(this, ScreenType.SCREEN_ABOUT);
		final GolfScreen quitDialog = new QuitDialog(this, ScreenType.SCREEN_QUIT_DIALOG);
		final GolfScreen chapterSelectionScreen = new ChapterSelectionScreen(this, ScreenType.SCREEN_CHAPTER_SELECTION);
		final GolfScreen loadingScreen = new LoadingScreen(this, ScreenType.SCREEN_LOADING);
		final GolfScreen levelSelectionScreen = new LevelSelectionScreen(this, ScreenType.SCREEN_LEVEL_SELECTION);
		final GolfScreen gameScreen = new GameScreen(this, ScreenType.SCREEN_GAME);
		final GolfScreen gameMenuScreen = new GameMenuScreen(this, ScreenType.SCREEN_GAME_MENU);
		final GolfScreen endLevelDialog = new EndLevelDialog(this, ScreenType.SCREEN_END_LEVEL_DIALOG);
		final GolfScreen clubSelectionScreen = new ClubSelectionScreen(this, ScreenType.SCREEN_CLUB_SELECTION);

		final ScreenGraph graph = new ScreenGraph();
		graph.add(loadingScreen);

		final ScreenGraph.Node splashNode = graph.createNode();
		splashNode.add(splashScreen);

		final ScreenGraph.Node mainNode = graph.createNode();
		mainNode.add(mainMenuScreen);
		mainNode.add(helpScreen);
		mainNode.add(optionsScreen);
		mainNode.add(aboutScreen);
		mainNode.add(quitDialog);
		mainNode.add(chapterSelectionScreen);

		final ScreenGraph.Node levelGroup = graph.createNode();
		levelGroup.add(levelSelectionScreen);

		final ScreenGraph.Node gameGroup = graph.createNode();
		gameGroup.add(gameScreen);
		gameGroup.add(gameMenuScreen);
		gameGroup.add(endLevelDialog);
		gameGroup.add(clubSelectionScreen);

		// Enable game-wide logging

		Gdx.app.setLogLevel(Logger.ERROR);

		splashScreen.create();
		loadingScreen.create();
		setScreen(splashScreen);
	}

	@Override
	public void dispose() {
		super.dispose();

		GolfAudioManager.clearAudioRes();
		Assets.get().clear();
	}
}
