/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.models.gamelogic;

import java.util.LinkedList;
import java.util.List;

/**
 * Class contains information about game structure.
 */
public class GameLogicModel {
	private List<ChapterLogicModel> mChapterModels;

	/**
	 * Constructs {@link GameLogicModel}.
	 */
	public GameLogicModel() {
		mChapterModels = new LinkedList<ChapterLogicModel>();
	}

	/**
	 * Adds {@link ChapterLogicModel} object. See {@link List#add(Object)}.
	 * 
	 * @param chapterModel
	 *            instance of {@link ChapterLogicModel}
	 */
	public void addChapter(ChapterLogicModel chapterModel) {
		mChapterModels.add(chapterModel);
	}

	/**
	 * Returns number of chapter. {@link List#size()}.
	 * 
	 * @return number of chapter
	 */
	public int getChapterCount() {
		return mChapterModels.size();
	}

	/**
	 * Returns chapter at index. Throws IndexOutOfBoundsException exception if index >=
	 * {@link GameLogicModel#getChapterCount() }. See {@link List#get(int)}.
	 * 
	 * 
	 * @param index
	 *            index of chapter which will be returned
	 * @return instance of {@link ChapterLogicModel}
	 */
	public ChapterLogicModel getChapterAt(int index) {
		return mChapterModels.get(index);
	}

}
