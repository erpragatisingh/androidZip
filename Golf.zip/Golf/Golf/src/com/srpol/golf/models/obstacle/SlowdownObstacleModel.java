/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.models.obstacle;

import com.badlogic.gdx.graphics.g2d.tiled.TiledMap;

/**
 * Contains information about an obstacle which slows down the ball.
 */
public class SlowdownObstacleModel extends AbstractObstacleModel {

	private static final String DEPTH = "depth";
	private float mDepth;

	/**
	 * Constructs {@link SlowdownObstacleModel}.
	 */
	public SlowdownObstacleModel() {
		// Empty
	}

	/**
	 * Returns information how deep is obstacle.
	 * 
	 * @return deep
	 */
	public float getDepth() {
		return mDepth;
	}

	/**
	 * Sets information how deep is obstacle.
	 * 
	 * @param depth
	 *            depth of obstacle
	 */
	public void setDepth(float depth) {
		mDepth = depth;
	}

	@Override
	public ObstacleType getTypeObstacle() {
		return ObstacleType.SLOW_DOWN;
	}

	@Override
	public void setObstacleDataFromTiledMap(TiledMap map, int obstacleIndex, int x, int y) {
		super.setObstacleDataFromTiledMap(map, obstacleIndex, x, y);
		final String deepStr = map.getTileProperty(obstacleIndex, DEPTH);
		setDepth(Float.parseFloat(deepStr));
	}
}
