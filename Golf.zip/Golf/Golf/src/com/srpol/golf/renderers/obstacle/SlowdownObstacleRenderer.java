/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.renderers.obstacle;

import com.badlogic.gdx.graphics.Camera;
import com.srpol.golf.models.obstacle.SlowdownObstacleModel;

/**
 * Class used to draw the obstacle which slows down the ball.
 */
public class SlowdownObstacleRenderer extends AbstractObstacleRenderer<SlowdownObstacleModel> {

	/**
	 * Constructs {@link SlowdownObstacleRenderer}.
	 * 
	 * @param slowdownObstacleModel
	 *            information about obstacle {@link SlowdownObstacleModel}
	 */
	public SlowdownObstacleRenderer(SlowdownObstacleModel slowdownObstacleModel) {
		super(slowdownObstacleModel);
	}

	@Override
	void debugRender(Camera camera) {
		// do nothing -
	}

}
