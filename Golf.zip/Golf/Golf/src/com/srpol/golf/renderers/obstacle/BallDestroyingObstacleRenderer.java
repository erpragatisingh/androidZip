/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf.renderers.obstacle;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.srpol.golf.models.obstacle.BallDestroyingObstacleModel;

/**
 * Class used to draw the obstacle which destroys the ball.
 */
public class BallDestroyingObstacleRenderer extends AbstractObstacleRenderer<BallDestroyingObstacleModel> {

	private ShapeRenderer mShapeRenderer;

	/**
	 * Constructs {@link BallDestroyingObstacleRenderer}.
	 * 
	 * @param ballDestroyingObstacleModel
	 *            object contains information about obstacle which destroys the ball {@link BallDestroyingObstacleModel}
	 */
	public BallDestroyingObstacleRenderer(BallDestroyingObstacleModel ballDestroyingObstacleModel) {
		super(ballDestroyingObstacleModel);
		if (DEBUG_RENDERING) {
			mShapeRenderer = new ShapeRenderer();
		}
	}

	@Override
	void debugRender(Camera camera) {
		mShapeRenderer.setProjectionMatrix(camera.projection);
		mShapeRenderer.setTransformMatrix(camera.view);

		mShapeRenderer.begin(ShapeType.Rectangle);
		mShapeRenderer.setColor(Color.YELLOW);
		mShapeRenderer.rect(getObstacleModel().getPositionX(), getObstacleModel().getPositionY(), getObstacleModel()
				.getWidth(), getObstacleModel().getHeight());
		mShapeRenderer.end();
	}
}
