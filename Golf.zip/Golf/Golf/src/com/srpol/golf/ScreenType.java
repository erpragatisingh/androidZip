/*
 ********************************************************************************
 * Copyright (c) 2013 Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is a confidential and proprietary information of Samsung
 * Electronics, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Samsung Electronics.
 ********************************************************************************
 */
package com.srpol.golf;

/**
 * Enumeration of screen types.
 */
public enum ScreenType {
	// @formatter:off
	SCREEN_SPLASH,
	SCREEN_MAIN_MENU,
	SCREEN_ABOUT,
	SCREEN_OPTIONS,
	SCREEN_HELP,
	SCREEN_CHAPTER_SELECTION,
	SCREEN_LEVEL_SELECTION,
	SCREEN_GAME,
	SCREEN_QUIT_DIALOG,
	SCREEN_GAME_MENU,
	SCREEN_CLUB_SELECTION,
	SCREEN_END_LEVEL_DIALOG,
	SCREEN_LOADING
	// @formatter:on
}
