package com.srpol.golf.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.srpol.golf.GolfGame;

public class GolfDesktop {

	public static void main(String[] args) {
		
		LwjglApplicationConfiguration cfg = new LwjglApplicationConfiguration();
		cfg.title = "Golf";
		cfg.width = 800;
		cfg.height = 600;
		cfg.useGL20 = true;

		new LwjglApplication(new GolfGame(), cfg);
	}
}
