package com.dteviot.simpleComicBookViewer;

public class Globals {
    public static final String TAG = "SimpleComicBookViewer";
}
