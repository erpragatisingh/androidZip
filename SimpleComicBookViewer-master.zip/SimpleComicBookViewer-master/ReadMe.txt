This is the code for My CodeProject Article about building a .CBZ viewer for Android.
I placed it here to make it easier for me to apply bug fixes and additional features.
This code has the additional changes from the version on Code Project.
1. BitmapViewer now uses a matrix to draw the bitmap.  This allows a zoomed in bitmap to fill the entire screen.
2. Replaced stock andriod App icon with image created by Shira-nyoro http://shiranyoro.deviantart.com/.  Thank you very much Shira Nyoro. 
3. Comics are listed in case insensitive order.

For more details on the code, please refer to the docs directory, or my original CodeProject article
at http://www.codeproject.com/Articles/507276/Simple-Comic-Book-Viewer-for-Android
