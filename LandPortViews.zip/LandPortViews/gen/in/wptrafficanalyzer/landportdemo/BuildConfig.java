/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.landportdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}