sample-airlines
===============

This app is for the fictitious Icenium Airlines Company. The app lets the user view trips, check in for a flight and change seat selection.
For more information please refer to the [sample documentation](http://docs.icenium.com/sample-apps/icenium-airlines-app).
