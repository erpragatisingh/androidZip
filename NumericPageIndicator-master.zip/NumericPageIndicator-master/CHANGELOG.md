Change Log
==========

Version 1.1.0 *(2013-06-6)*
---------------------------
* Don't change button background when pressed if the button is not visible in first or last page.

Version 1.1.0 *(2013-04-16)*
----------------------------
* Added "start" and "end" buttons
* Added new demo "Buttons in landscape mode only"


Version 1.0.0 *(2013-04-09)*
----------------------------
* Initial release.
