/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.activityresultdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}