![Logo][1]

HistoryEditText
===============
Android EditText that auto-saves previous values and displays them in a dropdown when used again.
 [1]: http://png-5.findicons.com/files/icons/1757/isabi/128/time_machine_shaped.png
 
 
 *This is a work in progress*
