/** Automatically generated file. DO NOT MODIFY */
package com.rajib.SmartKart;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}