package com.androidopentutorials.imageslideshow.utils;

public class TagName {
	
	public static final String TAG_STATUS = "status";
	public static final String TAG_DATA = "data";
	public static final String TAG_PRODUCTS = "products";
	public static final String KEY_NAME = "name";
	public static final String KEY_IMAGE_URL = "image_url";	
	public static final String KEY_ID = "id";
}
