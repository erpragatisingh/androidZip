sample-geolocation
==================

This sample application demonstrates the usage of Cordova Geolocation API. For more information please refer to the [sample documentation](http://docs.icenium.com/sample-apps/sample-geolocation).
