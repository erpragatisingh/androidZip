/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.themecustomizationversionspecific;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}