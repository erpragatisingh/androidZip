sample-camera
=============

Icenium sample illustrating the Cordova Camera API. For more information please refer to the [sample documentation](http://docs.icenium.com/sample-apps/sample-camera).
