/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.differentlayout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}