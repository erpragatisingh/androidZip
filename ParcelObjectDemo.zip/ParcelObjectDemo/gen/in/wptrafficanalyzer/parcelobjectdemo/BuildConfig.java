/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.parcelobjectdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}