package in.wptrafficanalyzer.alertdialogradio;

public class Android {
	static String[] code = new String[]{
		"Jelly Bean",
		"Ice Cream Sandwich",
		"Honeycomb",
		"Gingerbread",
		"Froyo",
		"Eclair",
		"Donut",
		"Cupcake"
	};
}
