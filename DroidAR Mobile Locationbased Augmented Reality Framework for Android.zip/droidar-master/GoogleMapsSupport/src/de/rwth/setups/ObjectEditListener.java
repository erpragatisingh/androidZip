package de.rwth.setups;

import util.Wrapper;

public interface ObjectEditListener {

	boolean onChangeWrapperObject(Wrapper wrapper, Object passedObject);

}
