package de.rwth.setups;

public class GoogleMapsKey {

	public static final String pc1DebugKey = "yourKeyHere";

}
