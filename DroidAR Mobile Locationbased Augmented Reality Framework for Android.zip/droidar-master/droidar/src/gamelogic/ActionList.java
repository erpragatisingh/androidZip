package gamelogic;

public class ActionList extends GameElementList<GameAction> {

}
