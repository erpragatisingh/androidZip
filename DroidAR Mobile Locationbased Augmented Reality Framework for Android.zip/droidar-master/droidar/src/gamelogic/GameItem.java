package gamelogic;

public abstract class GameItem extends GameElement {

	public GameItem(String uniqueName, int iconId) {
		super(uniqueName, iconId);
	}

}
