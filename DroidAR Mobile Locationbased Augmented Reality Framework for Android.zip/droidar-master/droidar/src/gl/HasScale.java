package gl;

import util.Vec;

public interface HasScale {
	public Vec getScale();

	public void setScale(Vec scale);
}
