package gl;

import util.Vec;

public interface HasPosition {
	public Vec getPosition();

	public void setPosition(Vec position);
}
